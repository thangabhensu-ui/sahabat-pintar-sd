package id.sahabatpintar.sd.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import id.sahabatpintar.sd.SahabatPintarApp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen() {
    val app = LocalContext.current.applicationContext as SahabatPintarApp
    val studentName by app.preferencesRepository.studentName.collectAsState(initial = "Teman Pintar")
    val schoolName by app.preferencesRepository.schoolName.collectAsState(initial = "SD Negeri 01 Indonesia")
    val studentGrade by app.preferencesRepository.studentGrade.collectAsState(initial = 1)
    val totalStars by app.preferencesRepository.totalStars.collectAsState(initial = 15)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC))
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0284C7))
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(text = "👦", fontSize = 48.sp)
                Spacer(modifier = Modifier.height(8.dp))
                Text(text = studentName, fontWeight = FontWeight.Black, fontSize = 20.sp, color = Color.White)
                Text(text = "$schoolName • Kelas $studentGrade SD", fontSize = 13.sp, color = Color(0xFFE0F2FE))
                Spacer(modifier = Modifier.height(16.dp))
                Row(
                    modifier = Modifier
                        .background(Color(0xFFFACC15), RoundedCornerShape(16.dp))
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Star, contentDescription = null, tint = Color(0xFF713F12))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "$totalStars Bintang Emas", fontWeight = FontWeight.Black, color = Color(0xFF713F12))
                }
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(text = "Lemari Lencana Prestasi:", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Spacer(modifier = Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Surface(shape = RoundedCornerShape(12.dp), color = Color(0xFFFEF9C3)) {
                        Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.EmojiEvents, contentDescription = null, tint = Color(0xFFEAB308))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = "Pelajar Pemula", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFF854D0E))
                        }
                    }
                }
            }
        }
    }
}
