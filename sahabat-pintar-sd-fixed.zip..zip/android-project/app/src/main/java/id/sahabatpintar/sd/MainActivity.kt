package id.sahabatpintar.sd

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import id.sahabatpintar.sd.ui.screens.GamesScreen
import id.sahabatpintar.sd.ui.screens.HomeScreen
import id.sahabatpintar.sd.ui.screens.ProfileScreen
import id.sahabatpintar.sd.ui.screens.QuizScreen
import id.sahabatpintar.sd.ui.screens.SubjectScreen
import id.sahabatpintar.sd.ui.theme.SahabatPintarTheme

sealed class Screen(val route: String, val title: String, val icon: ImageVector) {
    data object Home : Screen("home", "Beranda", Icons.Default.Home)
    data object Subjects : Screen("subjects", "Pelajaran", Icons.Default.Book)
    data object Games : Screen("games", "Game Seru", Icons.Default.Gamepad)
    data object Profile : Screen("profile", "Prestasi", Icons.Default.EmojiEvents)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SahabatPintarTheme {
                MainAppNavigation()
            }
        }
    }
}

@Composable
fun MainAppNavigation() {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    val bottomNavItems = listOf(
        Screen.Home,
        Screen.Subjects,
        Screen.Games,
        Screen.Profile
    )

    val showBottomBar = currentRoute in bottomNavItems.map { it.route }

    Scaffold(
        bottomBar = {
            if (showBottomBar) {
                NavigationBar {
                    bottomNavItems.forEach { screen ->
                        NavigationBarItem(
                            icon = { Icon(screen.icon, contentDescription = screen.title) },
                            label = { Text(screen.title) },
                            selected = currentRoute == screen.route,
                            onClick = {
                                navController.navigate(screen.route) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Home.route,
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            composable(Screen.Home.route) {
                HomeScreen(
                    onSubjectClick = { subjectId, grade ->
                        navController.navigate("subject/$subjectId/$grade")
                    },
                    onQuizClick = { quizId ->
                        navController.navigate("quiz/$quizId")
                    },
                    onGamesClick = {
                        navController.navigate(Screen.Games.route)
                    }
                )
            }

            composable(Screen.Subjects.route) {
                SubjectScreen(
                    subjectId = "matematika",
                    grade = 1,
                    onBack = { navController.popBackStack() },
                    onStartQuiz = { quizId ->
                        navController.navigate("quiz/$quizId")
                    }
                )
            }

            composable(
                route = "subject/{subjectId}/{grade}",
                arguments = listOf(
                    navArgument("subjectId") { type = NavType.StringType },
                    navArgument("grade") { type = NavType.IntType }
                )
            ) { entry ->
                val subjectId = entry.arguments?.getString("subjectId") ?: "matematika"
                val grade = entry.arguments?.getInt("grade") ?: 1
                SubjectScreen(
                    subjectId = subjectId,
                    grade = grade,
                    onBack = { navController.popBackStack() },
                    onStartQuiz = { quizId ->
                        navController.navigate("quiz/$quizId")
                    }
                )
            }

            composable(
                route = "quiz/{quizId}",
                arguments = listOf(navArgument("quizId") { type = NavType.StringType })
            ) { entry ->
                val quizId = entry.arguments?.getString("quizId") ?: ""
                QuizScreen(
                    quizId = quizId,
                    onFinish = { navController.popBackStack() }
                )
            }

            composable(Screen.Games.route) {
                GamesScreen(onBack = { navController.popBackStack() })
            }

            composable(Screen.Profile.route) {
                ProfileScreen()
            }
        }
    }
}
