# SAHABAT PINTAR SD - Proyek Android Native (Kotlin + Jetpack Compose)

Aplikasi pendidikan gratis untuk seluruh anak Sekolah Dasar di Indonesia (Kelas 1 - 6) berbasis Android Native dengan Material 3, Room Database, dan Jetpack DataStore Preferences.

## Spesifikasi Teknis:
- **Bahasa**: Kotlin 2.0.21
- **UI Framework**: Jetpack Compose & Material 3
- **Database Lokal**: AndroidX Room 2.6.1 (100% Offline tanpa internet)
- **Penyimpanan Pengaturan**: Jetpack DataStore Preferences 1.1.1
- **Target SDK**: Android 15 (API 35)
- **Minimum SDK**: Android 7.0 (API 24 - Kompatibel dengan 99% HP Android di Indonesia)
- **Arsitektur**: Clean Architecture Modular (MVVM)

## Cara Membuat File APK (Pilih Salah Satu):

### Cara 1: Menggunakan Android Studio (di Laptop / PC)
1. Ekstrak file zip ini ke folder komputer Anda.
2. Buka **Android Studio** -> Pilih **Open** -> Arahkan ke folder proyek ini.
3. Tunggu proses *Gradle Sync* selesai otomatis.
4. Klik menu **Build** -> **Build Bundle(s) / APK(s)** -> **Build APK(s)**.
5. File `app-debug.apk` siap dipasang langsung ke HP Android Anda!

### Cara 2: Otomatis via Cloud Build (GitHub Actions - Tanpa Perlu Laptop)
1. Unggah folder proyek ini ke akun GitHub Anda (Free).
2. GitHub Actions yang sudah kami sediakan di `.github/workflows/build-apk.yml` akan otomatis melakukan build.
3. Unduh file `app-debug.apk` yang sudah jadi langsung dari menu **Actions -> Artifacts** di HP Anda!

### Cara 3: Menggunakan Termux di HP Android
1. Buka Termux di HP Anda.
2. Pasang JDK & Gradle: `pkg install openjdk-17`
3. Masuk ke folder proyek dan jalankan: `./gradlew assembleDebug`
4. File APK berada di `app/build/outputs/apk/debug/app-debug.apk`.
