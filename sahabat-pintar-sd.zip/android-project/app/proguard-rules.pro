# Add project specific ProGuard rules here.
# By default, the flags in this file are appended to flags specified
# in defaultProguardFile('proguard-android-optimize.txt').

-keepattributes *Annotation*
-dontwarn java.lang.invoke.**
