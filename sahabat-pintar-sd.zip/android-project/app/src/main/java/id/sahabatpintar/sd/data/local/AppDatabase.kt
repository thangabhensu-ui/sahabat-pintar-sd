package id.sahabatpintar.sd.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "completed_lessons")
data class CompletedLessonEntity(
    @PrimaryKey val lessonId: String,
    val subjectId: String,
    val grade: Int,
    val completedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "quiz_results")
data class QuizResultEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val quizId: String,
    val quizTitle: String,
    val subjectId: String,
    val grade: Int,
    val score: Int,
    val totalQuestions: Int,
    val percentage: Int,
    val starsEarned: Int,
    val timestamp: Long = System.currentTimeMillis()
)

@Dao
interface LessonDao {
    @Query("SELECT * FROM completed_lessons WHERE grade = :grade")
    fun getCompletedLessonsByGrade(grade: Int): Flow<List<CompletedLessonEntity>>

    @Query("SELECT COUNT(*) FROM completed_lessons")
    fun getTotalCompletedLessonsCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun markLessonCompleted(lesson: CompletedLessonEntity)

    @Insert
    suspend fun insertQuizResult(result: QuizResultEntity)

    @Query("SELECT * FROM quiz_results ORDER BY timestamp DESC LIMIT 30")
    fun getAllQuizResults(): Flow<List<QuizResultEntity>>

    @Query("SELECT SUM(starsEarned) FROM quiz_results")
    fun getTotalStarsFromQuizzes(): Flow<Int?>
}

@Database(
    entities = [CompletedLessonEntity::class, QuizResultEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun lessonDao(): LessonDao
}
