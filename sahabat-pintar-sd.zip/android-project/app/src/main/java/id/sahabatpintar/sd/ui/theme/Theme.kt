package id.sahabatpintar.sd.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val LightColorScheme = lightColorScheme(
    primary = SkyBluePrimary,
    onPrimary = PureWhite,
    primaryContainer = SkyBlueContainer,
    onPrimaryContainer = DarkNavyText,
    secondary = YellowAccent,
    onSecondary = DarkNavyText,
    secondaryContainer = YellowContainer,
    onSecondaryContainer = DarkNavyText,
    tertiary = GreenSuccess,
    background = LightBackground,
    surface = PureWhite,
    onBackground = DarkNavyText,
    onSurface = DarkNavyText
)

@Composable
fun SahabatPintarTheme(
    content: @Composable () -> Unit
) {
    val colorScheme = LightColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = SkyBlueDark.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
