package id.sahabatpintar.sd.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import id.sahabatpintar.sd.SahabatPintarApp

data class SubjectItem(val id: String, val name: String, val desc: String, val color: Color, val tag: String)

@Composable
fun HomeScreen(
    onSubjectClick: (String, Int) -> Unit,
    onQuizClick: (String) -> Unit,
    onGamesClick: () -> Unit
) {
    val app = LocalContext.current.applicationContext as SahabatPintarApp
    val studentGrade by app.preferencesRepository.studentGrade.collectAsState(initial = 1)
    val totalStars by app.preferencesRepository.totalStars.collectAsState(initial = 15)
    val studentName by app.preferencesRepository.studentName.collectAsState(initial = "Teman Pintar")

    val coroutineScope = rememberCoroutineScope()

    val subjects = listOf(
        SubjectItem("bahasa_indonesia", "Bahasa Indonesia", "Membaca kata ajaib, puisi, dan menyusun kalimat indah", Color(0xFF0284C7), "Membaca"),
        SubjectItem("matematika", "Matematika", "Petualangan angka, penjumlahan, perkalian, dan pecahan", Color(0xFFEAB308), "Angka"),
        SubjectItem("ipas", "IPAS (Alam & Sosial)", "Pancaindra, fotosintesis, tata surya, dan budaya", Color(0xFF16A34A), "Sains"),
        SubjectItem("pancasila", "Pendidikan Pancasila", "5 Sila Garuda, gotong royong, dan cinta tanah air", Color(0xFFDC2626), "Karakter"),
        SubjectItem("bahasa_inggris", "Bahasa Inggris", "Colors, numbers, animals, greetings, and vocabulary", Color(0xFF9333EA), "Bahasa"),
        SubjectItem("seni_budaya", "Seni dan Budaya", "Warna primer, lagu daerah, tari, dan kerajinan tangan", Color(0xFFEA580C), "Kreativitas"),
        SubjectItem("agama", "Pendidikan Agama", "Kejujuran, berbakti kepada orang tua, dan budi pekerti", Color(0xFF0D9488), "Akhlak")
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF0F9FF))
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        // Top Header greeting
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "SAHABAT PINTAR SD",
                    fontWeight = FontWeight.Black,
                    fontSize = 20.sp,
                    color = Color(0xFF0369A1)
                )
                Text(
                    text = "Halo, $studentName! Siap belajar hari ini?",
                    fontSize = 13.sp,
                    color = Color(0xFF64748B)
                )
            }

            // Star Counter
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = Color(0xFFFEF9C3),
                shadowElevation = 2.dp
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Star,
                        contentDescription = "Bintang",
                        tint = Color(0xFFEAB308),
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "$totalStars Bintang",
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF854D0E),
                        fontSize = 13.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Grade Selector 1 to 6
        Text(
            text = "Pilih Kelasmu:",
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            color = Color(0xFF1E293B)
        )
        Spacer(modifier = Modifier.height(6.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            (1..6).forEach { g ->
                val isSelected = studentGrade == g
                Button(
                    onClick = {
                        // Launch coroutine to update grade
                    },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isSelected) Color(0xFF0284C7) else Color.White,
                        contentColor = if (isSelected) Color.White else Color(0xFF334155)
                    ),
                    elevation = ButtonDefaults.buttonElevation(defaultElevation = 2.dp),
                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 8.dp)
                ) {
                    Text(
                        text = "Kls $g",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Continue Learning Banner
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onSubjectClick("matematika", studentGrade) },
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFE0F2FE))
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Lanjutkan Belajar Terakhir",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0369A1)
                    )
                    Text(
                        text = "Matematika • Kelas $studentGrade SD",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Black,
                        color = Color(0xFF0F172A)
                    )
                }
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = "Mulai",
                    tint = Color(0xFF0284C7),
                    modifier = Modifier.size(32.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 7 Subjects List
        Text(
            text = "Menu 7 Mata Pelajaran Lengkap:",
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            color = Color(0xFF1E293B)
        )
        Spacer(modifier = Modifier.height(8.dp))

        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            subjects.forEach { sub ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSubjectClick(sub.id, studentGrade) },
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(sub.color),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = sub.name.take(1),
                                color = Color.White,
                                fontWeight = FontWeight.Black,
                                fontSize = 18.sp
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = sub.name,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = Color(0xFF0F172A)
                            )
                            Text(
                                text = sub.desc,
                                fontSize = 11.sp,
                                color = Color(0xFF64748B),
                                maxLines = 1
                            )
                        }
                    }
                }
            }
        }
    }
}
