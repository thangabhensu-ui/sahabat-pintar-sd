package id.sahabatpintar.sd

import android.app.Application
import androidx.room.Room
import id.sahabatpintar.sd.data.datastore.UserPreferencesRepository
import id.sahabatpintar.sd.data.local.AppDatabase

class SahabatPintarApp : Application() {

    lateinit var database: AppDatabase
        private set

    lateinit var preferencesRepository: UserPreferencesRepository
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this

        database = Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java,
            "sahabat_pintar_database"
        ).fallbackToDestructiveMigration().build()

        preferencesRepository = UserPreferencesRepository(applicationContext)
    }

    companion object {
        lateinit var instance: SahabatPintarApp
            private set
    }
}
