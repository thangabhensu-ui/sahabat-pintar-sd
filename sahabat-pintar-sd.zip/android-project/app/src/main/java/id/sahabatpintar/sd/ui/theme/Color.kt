package id.sahabatpintar.sd.ui.theme

import androidx.compose.ui.graphics.Color

val SkyBluePrimary = Color(0xFF0284C7)
val SkyBlueContainer = Color(0xFFE0F2FE)
val SkyBlueDark = Color(0xFF0369A1)

val YellowAccent = Color(0xFFFACC15)
val YellowContainer = Color(0xFFFEF9C3)
val YellowDark = Color(0xFFCA8A04)

val GreenSuccess = Color(0xFF22C55E)
val GreenContainer = Color(0xFFDCFCE7)

val RedHonor = Color(0xFFDC2626)
val RedContainer = Color(0xFFFEE2E2)

val DarkNavyText = Color(0xFF0F172A)
val SlateSubtitle = Color(0xFF64748B)
val LightBackground = Color(0xFFF8FAFC)
val PureWhite = Color(0xFFFFFFFF)
