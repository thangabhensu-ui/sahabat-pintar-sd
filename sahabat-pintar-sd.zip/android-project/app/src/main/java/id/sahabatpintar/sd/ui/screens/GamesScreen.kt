package id.sahabatpintar.sd.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GamesScreen(onBack: () -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Game Edukasi Ceria") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Kembali")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF0284C7),
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(Color(0xFFF8FAFC))
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF9C3))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = "🎈 Teka-Teki Balon Angka", fontWeight = FontWeight.Black, fontSize = 16.sp, color = Color(0xFF854D0E))
                    Text(text = "Pecahkan balon jawaban matematika yang tepat untuk mengumpulkan bintang!", fontSize = 12.sp, color = Color(0xFF713F12))
                }
            }

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFDCFCE7))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = "🧩 Susun Kata Ceria", fontWeight = FontWeight.Black, fontSize = 16.sp, color = Color(0xFF166534))
                    Text(text = "Susun huruf-huruf acak menjadi nama flora, fauna, dan pahlawan nusantara!", fontSize = 12.sp, color = Color(0xFF14532D))
                }
            }

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFEE2E2))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = "🦅 Petualangan Garuda Pancasila", fontWeight = FontWeight.Black, fontSize = 16.sp, color = Color(0xFF991B1B))
                    Text(text = "Jodohkan 5 simbol perisai Garuda dengan butir pengamalan luhur sehari-hari!", fontSize = 12.sp, color = Color(0xFF7F1D1D))
                }
            }
        }
    }
}
