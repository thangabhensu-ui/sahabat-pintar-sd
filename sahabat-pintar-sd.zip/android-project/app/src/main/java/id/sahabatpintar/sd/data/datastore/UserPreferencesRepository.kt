package id.sahabatpintar.sd.data.datastore

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "sahabat_pintar_prefs")

class UserPreferencesRepository(private val context: Context) {

    private object Keys {
        val STUDENT_NAME = stringPreferencesKey("student_name")
        val SCHOOL_NAME = stringPreferencesKey("school_name")
        val STUDENT_GRADE = intPreferencesKey("student_grade")
        val AVATAR_ID = stringPreferencesKey("avatar_id")
        val TOTAL_STARS = intPreferencesKey("total_stars")
        val SOUND_ENABLED = booleanPreferencesKey("sound_enabled")
    }

    val studentName: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[Keys.STUDENT_NAME] ?: "Teman Pintar"
    }

    val schoolName: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[Keys.SCHOOL_NAME] ?: "SD Negeri 01 Indonesia"
    }

    val studentGrade: Flow<Int> = context.dataStore.data.map { prefs ->
        prefs[Keys.STUDENT_GRADE] ?: 1
    }

    val avatarId: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[Keys.AVATAR_ID] ?: "boni"
    }

    val totalStars: Flow<Int> = context.dataStore.data.map { prefs ->
        prefs[Keys.TOTAL_STARS] ?: 15
    }

    val soundEnabled: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[Keys.SOUND_ENABLED] ?: true
    }

    suspend fun updateGrade(grade: Int) {
        context.dataStore.edit { prefs ->
            prefs[Keys.STUDENT_GRADE] = grade
        }
    }

    suspend fun updateProfile(name: String, school: String, avatar: String) {
        context.dataStore.edit { prefs ->
            prefs[Keys.STUDENT_NAME] = name
            prefs[Keys.SCHOOL_NAME] = school
            prefs[Keys.AVATAR_ID] = avatar
        }
    }

    suspend fun addStars(amount: Int) {
        context.dataStore.edit { prefs ->
            val current = prefs[Keys.TOTAL_STARS] ?: 15
            prefs[Keys.TOTAL_STARS] = current + amount
        }
    }

    suspend fun toggleSound() {
        context.dataStore.edit { prefs ->
            val current = prefs[Keys.SOUND_ENABLED] ?: true
            prefs[Keys.SOUND_ENABLED] = !current
        }
    }
}
