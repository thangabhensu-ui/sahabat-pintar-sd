import { UserProfile, Grade, AvatarId, QuizResultRecord, SubjectId } from '../types';

const STORAGE_KEY = 'sahabat_pintar_sd_profile_v2';

const DEFAULT_PROFILE: UserProfile = {
  name: 'Teman Pintar',
  schoolName: 'SD Negeri 01 Indonesia',
  grade: 1,
  avatarId: 'boni',
  stars: 15,
  completedLessons: ['bin_g1_t1'],
  unlockedBadges: ['welcome', 'first_lesson'],
  quizHistory: [],
  soundEnabled: true,
  lastLessonId: 'bin_g1_t1',
  lastSubjectId: 'bahasa_indonesia'
};

export const storageService = {
  getProfile: (): UserProfile => {
    if (typeof window === 'undefined') return DEFAULT_PROFILE;
    try {
      const data = localStorage.getItem(STORAGE_KEY);
      if (!data) {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(DEFAULT_PROFILE));
        return DEFAULT_PROFILE;
      }
      return { ...DEFAULT_PROFILE, ...JSON.parse(data) };
    } catch {
      return DEFAULT_PROFILE;
    }
  },

  saveProfile: (profile: UserProfile): void => {
    if (typeof window === 'undefined') return;
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(profile));
    } catch (e) {
      console.error('Failed to save profile', e);
    }
  },

  updateGrade: (grade: Grade): UserProfile => {
    const current = storageService.getProfile();
    const updated: UserProfile = { ...current, grade };
    storageService.saveProfile(updated);
    return updated;
  },

  updateAvatar: (avatarId: AvatarId): UserProfile => {
    const current = storageService.getProfile();
    const updated: UserProfile = { ...current, avatarId };
    storageService.saveProfile(updated);
    return updated;
  },

  updateName: (name: string, schoolName?: string): UserProfile => {
    const current = storageService.getProfile();
    const updated: UserProfile = {
      ...current,
      name: name.trim() || 'Teman Pintar',
      schoolName: schoolName !== undefined ? schoolName.trim() : current.schoolName
    };
    storageService.saveProfile(updated);
    return updated;
  },

  addStars: (amount: number): UserProfile => {
    const current = storageService.getProfile();
    const newStars = Math.max(0, current.stars + amount);
    let badges = [...current.unlockedBadges];

    if (newStars >= 50 && !badges.includes('star_50')) {
      badges.push('star_50');
    }
    if (newStars >= 100 && !badges.includes('star_100')) {
      badges.push('star_100');
    }

    const updated: UserProfile = { ...current, stars: newStars, unlockedBadges: badges };
    storageService.saveProfile(updated);
    return updated;
  },

  completeLesson: (lessonId: string, subjectId: SubjectId): UserProfile => {
    const current = storageService.getProfile();
    const completed = new Set(current.completedLessons);
    completed.add(lessonId);

    const badges = [...current.unlockedBadges];
    if (completed.size >= 1 && !badges.includes('first_lesson')) {
      badges.push('first_lesson');
    }
    if (completed.size >= 5 && !badges.includes('scholar_5')) {
      badges.push('scholar_5');
    }

    const updated: UserProfile = {
      ...current,
      completedLessons: Array.from(completed),
      unlockedBadges: badges,
      lastLessonId: lessonId,
      lastSubjectId: subjectId
    };
    storageService.saveProfile(updated);
    return updated;
  },

  recordQuiz: (record: QuizResultRecord): UserProfile => {
    const current = storageService.getProfile();
    const history = [record, ...current.quizHistory.slice(0, 49)];
    const starsGained = record.starsEarned;
    const newStars = current.stars + starsGained;

    const badges = [...current.unlockedBadges];
    if (record.percentage === 100 && !badges.includes('perfect_quiz')) {
      badges.push('perfect_quiz');
    }
    if (history.length >= 3 && !badges.includes('quiz_master_3')) {
      badges.push('quiz_master_3');
    }

    const updated: UserProfile = {
      ...current,
      stars: newStars,
      quizHistory: history,
      unlockedBadges: badges
    };
    storageService.saveProfile(updated);
    return updated;
  },

  resetProgress: (): UserProfile => {
    const fresh = { ...DEFAULT_PROFILE, name: storageService.getProfile().name };
    storageService.saveProfile(fresh);
    return fresh;
  }
};
