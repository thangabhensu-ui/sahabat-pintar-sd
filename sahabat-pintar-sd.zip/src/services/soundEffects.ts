// Web Audio API Synthesizer & Web Speech API Reader for Sahabat Pintar SD

let audioCtx: AudioContext | null = null;

function getAudioContext(): AudioContext | null {
  if (typeof window === 'undefined') return null;
  if (!audioCtx) {
    const AudioContextClass =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (AudioContextClass) {
      audioCtx = new AudioContextClass();
    }
  }
  if (audioCtx && audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
  return audioCtx;
}

export const playSound = {
  click: () => {
    try {
      const ctx = getAudioContext();
      if (!ctx) return;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(440, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.08);
      gain.gain.setValueAtTime(0.12, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.08);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.08);
    } catch {
      // Ignore audio context autoplay limitations
    }
  },

  success: () => {
    try {
      const ctx = getAudioContext();
      if (!ctx) return;
      const now = ctx.currentTime;
      // Arpeggio C5, E5, G5, C6
      const notes = [523.25, 659.25, 783.99, 1046.5];
      notes.forEach((freq, i) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.value = freq;
        gain.gain.setValueAtTime(0.15, now + i * 0.08);
        gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.08 + 0.25);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now + i * 0.08);
        osc.stop(now + i * 0.08 + 0.25);
      });
    } catch {
      // Ignore
    }
  },

  wrong: () => {
    try {
      const ctx = getAudioContext();
      if (!ctx) return;
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      // Gentle soft descending 'boop'
      osc.frequency.setValueAtTime(260, now);
      osc.frequency.exponentialRampToValueAtTime(180, now + 0.2);
      gain.gain.setValueAtTime(0.15, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.2);
    } catch {
      // Ignore
    }
  },

  star: () => {
    try {
      const ctx = getAudioContext();
      if (!ctx) return;
      const now = ctx.currentTime;
      const notes = [659.25, 880, 1174.66, 1318.51];
      notes.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.value = freq;
        gain.gain.setValueAtTime(0.12, now + idx * 0.06);
        gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.06 + 0.2);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now + idx * 0.06);
        osc.stop(now + idx * 0.06 + 0.2);
      });
    } catch {
      // Ignore
    }
  },

  fanfare: () => {
    try {
      const ctx = getAudioContext();
      if (!ctx) return;
      const now = ctx.currentTime;
      // Chords: G4, C5, E5, G5
      const freqs = [392.0, 523.25, 659.25, 783.99, 1046.5];
      freqs.forEach((f, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(f, now + idx * 0.1);
        gain.gain.setValueAtTime(0.18, now + idx * 0.1);
        gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.1 + 0.5);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now + idx * 0.1);
        osc.stop(now + idx * 0.1 + 0.5);
      });
    } catch {
      // Ignore
    }
  }
};

let currentTextBeingSpoken = '';
let currentSpeechOptions: {
  rate?: number;
  pitch?: number;
  onEnd?: () => void;
  onError?: () => void;
} = {};
let speechPaused = false;

// Web Speech API for reading lesson content and exercise questions in Indonesian
export const speechService = {
  isSupported: () => {
    return typeof window !== 'undefined' && 'speechSynthesis' in window;
  },

  speak: (
    text: string,
    options?: {
      rate?: number;
      pitch?: number;
      onEnd?: () => void;
      onError?: () => void;
    }
  ) => {
    if (!speechService.isSupported()) return;
    window.speechSynthesis.cancel();
    speechPaused = false;
    currentTextBeingSpoken = text;
    currentSpeechOptions = options || {};

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'id-ID';
    utterance.rate = options?.rate ?? 0.95; // Friendly rate for children
    utterance.pitch = options?.pitch ?? 1.1; // Cheerful friendly tone

    // Try finding an Indonesian voice if available
    const voices = window.speechSynthesis.getVoices();
    const indonesianVoice = voices.find(
      (v) => v.lang === 'id-ID' || v.lang.startsWith('id')
    );
    if (indonesianVoice) {
      utterance.voice = indonesianVoice;
    }

    utterance.onend = () => {
      speechPaused = false;
      options?.onEnd?.();
    };
    utterance.onerror = () => {
      speechPaused = false;
      options?.onError?.();
    };

    window.speechSynthesis.speak(utterance);
  },

  pause: () => {
    if (speechService.isSupported() && window.speechSynthesis.speaking) {
      window.speechSynthesis.pause();
      speechPaused = true;
    }
  },

  resume: () => {
    if (speechService.isSupported() && speechPaused) {
      window.speechSynthesis.resume();
      speechPaused = false;
    } else if (currentTextBeingSpoken) {
      speechService.speak(currentTextBeingSpoken, currentSpeechOptions);
    }
  },

  stop: () => {
    if (speechService.isSupported()) {
      window.speechSynthesis.cancel();
      speechPaused = false;
    }
  },

  replay: () => {
    if (currentTextBeingSpoken) {
      speechService.stop();
      speechService.speak(currentTextBeingSpoken, currentSpeechOptions);
    }
  },

  isSpeaking: () => {
    return speechService.isSupported() && window.speechSynthesis.speaking && !speechPaused;
  },

  isPaused: () => {
    return speechService.isSupported() && speechPaused;
  }
};
