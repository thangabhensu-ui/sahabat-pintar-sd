import { Lesson, Quiz, Grade, SubjectId, ExerciseQuestion } from '../types';
import { getBahasaIndonesiaLessonsForGrade } from './curriculum/bahasaIndonesia';
import { getMatematikaLessonsForGrade } from './curriculum/matematika';
import { getIpasLessonsForGrade } from './curriculum/ipas';
import { getOtherSubjectLessonsForGrade } from './curriculum/otherSubjects';

// Master accessor for all lessons for a given subject and grade
export function getLessonsForSubjectAndGrade(subjectId: SubjectId, grade: Grade): Lesson[] {
  switch (subjectId) {
    case 'bahasa_indonesia':
      return getBahasaIndonesiaLessonsForGrade(grade);
    case 'matematika':
      return getMatematikaLessonsForGrade(grade);
    case 'ipas':
      return getIpasLessonsForGrade(grade);
    case 'pancasila':
    case 'bahasa_inggris':
    case 'seni_budaya':
    case 'agama':
      return getOtherSubjectLessonsForGrade(subjectId, grade);
    default:
      return [];
  }
}

// Master accessor for all lessons of a specific grade
export function getAllLessonsForGrade(grade: Grade): Lesson[] {
  const subjects: SubjectId[] = [
    'bahasa_indonesia',
    'matematika',
    'ipas',
    'pancasila',
    'bahasa_inggris',
    'seni_budaya',
    'agama'
  ];

  const all: Lesson[] = [];
  for (const s of subjects) {
    all.push(...getLessonsForSubjectAndGrade(s, grade));
  }
  return all;
}

// Global lookup for any lesson by ID
export function findLessonById(id: string): Lesson | undefined {
  const grades: Grade[] = [1, 2, 3, 4, 5, 6];
  for (const g of grades) {
    const list = getAllLessonsForGrade(g);
    const found = list.find((l) => l.id === id);
    if (found) return found;
  }
  return undefined;
}

// Generate quizzes dynamically from lesson exercises
export function getQuizForLesson(lesson: Lesson): Quiz {
  const questions: ExerciseQuestion[] = lesson.exercises && lesson.exercises.length > 0
    ? lesson.exercises
    : [
        {
          id: `${lesson.id}_q1`,
          type: 'multiple_choice',
          prompt: `Apa intisari utama dari bab ${lesson.title}?`,
          options: [
            lesson.summary,
            'Tidak ada pembelajaran yang bermakna',
            'Bermain tanpa aturan',
            'Mengabaikan pelajaran'
          ],
          correctOptionIndex: 0,
          explanation: `Pelajaran ${lesson.title} mengajarkan kita: ${lesson.summary}`,
          hint: 'Ingat kembali ringkasan materi di awal bab.',
          praiseMessage: 'Hebat sekali! Pemahamanmu sempurna!',
          points: 25
        },
        {
          id: `${lesson.id}_q2`,
          type: 'true_false',
          prompt: `Mempelajari materi ${lesson.title} membantu kita menjadi siswa yang lebih pintar dan berakhlak mulia.`,
          isTrue: true,
          explanation: 'Benar! Menuntut ilmu dengan sungguh-sungguh selalu membawa kebaikan.',
          hint: 'Apakah belajar itu bermanfaat?',
          praiseMessage: 'Tepat sekali!',
          points: 25
        }
      ];

  return {
    id: `quiz_${lesson.id}`,
    lessonId: lesson.id,
    subjectId: lesson.subjectId,
    grade: lesson.grade,
    title: `Kuis ${lesson.title}`,
    description: `Uji pemahamanmu tentang ${lesson.subtitle} (Bab ${lesson.chapterNumber})`,
    rewardStars: 10,
    questions
  };
}

// Accessor for all quizzes of a grade
export function getQuizzesForGrade(grade: Grade): Quiz[] {
  const lessons = getAllLessonsForGrade(grade);
  return lessons.map((l) => getQuizForLesson(l));
}

// Default export of flat lessons list for Grade 1 (fallback)
export const LESSONS: Lesson[] = getAllLessonsForGrade(1);
export const QUIZZES: Quiz[] = getQuizzesForGrade(1);
