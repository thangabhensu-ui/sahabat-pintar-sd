import { Subject, Badge } from '../types';

export const SUBJECTS: Subject[] = [
  {
    id: 'bahasa_indonesia',
    name: 'Bahasa Indonesia',
    shortName: 'B. Indonesia',
    iconName: 'BookOpen',
    color: '#0284c7', // Sky Blue 600
    bgLight: '#f0f9ff',
    borderLight: '#bae6fd',
    description: 'Membaca cerita ceria, mengenal huruf, kata ajaib, puisi, dan menyusun kalimat indah.',
    topicCount: 6,
    badgeTag: 'Membaca & Berbahasa'
  },
  {
    id: 'matematika',
    name: 'Matematika',
    shortName: 'Matematika',
    iconName: 'Calculator',
    color: '#eab308', // Warm Yellow 500
    bgLight: '#fefce8',
    borderLight: '#fde047',
    description: 'Petualangan angka seru, tambah-kurang, perkalian, pecahan, dan bangun ruang ajaib.',
    topicCount: 6,
    badgeTag: 'Angka & Logika'
  },
  {
    id: 'ipas',
    name: 'IPAS (Alam & Sosial)',
    shortName: 'IPAS',
    iconName: 'Compass',
    color: '#16a34a', // Fresh Green 600
    bgLight: '#f0fdf4',
    borderLight: '#bbf7d0',
    description: 'Rahasia tubuh manusia, tumbuhan hijau, tata surya, gaya gerak, dan cerita budaya nusantara.',
    topicCount: 6,
    badgeTag: 'Sains & Alam'
  },
  {
    id: 'pancasila',
    name: 'Pendidikan Pancasila',
    shortName: 'Pancasila',
    iconName: 'ShieldCheck',
    color: '#dc2626', // Proud Red 600
    bgLight: '#fef2f2',
    borderLight: '#fecaca',
    description: 'Mengenal 5 Sila Garuda, arti gotong royong, hak anak, aturan sekolah, dan cinta tanah air.',
    topicCount: 5,
    badgeTag: 'Karakter & Nilai'
  },
  {
    id: 'bahasa_inggris',
    name: 'Bahasa Inggris',
    shortName: 'English',
    iconName: 'Globe',
    color: '#9333ea', // Purple 600
    bgLight: '#faf5ff',
    borderLight: '#e9d5ff',
    description: 'Fun English words, greetings, animals, colors, daily talk, and cheerful rhymes!',
    topicCount: 5,
    badgeTag: 'Global Language'
  },
  {
    id: 'seni_budaya',
    name: 'Seni dan Budaya',
    shortName: 'Seni Budaya',
    iconName: 'Palette',
    color: '#ea580c', // Orange 600
    bgLight: '#fff7ed',
    borderLight: '#fed7aa',
    description: 'Mencampur warna pelangi, lagu daerah Indonesia, alat musik tradisional, dan tari ceria.',
    topicCount: 5,
    badgeTag: 'Kreativitas & Seni'
  },
  {
    id: 'agama',
    name: 'Pendidikan Agama & Budi Pekerti',
    shortName: 'Budi Pekerti',
    iconName: 'HeartHandshake',
    color: '#0d9488', // Teal 600
    bgLight: '#f0fdfa',
    borderLight: '#99f6e4',
    description: 'Belajar berbuat jujur, sayang orang tua & guru, tolong menolong, dan saling menghargai sesama.',
    topicCount: 5,
    badgeTag: 'Akhlak Mulia'
  }
];

export const BADGES: Badge[] = [
  {
    id: 'welcome',
    title: 'Pelajar Pemula',
    description: 'Selamat datang di Sahabat Pintar SD! Langkah pertama menjadi juara.',
    icon: 'Sparkles',
    color: '#38bdf8'
  },
  {
    id: 'first_lesson',
    title: 'Pembaca Hebat',
    description: 'Menyelesaikan materi pertama dengan penuh semangat.',
    icon: 'BookOpen',
    color: '#22c55e'
  },
  {
    id: 'star_50',
    title: 'Kolektor 50 Bintang',
    description: 'Mengumpulkan 50 bintang prestasi dari kuis dan belajar.',
    icon: 'Star',
    color: '#facc15'
  },
  {
    id: 'star_100',
    title: 'Bintang Emas Juara',
    description: 'Mencapai 100 bintang gemilang! Kamu anak luar biasa!',
    icon: 'Trophy',
    color: '#eab308'
  },
  {
    id: 'perfect_quiz',
    title: 'Nilai Sempurna 100',
    description: 'Meraih skor 100 pada kuis pilihan ganda tanpa salah!',
    icon: 'Award',
    color: '#ef4444'
  },
  {
    id: 'quiz_master_3',
    title: 'Jagoan Kuis',
    description: 'Menyelesaikan minimal 3 kuis pembelajaran dengan sukses.',
    icon: 'Flame',
    color: '#a855f7'
  },
  {
    id: 'scholar_5',
    title: 'Cendekia Cilik',
    description: 'Membaca dan menuntaskan 5 materi pelajaran berbeda.',
    icon: 'GraduationCap',
    color: '#0284c7'
  }
];

export const AVATARS = [
  {
    id: 'boni' as const,
    name: 'Boni',
    title: 'Ceria & Semangat',
    desc: 'Boni memakai seragam merah-putih SD dan peci hitam Indonesia.',
    primaryColor: '#0284c7'
  },
  {
    id: 'sasa' as const,
    name: 'Sasa',
    title: 'Pintar & Kreatif',
    desc: 'Sasa tersenyum riang dengan pita kuning di rambutnya.',
    primaryColor: '#ec4899'
  },
  {
    id: 'edo' as const,
    name: 'Edo',
    title: 'Penjelajah Alam',
    desc: 'Edo gemar sains dan bertualang melihat keindahan nusantara.',
    primaryColor: '#16a34a'
  },
  {
    id: 'siti' as const,
    name: 'Siti',
    title: 'Santun & Rajin',
    desc: 'Siti berkerudung putih rapi dan selalu suka membaca buku.',
    primaryColor: '#0d9488'
  },
  {
    id: 'dayu' as const,
    name: 'Dayu',
    title: 'Seniman Cilik',
    desc: 'Dayu pandai menari tarian daerah dan menyanyi lagu nusantara.',
    primaryColor: '#ea580c'
  },
  {
    id: 'budi' as const,
    name: 'Budi',
    title: 'Juara Hitung',
    desc: 'Budi memakai kacamata pintar dan sangat cepat berhitung!',
    primaryColor: '#8b5cf6'
  }
];
