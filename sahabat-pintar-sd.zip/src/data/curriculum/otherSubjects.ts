import { Lesson, Grade, SubjectId } from '../../types';

// Structured Curriculum Data for Pendidikan Pancasila, Bahasa Inggris, Seni Budaya, and Agama
export function getOtherSubjectLessonsForGrade(subjectId: SubjectId, grade: Grade): Lesson[] {
  // Topic definitions for each subject across grades
  const subjectConfigs: Record<string, Record<number, Array<{ title: string; subtitle: string; cat: string; fact: string; summary: string; samplePrompt: string; sampleAns: string }>>> = {
    pancasila: {
      1: [
        { title: 'Mengenal 5 Simbol Garuda Pancasila', subtitle: 'Bintang, rantai, beringin, banteng, padi kapas', cat: 'Dasar Negara', fact: 'Garuda Pancasila dirancang oleh Sultan Hamid II dari Pontianak!', summary: 'Mengenal 5 lambang sila di perisai burung Garuda dan maknanya.', samplePrompt: 'Simbol sila pertama adalah...', sampleAns: 'Bintang Emas' },
        { title: 'Aturan di Rumah dan di Sekolah', subtitle: 'Disiplin dan tertib sejak usia dini', cat: 'Norma & Aturan', fact: 'Mentaati aturan membuat suasana belajar menjadi tenang dan menyenangkan!', summary: 'Mengenal aturan bangun pagi, merapikan mainan, dan berbaris rapi di sekolah.', samplePrompt: 'Aturan dibuat agar hidup kita...', sampleAns: 'Tertib dan damai' },
        { title: 'Aku dan Sahabatku yang Berbeda', subtitle: 'Mengenal keberagaman ciri fisik dan hobi', cat: 'Bhinneka Tunggal Ika', fact: 'Meskipun berbeda suku dan warna kulit, kita semua bersaudara anak Indonesia!', summary: 'Saling menghargai perbedaan rambut keriting, lurus, dan kegemaran bersama teman.', samplePrompt: 'Sikap kita saat teman memiliki hobi berbeda adalah...', sampleAns: 'Menghargai dan rukun' },
        { title: 'Gotong Royong Membersihkan Kelas', subtitle: 'Bekerja bersama terasa ringan dan cepat selesai', cat: 'Gotong Royong', fact: 'Gotong royong adalah tradisi asli bangsa Indonesia yang dikagumi dunia!', summary: 'Manfaat kerja sama saat piket kelas: menyapu, menghapus papan, dan merapikan meja.', samplePrompt: 'Pekerjaan berat jika dikerjakan bersama akan menjadi...', sampleAns: 'Ringan dan cepat selesai' },
        { title: 'Cinta Bendera Merah Putih dan Lagu Kebangsaan', subtitle: 'Menghormati lambang kebanggaan negara', cat: 'Cinta Tanah Air', fact: 'Warna merah melambangkan keberanian dan warna putih melambangkan kesucian hati!', summary: 'Sikap tegap saat menyanyikan lagu Indonesia Raya dan menghormati Sang Merah Putih.', samplePrompt: 'Sikap saat mendengar lagu Indonesia Raya berkumandang adalah...', sampleAns: 'Berdiri tegap dan khidmat' }
      ],
      2: [
        { title: 'Penerapan Sila Pertama dan Kedua di Rumah', subtitle: 'Berdoa bersama dan tolong-menolong sesama saudara', cat: 'Pengamalan Sila', fact: 'Berbagi bekal makanan dengan teman adalah wujud nyata pengamalan Sila ke-2!', summary: 'Beribadah tepat waktu dan bersikap adil serta menyayangi kakak dan adik.', samplePrompt: 'Berdoa sebelum makan adalah pengamalan Sila ke...', sampleAns: 'Sila ke-1' },
        { title: 'Hak dan Kewajiban Anak di Rumah', subtitle: 'Mendapat kasih sayang dan membantu orang tua', cat: 'Hak & Kewajiban', fact: 'Kewajiban harus dilaksanakan dengan ikhlas sebelum menuntut hak kita!', summary: 'Hak anak mendapatkan pendidikan dan kewajiban belajar serta merapikan kamar.', samplePrompt: 'Membantu ibu menyapu lantai adalah contoh...', sampleAns: 'Kewajiban anak di rumah' },
        { title: 'Menjaga Kerukunan dalam Keberagaman Agama', subtitle: 'Enam agama resmi di Indonesia hidup berdampingan', cat: 'Toleransi', fact: 'Semboyan Bhinneka Tunggal Ika tertulis di pita yang dicengkeram Burung Garuda!', summary: 'Mengucapkan selamat hari raya dan tidak berisik saat tetangga beribadah.', samplePrompt: 'Arti semboyan Bhinneka Tunggal Ika adalah...', sampleAns: 'Berbeda-beda tetapi tetap satu' },
        { title: 'Musyawarah Sederhana Memilih Ketua Kelas', subtitle: 'Pengamalan Sila ke-4 Kepala Banteng', cat: 'Musyawarah', fact: 'Kepala Banteng melambangkan hewan sosial yang suka berkumpul dan berdiskusi.', summary: 'Menyampaikan usulan secara sopan dan menerima keputusan voting dengan lapang dada.', samplePrompt: 'Keputusan bersama dalam kelas diambil melalui cara...', sampleAns: 'Musyawarah mufakat' },
        { title: 'Mengenal Pahlawan Nasional Indonesia', subtitle: 'Ki Hajar Dewantara, R.A. Kartini, dan Bung Karno', cat: 'Sejarah Bangsa', fact: 'Ki Hajar Dewantara adalah Bapak Pendidikan Nasional dengan semboyan Tut Wuri Handayani!', summary: 'Meneladani semangat belajar Kartini dan perjuangan para pahlawan kemerdekaan.', samplePrompt: 'Hari Pendidikan Nasional diperingati untuk menghormati jasa...', sampleAns: 'Ki Hajar Dewantara' }
      ],
      3: [
        { title: 'Arti Lambang Perisai Garuda Pancasila', subtitle: 'Makna warna merah-putih dan garis tebal khatulistiwa', cat: 'Simbol Negara', fact: 'Garis hitam tebal di tengah perisai melambangkan garis khatulistiwa yang melintasi nusantara!', summary: 'Mendalami makna filosofis perisai dan 17-8-45 helai bulu burung Garuda.', samplePrompt: 'Garis tebal di tengah perisai Garuda melambangkan...', sampleAns: 'Garis Khatulistiwa' },
        { title: 'Kewajiban Siswa Terhadap Fasilitas Sekolah', subtitle: 'Merawat buku perpustakaan dan bangku belajar', cat: 'Tanggung Jawab', fact: 'Menjaga kebersihan sekolah membuat semua siswa betah belajar sampai sore!', summary: 'Tidak mencoret meja, mengembalikan buku tepat waktu, dan menyiram toilet bersih.', samplePrompt: 'Tidak mencoret-coret dinding sekolah adalah bentuk...', sampleAns: 'Kewajiban merawat fasilitas' },
        { title: 'Keragaman Budaya Rumah Adat dan Pakaian Daerah', subtitle: 'Rumah Gadang, Tongkonan, Joglo, dan Honai', cat: 'Bhinneka Tunggal Ika', fact: 'Rumah Gadang Minangkabau memiliki atap melengkung runcing seperti tanduk kerbau!', summary: 'Keunikan arsitektur rumah adat tahan gempa karya leluhur nusantara.', samplePrompt: 'Rumah adat khas suku Minangkabau di Sumatera Barat adalah...', sampleAns: 'Rumah Gadang' },
        { title: 'Praktik Gotong Royong di Lingkungan RT/RW', subtitle: 'Kerja bakti membersihkan selokan dan pos ronda', cat: 'Kemasyarakatan', fact: 'Budaya sambatan dan gugur gunung adalah nama lokal tradisi gotong royong di Jawa!', summary: 'Peran warga dalam menjaga keamanan siskamling dan kebersihan lingkungan rukun tetangga.', samplePrompt: 'Tradisi gotong royong membersihkan desa disebut...', sampleAns: 'Kerja bakti' },
        { title: 'Keadilan Sosial bagi Seluruh Rakyat (Sila ke-5)', subtitle: 'Padi dan Kapas untuk kemakmuran bersama', cat: 'Keadilan Sosial', fact: 'Padi melambangkan ketersediaan pangan dan kapas melambangkan pakaian yang cukup!', summary: 'Gaya hidup hemat, gemar menabung, dan suka menghargai hasil karya orang lain.', samplePrompt: 'Simbol Sila ke-5 Keadilan Sosial adalah...', sampleAns: 'Padi dan Kapas' }
      ],
      4: [
        { title: 'Makna Sila-Sila Pancasila dalam Kehidupan Sehari-hari', subtitle: 'Integrasi nilai ketuhanan, kemanusiaan, dan persatuan', cat: 'Ideologi Bangsa', fact: 'Pancasila disahkan pada tanggal 18 Agustus 1945 oleh PPKI!', summary: 'Mengamalkan nilai kelima sila secara utuh dan tidak terpisah-pisah.', samplePrompt: 'Pancasila lahir dan disahkan sebagai dasar negara pada tahun...', sampleAns: '1945' },
        { title: 'Norma Agama, Norma Kesusilaan, dan Norma Hukum', subtitle: 'Pedoman bertingkah laku dalam masyarakat', cat: 'Norma Hukum', fact: 'Norma hukum memiliki sanksi tegas dan mengikat yang ditegakkan oleh aparat kepolisian!', summary: 'Membedakan norma agama dari Tuhan, kesusilaan dari hati nurani, dan hukum negara.', samplePrompt: 'Norma yang bersumber dari hati nurani manusia disebut...', sampleAns: 'Norma kesusilaan' },
        { title: 'Kearifan Lokal dan Budaya Menjaga Hutan Adat', subtitle: 'Hutan larangan dan tradisi Sasi di Maluku', cat: 'Kearifan Lokal', fact: 'Tradisi Sasi di Maluku melarang penangkapan ikan di waktu tertentu agar laut tetap lestari!', summary: 'Hukum adat tradisional yang melindungi hutan dan laut dari kerusakan.', samplePrompt: 'Tradisi larangan mengambil hasil laut sebelum waktunya di Maluku adalah...', sampleAns: 'Tradisi Sasi' },
        { title: 'Musyawarah untuk Mufakat dalam Menghadapi Masalah', subtitle: 'Mengutamakan kepentingan bersama di atas golongan', cat: 'Demokrasi Pancasila', fact: 'Musyawarah menghindari voting tergesa-gesa dengan mencari titik temu yang adil.', summary: 'Etika mendengarkan lawan bicara dan lapang dada menerima hasil mufakat bersama.', samplePrompt: 'Tujuan utama musyawarah adalah mencapai...', sampleAns: 'Mufakat bersama' },
        { title: 'Menjaga Keutuhan Negara Kesatuan Republik Indonesia (NKRI)', subtitle: 'Wawasan nusantara dari Sabang sampai Merauke', cat: 'Wawasan Kebangsaan', fact: 'Deklarasi Djuanda 1957 menyatukan wilayah laut nusantara menjadi kedaulatan utuh Indonesia!', summary: 'Bangga memakai produk buatan Indonesia dan menjaga persatuan antarpulau.', samplePrompt: 'Bentuk negara Indonesia sesuai UUD 1945 adalah...', sampleAns: 'Negara Kesatuan' }
      ],
      5: [
        { title: 'Sejarah Perumusan Pancasila oleh Tokoh Bangsa', subtitle: 'Sidang BPUPKI dan Piagam Jakarta', cat: 'Sejarah Konstitusi', fact: 'Pidato Ir. Soekarno pada 1 Juni 1945 menandai lahirnya istilah Pancasila!', summary: 'Gagasan Mohammad Yamin, Mr. Soepomo, dan Ir. Soekarno dalam merumuskan dasar negara.', samplePrompt: 'Istilah Pancasila pertama kali disampaikan Bung Karno pada tanggal...', sampleAns: '1 Juni 1945' },
        { title: 'Nilai Kemanusiaan yang Adil dan Beradab (Sila ke-2)', subtitle: 'Menentang penjajahan dan perundungan (bullying)', cat: 'Hak Asasi Manusia', fact: 'UUD 1945 menyatakan bahwa penjajahan di atas dunia harus dihapuskan!', summary: 'Menolak perilaku perundungan di sekolah dan membela teman yang diperlakukan tidak adil.', samplePrompt: 'Perilaku mengejek dan menindas teman di sekolah disebut...', sampleAns: 'Perundungan (Bullying)' },
        { title: 'Tanggung Jawab sebagai Warga Negara Indonesia', subtitle: 'Taat membayar pajak, menjaga fasilitas umum, dan bela negara', cat: 'Kewargaan', fact: 'Pajak yang dibayar rakyat digunakan untuk membangun jalan tol, jembatan, dan sekolah gratis!', summary: 'Hubungan timbal balik antara hak warga negara dan kewajiban membela tanah air.', samplePrompt: 'Membayar pajak tepat waktu adalah wujud...', sampleAns: 'Kewajiban warga negara' },
        { title: 'Sistem Pemerintahan Desa dan Kelurahan', subtitle: 'Kepala Desa, BPD, dan pelayanan masyarakat', cat: 'Tata Kelola Desa', fact: 'Dana Desa diberikan langsung oleh pemerintah pusat untuk kemakmuran warga pelosok!', summary: 'Struktur kepemimpinan desa yang dekat dengan kehidupan rakyat sehari-hari.', samplePrompt: 'Pemimpin tertinggi di lingkungan sebuah desa adalah...', sampleAns: 'Kepala Desa' },
        { title: 'Semangat Sumpah Pemuda 28 Oktober 1928', subtitle: 'Satu nusa, satu bangsa, dan satu bahasa Indonesia', cat: 'Sejarah Pergerakan', fact: 'Kongres Pemuda II melahirkan ikrar persatuan yang menyatukan Jong Java, Jong Sumatranen, dll!', summary: 'Meneladani ikrar pemuda 1928 untuk memperkokoh bahasa Indonesia sebagai perekat bangsa.', samplePrompt: 'Hari Sumpah Pemuda diperingati setiap tanggal...', sampleAns: '28 Oktober' }
      ],
      6: [
        { title: 'Pancasila sebagai Pandangan Hidup Bangsa dan Ideologi Terbuka', subtitle: 'Pedoman moral menghadapi era globalisasi modern', cat: 'Filsafat Pancasila', fact: 'Pancasila mampu menyaring budaya asing yang negatif tanpa kehilangan jati diri bangsa!', summary: 'Pancasila sebagai sumber dari segala sumber hukum dan filter kemajuan zaman.', samplePrompt: 'Pancasila berfungsi sebagai sumber dari segala sumber...', sampleAns: 'Hukum negara' },
        { title: 'Undang-Undang Dasar 1945 sebagai Hukum Dasar Tertinggi', subtitle: 'Pembukaan UUD 1945 dan pokok-pokok pikiran kemerdekaan', cat: 'Hukum Konstitusi', fact: 'Pembukaan UUD 1945 memuat tujuan nasional negara Indonesia yang abadi!', summary: 'Makna 4 alinea pembukaan UUD 1945 dalam melindungi segenap tumpah darah Indonesia.', samplePrompt: 'Tujuan nasional negara Indonesia termaktub dalam Pembukaan UUD 1945 alinea ke...', sampleAns: 'Alinea ke-4' },
        { title: 'Lembaga-Lembaga Negara Republik Indonesia', subtitle: 'Presiden, DPR, DPD, MPR, MA, MK, dan BPK', cat: 'Sistem Ketatanegaraan', fact: 'Mahkamah Konstitusi bertugas menguji undang-undang agar tidak bertentangan dengan UUD 1945!', summary: 'Tugas eksekutif, legislatif, dan yudikatif dalam menjalankan roda pemerintahan demokrasi.', samplePrompt: 'Lembaga negara yang bertugas membuat undang-undang bersama presiden adalah...', sampleAns: 'DPR' },
        { title: 'Hak Asasi Manusia (HAM) dan Perlindungan Anak', subtitle: 'Hak hidup, tumbuh kembang, dan bebas dari kekerasan', cat: 'HAM & Perlindungan', fact: 'Setiap anak berhak mendapatkan nama, identitas kebangsaan, dan kasih sayang keluarga!', summary: 'Konvensi Hak Anak PBB dan Undang-Undang Perlindungan Anak di Indonesia.', samplePrompt: 'Hak anak untuk bersekolah dan menuntut ilmu termasuk hak...', sampleAns: 'Hak pendidikan' },
        { title: 'Peran Indonesia dalam Menciptakan Perdamaian Dunia', subtitle: 'Politik Luar Negeri Bebas Aktif dan Pasukan Garuda', cat: 'Hubungan Dunia', fact: 'Pasukan Perdamaian Garuda Indonesia telah bertugas di puluhan negara konflik dunia!', summary: 'Prinsip Bebas Aktif: tidak memihak blok manapun dan selalu aktif menjaga perdamaian dunia.', samplePrompt: 'Prinsip politik luar negeri bangsa Indonesia adalah politik...', sampleAns: 'Bebas dan Aktif' }
      ]
    },
    bahasa_inggris: {
      1: [
        { title: 'Alphabet and Cheerful Phonics', subtitle: 'Singing A-B-C with smiling friends', cat: 'Basic Phonics', fact: 'The English alphabet has 26 letters from A to Z!', summary: 'Learning English alphabet pronunciation and cheerful letter sounds.', samplePrompt: 'The first letter of the alphabet is...', sampleAns: 'Letter A' },
        { title: 'Colors of the Rainbow', subtitle: 'Red, yellow, green, blue, purple, and orange', cat: 'Colors', fact: 'Red and yellow mixed together make bright orange!', summary: 'Identifying English colors of apples, sky, grass, and sunflowers.', samplePrompt: 'What color is an apple?', sampleAns: 'Red' },
        { title: 'Counting Numbers 1 to 10', subtitle: 'One, two, three, four, five, six, seven, eight, nine, ten', cat: 'Numbers', fact: 'Ten fingers make counting super fast and easy!', summary: 'Counting everyday toys and classroom objects in English.', samplePrompt: 'What number comes after eight?', sampleAns: 'Nine' },
        { title: 'My Cheerful Family', subtitle: 'Father, mother, brother, sister, and baby', cat: 'Family', fact: 'A happy family is the greatest blessing in our life!', summary: 'Introducing family members with loving English words.', samplePrompt: '"Ibu" in English is...', sampleAns: 'Mother' },
        { title: 'School Things in My Backpack', subtitle: 'Book, pencil, eraser, ruler, and bag', cat: 'Classroom', fact: 'Books are magic doors to exciting new worlds!', summary: 'Naming classroom stationery: "This is my blue pencil".', samplePrompt: '"Buku" in English is...', sampleAns: 'Book' }
      ],
      2: [
        { title: 'Greetings and Polite Expressions', subtitle: 'Good morning, good afternoon, and thank you', cat: 'Speaking', fact: 'Saying "please" and "thank you" makes friends everywhere you go!', summary: 'Practicing polite daily greetings with teachers and classmates.', samplePrompt: 'When you wake up in the morning, you say...', sampleAns: 'Good morning' },
        { title: 'Cute Animals at the Zoo', subtitle: 'Cat, dog, rabbit, elephant, lion, and giraffe', cat: 'Animals', fact: 'Giraffes have very long necks to eat fresh green leaves high in trees!', summary: 'Animal names, sounds, and actions in English.', samplePrompt: 'An animal with a long trunk is an...', sampleAns: 'Elephant' },
        { title: 'Yummy Fruits and Vegetables', subtitle: 'Banana, orange, apple, carrot, and tomato', cat: 'Food', fact: 'Eating fruits gives you vitamins to run fast and stay strong!', summary: 'Expressing likes: "I like sweet bananas and fresh apples".', samplePrompt: '"Pisang" in English is...', sampleAns: 'Banana' },
        { title: 'Parts of the Body', subtitle: 'Head, shoulders, knees, toes, eyes, ears, and nose', cat: 'Body', fact: 'Our heart beats over 100,000 times a day to pump fresh blood!', summary: 'Singing head, shoulders, knees and toes with energetic movements.', samplePrompt: 'You smell sweet flowers with your...', sampleAns: 'Nose' },
        { title: 'My Cozy Bedroom', subtitle: 'Bed, pillow, blanket, lamp, and clock', cat: 'Home', fact: 'A neat and tidy bedroom helps you sleep sweetly every night!', summary: 'Describing bedroom furniture and bedtime habits.', samplePrompt: 'You sleep at night on a comfortable...', sampleAns: 'Bed' }
      ],
      3: [
        { title: 'Daily Activities and Clock Time', subtitle: 'Telling time: "It is seven oclock in the morning"', cat: 'Daily Routine', fact: 'One hour has exactly 60 minutes and 3,600 seconds!', summary: 'Describing wake up, take a bath, study at school, and sleep time.', samplePrompt: 'Pukul 07.00 tepat dalam bahasa Inggris adalah...', sampleAns: 'Seven oclock' },
        { title: 'Days of the Week and Months', subtitle: 'Monday to Sunday, January to December', cat: 'Calendar', fact: 'Sunday is named after the bright shining sun!', summary: 'Naming the 7 days of the week and 12 calendar months.', samplePrompt: 'The day after Friday is...', sampleAns: 'Saturday' },
        { title: 'Weather and Four Seasons Around the World', subtitle: 'Sunny, rainy, cloudy, windy, and snowy', cat: 'Weather', fact: 'Indonesia has two tropical seasons: rainy season and dry season!', summary: 'Talking about daily weather and outdoor clothing.', samplePrompt: 'When it is raining outside, you need an...', sampleAns: 'Umbrella' },
        { title: 'My Favorite Hobbies and Sports', subtitle: 'Swimming, reading books, playing football, and drawing', cat: 'Hobbies', fact: 'Playing sports with friends builds teamwork and a healthy heart!', summary: 'Asking friends: "What is your hobby? My hobby is reading".', samplePrompt: '"Bermain sepak bola" in English is...', sampleAns: 'Playing football' },
        { title: 'Describing Things with Adjectives', subtitle: 'Big vs small, tall vs short, clean vs dirty', cat: 'Adjectives', fact: 'Opposite words make our English descriptions colorful and vivid!', summary: 'Using pairs of opposite adjectives to describe everyday objects.', samplePrompt: 'The opposite of "BIG" is...', sampleAns: 'Small' }
      ],
      4: [
        { title: 'Simple Present Tense for Daily Habits', subtitle: 'I eat, he eats, she walks, we study English', cat: 'Grammar', fact: 'In English, we add -s or -es when talking about he, she, or it!', summary: 'Forming positive, negative, and interrogative habit sentences.', samplePrompt: 'He [ ? ] to school by bicycle every morning (go / goes)', sampleAns: 'goes' },
        { title: 'Places in the City and Giving Directions', subtitle: 'Hospital, school, bank, market, and turn left / right', cat: 'City Life', fact: 'Maps have north arrows at the top to guide travelers accurately!', summary: 'Asking for directions: "Where is the library? Turn right and go straight".', samplePrompt: 'A place where doctors treat sick people is a...', sampleAns: 'Hospital' },
        { title: 'Occupations and Dream Jobs', subtitle: 'Teacher, doctor, pilot, engineer, and firefighter', cat: 'Jobs', fact: 'Pilots fly airplanes across oceans and clouds to distant countries!', summary: 'Talking about future dreams: "When I grow up, I want to be a doctor".', samplePrompt: 'A person who flies airplanes is a...', sampleAns: 'Pilot' },
        { title: 'Ordering Food and Drinks at a Restaurant', subtitle: 'Menu, delicious soup, fried rice, and orange juice', cat: 'Dining', fact: 'Indonesian fried rice (nasi goreng) is ranked among the worlds tastiest foods!', summary: 'Polite ordering: "Could I have fried rice and iced tea, please?"', samplePrompt: 'To order food politely, you say: "May I [ ? ] fried rice"', sampleAns: 'have' },
        { title: 'Prepositions of Place (In, On, Under, Beside)', subtitle: 'Locating objects in the classroom and room', cat: 'Grammar', fact: 'Prepositions tell us exactly where something is hiding!', summary: 'Describing positions: "The cat is under the wooden table".', samplePrompt: 'The book is [ ? ] the table (di atas meja)', sampleAns: 'on' }
      ],
      5: [
        { title: 'Degrees of Comparison: Comparative & Superlative', subtitle: 'Fast, faster, fastest; beautiful, more beautiful, most beautiful', cat: 'Grammar', fact: 'The cheetah is the fastest land animal on planet earth!', summary: 'Comparing animals and places using -er / -est and more / most.', samplePrompt: 'An elephant is [ ? ] than a rabbit (big / bigger / biggest)', sampleAns: 'bigger' },
        { title: 'Talking About Past Events (Simple Past Tense)', subtitle: 'Regular verbs (-ed) and irregular verbs (went, saw, ate)', cat: 'Grammar', fact: 'Stories in books are mostly written in the past tense because they already happened!', summary: 'Telling vacation stories: "Yesterday, I went to Borobudur Temple".', samplePrompt: 'The past tense of "GO" is...', sampleAns: 'went' },
        { title: 'Saving Our Planet: Go Green and Recycling', subtitle: 'Reduce plastic waste, save water, and plant trees', cat: 'Environment', fact: 'Reusing canvas shopping bags saves hundreds of plastic bags every year!', summary: 'Environmental vocabulary: pollution, reuse, recycle, renewable energy.', samplePrompt: 'To save electricity, we must turn [ ? ] the lights when leaving', sampleAns: 'off' },
        { title: 'Reading Short Fables and Moral Stories', subtitle: 'The Ant and the Grasshopper; The Lion and the Mouse', cat: 'Reading', fact: 'Aesops fables have been translated into hundreds of world languages!', summary: 'Identifying main characters, problem, and moral lessons in English.', samplePrompt: 'In fables, the hard-working insect that saves food is the...', sampleAns: 'Ant' },
        { title: 'Writing Simple Procedural Recipes in English', subtitle: 'How to make a delicious cup of sweet tea', cat: 'Writing', fact: 'Step-by-step transition words: First, Next, Then, and Finally!', summary: 'Writing ingredients and numbered instructions clearly.', samplePrompt: 'The first word to start a recipe step is usually...', sampleAns: 'First' }
      ],
      6: [
        { title: 'Future Plans with "Will" and "Going To"', subtitle: 'What will you do after graduating from elementary school?', cat: 'Future Tense', fact: 'Planning your future with good habits helps achieve your greatest dreams!', summary: 'Expressing goals: "I will study hard to enter my dream junior high school".', samplePrompt: 'I [ ? ] study hard for my examination tomorrow (will / did)', sampleAns: 'will' },
        { title: 'Present Perfect Tense for Life Experiences', subtitle: 'I have visited Bali; Have you ever seen a Komodo dragon?', cat: 'Grammar', fact: 'Komodo dragons are the largest living lizards in the world and only exist in Indonesia!', summary: 'Using have/has + verb 3 to talk about experiences and achievements.', samplePrompt: 'Have you ever [ ? ] to Raja Ampat? (be / been / was)', sampleAns: 'been' },
        { title: 'Writing Formal Emails and Personal Letters', subtitle: 'Greeting, body paragraphs, and polite sign-off', cat: 'Communication', fact: 'Email etiquette teaches us to be clear, respectful, and spell words correctly!', summary: 'Writing: "Dear Penpal, How are you? Best regards, Boni".', samplePrompt: 'A polite closing for a friendly letter is "Best [ ? ]"', sampleAns: 'regards' },
        { title: 'Describing Wonders of Indonesia to International Friends', subtitle: 'Komodo Island, Raja Ampat, Lake Toba, and Mount Bromo', cat: 'Tourism', fact: 'Raja Ampat contains 75% of all known coral species on earth!', summary: 'Promoting Indonesian natural beauty to global tourists with rich adjectives.', samplePrompt: 'Raja Ampat is famous for its breathtaking coral...', sampleAns: 'reefs' },
        { title: 'Expressing Opinions and Agreeing / Disagreeing', subtitle: '"In my opinion...", "I totally agree with your point"', cat: 'Discussion', fact: 'Polite debates help us look at problems from many different angles!', summary: 'Sharing perspectives respectfully in English classroom discussions.', samplePrompt: 'When you share your thought, you say: "In my [ ? ]"', sampleAns: 'opinion' }
      ]
    },
    seni_budaya: {
      1: [
        { title: 'Mengenal Tiga Warna Primer', subtitle: 'Merah, kuning, dan biru', cat: 'Seni Rupa', fact: 'Warna primer tidak bisa dibuat dari campuran warna lain karena mereka adalah warna murni!', summary: 'Bereksperimen mencampur cat air merah + kuning menjadi jingga, kuning + biru menjadi hijau.', samplePrompt: 'Campuran warna kuning dan biru menghasilkan warna...', sampleAns: 'Hijau' },
        { title: 'Menggambar Garis Lurus dan Garis Lengkung', subtitle: 'Pondasi dasar menggambar bentuk alam', cat: 'Seni Rupa', fact: 'Semua gambar di dunia berawal dari goresan titik dan garis sederhana!', summary: 'Melatih keluwesan jari tangan membuat garis lurus, zig-zag, spiral, dan lengkung.', samplePrompt: 'Garis yang berbelok-belok tajam ke kiri dan kanan disebut garis...', sampleAns: 'Zig-zag' },
        { title: 'Bernyanyi Lagu Anak Nasional Ceria', subtitle: 'Pelangi-Pelangi, Bintang Kecil, dan Balonku', cat: 'Seni Musik', fact: 'Pak Kasur dan A.T. Mahmud adalah pencipta lagu anak legendaris Indonesia!', summary: 'Menyanyikan lagu anak dengan birama dan ketukan tepuk tangan yang kompak.', samplePrompt: 'Lagu "Pelangi-Pelangi" diciptakan oleh tokoh bernama...', sampleAns: 'A.T. Mahmud' },
        { title: 'Menirukan Gerak Hewan dan Alam (Tari Dasar)', subtitle: 'Gerak kupu-kupu terbang dan katak melompat', cat: 'Seni Tari', fact: 'Tarian anak-anak mengekspresikan kegembiraan alam melalui gerak tubuh yang lincah!', summary: 'Menari menirukan kepakan sayap burung dan tiupan angin sepoi-sepoi.', samplePrompt: 'Gerak melompat-lompat dengan lincah menirukan gerakan hewan...', sampleAns: 'Katak atau kelinci' },
        { title: 'Membuat Kolase dari Kertas Warna dan Daun Kering', subtitle: 'Menempel potongan kertas membentuk gambar indah', cat: 'Kriya & Kerajinan', fact: 'Kolase memanfaatkan bahan daur ulang daun kering menjadi lukisan bernilai seni tinggi!', summary: 'Teknik merobek, menggunting, dan merekatkan lem kertas pada pola gambar.', samplePrompt: 'Seni menempelkan potongan bahan pada pola gambar disebut seni...', sampleAns: 'Kolase' }
      ],
      2: [
        { title: 'Mengenal Warna Sekunder dan Lingkaran Warna', subtitle: 'Jingga, hijau, dan ungu hasil pencampuran', cat: 'Seni Rupa', fact: 'Merah dicampur biru akan menghasilkan warna ungu anggur yang megah!', summary: 'Mempelajari lingkaran warna dan gradasi warna pelangi.', samplePrompt: 'Warna ungu didapat dari percampuran warna...', sampleAns: 'Merah dan biru' },
        { title: 'Membuat Bentuk Tiga Dimensi dari Plastisin (Lilin Mainan)', subtitle: 'Membuat miniatur buah-buahan dan hewan lucu', cat: 'Seni Patung', fact: 'Plastisin bisa dibentuk berulang kali karena memiliki sifat elastis dan liat!', summary: 'Teknik memilin, meremas, memipihkan, dan menyambung plastisin menjadi patung mini.', samplePrompt: 'Karya seni yang memiliki panjang, lebar, dan tinggi disebut karya...', sampleAns: 'Tiga dimensi (3D)' },
        { title: 'Alat Musik Ritmis dan Melodis Sederhana', subtitle: 'Gendang, tamborin, marakas, dan pianika', cat: 'Seni Musik', fact: 'Alat musik ritmis tidak bernada, fungsinya menjaga ketukan irama lagu!', summary: 'Membedakan alat musik petik, pukul, dan tiup serta memainkannya secara ritmis.', samplePrompt: 'Alat musik yang dimainkan dengan cara dipukul untuk menjaga irama adalah...', sampleAns: 'Gendang / Tamborin' },
        { title: 'Mengenal Tarian Tradisional Daerah Nusantara', subtitle: 'Tari Saman, Tari Piring, dan Tari Jaipong', cat: 'Seni Tari', fact: 'Tari Saman dari Aceh sangat terkenal di dunia dengan kekompakan tepukan dada yang cepat!', summary: 'Mengenal busana tari tradisional dan makna gerakan penghormatan.', samplePrompt: 'Tari Saman yang dilakukan secara duduk kompak berasal dari daerah...', sampleAns: 'Aceh' },
        { title: 'Membuat Anyaman Kertas Dua Warna', subtitle: 'Pola anyaman selang-seling yang rapi', cat: 'Kriya Tradisional', fact: 'Anyaman adalah warisan leluhur nusantara untuk membuat tikar, topi, dan keranjang!', summary: 'Langkah memotong pita kertas dan menyisipkannya dengan pola satu atas satu bawah.', samplePrompt: 'Kerajinan menyilangkan helai kertas secara teratur disebut seni...', sampleAns: 'Anyaman' }
      ],
      3: [
        { title: 'Menggambar Dekoratif Ornamen Motif Nusantara', subtitle: 'Motif batik kawung dan tumpal nusantara', cat: 'Seni Rupa Dekoratif', fact: 'Batik Indonesia telah diakui UNESCO sebagai warisan budaya tak benda dunia!', summary: 'Menggambar ragam hias geometris dan flora fauna khas daerah.', samplePrompt: 'Ragam hias batik yang berbentuk lingkaran empat kelopak teratur adalah motif...', sampleAns: 'Kawung' },
        { title: 'Tangga Nada Diatonis Mayor dan Minor', subtitle: 'Lagu riang gembira vs lagu haru syahdu', cat: 'Teori Musik', fact: 'Lagu bertangga nada mayor biasanya diawali dan diakhiri dengan nada Do!', summary: 'Menyanyikan solmisasi Do-Re-Mi-Fa-Sol-La-Si-Do dan membedakan tempo lagu.', samplePrompt: 'Lagu yang bersemangat dan riang gembira biasanya bertangga nada...', sampleAns: 'Diatonis Mayor' },
        { title: 'Gerak Tari Menggunakan Properti Kipas dan Piring', subtitle: 'Keindahan tari berproperti panggung', cat: 'Seni Tari', fact: 'Penari Tari Piring asal Minangkabau mengayunkan piring porselen tanpa pernah terjatuh!', summary: 'Melatih keseimbangan memegang properti tari selaras dengan alunan musik pengiring.', samplePrompt: 'Tari Piring menggunakan properti utama berupa...', sampleAns: 'Piring' },
        { title: 'Membuat Karya Seni Mozaik Kepingan Bahan', subtitle: 'Menyusun pecahan keramik, cangkang telur, atau biji-bijian', cat: 'Kriya Kreatif', fact: 'Mozaik cangkang telur yang divernis bisa menghasilkan efek retakan marmer alami!', summary: 'Teknik menata kepingan kecil bahan sejenis pada bidang datar dengan lem perekat.', samplePrompt: 'Seni menempelkan kepingan bahan kecil sejenis disebut...', sampleAns: 'Mozaik' },
        { title: 'Menyanyikan Lagu Daerah Nusantara dengan Harmoni', subtitle: 'Ampar-Ampar Pisang, Yamko Rambe Yamko, dan Bungong Jeumpa', cat: 'Musik Nusantara', fact: 'Lagu Ampar-Ampar Pisang menceritakan pembuatan kue pisang khas Kalimantan Selatan!', summary: 'Memahami makna lirik lagu daerah dan menyanyikannya dengan pelafalan dialek yang tepat.', samplePrompt: 'Lagu daerah "Ampar-Ampar Pisang" berasal dari provinsi...', sampleAns: 'Kalimantan Selatan' }
      ],
      4: [
        { title: 'Menggambar Ilustrasi Cerita Rakyat (Komik Anak)', subtitle: 'Membuat panel gambar dan balon percakapan', cat: 'Seni Ilustrasi', fact: 'Komik memadukan kekuatan gambar visual dengan cerita teks yang seru!', summary: 'Langkah membuat sketsa tokoh, ekspresi wajah, dan balon kata cerita rakyat.', samplePrompt: 'Tempat meletakkan teks percakapan tokoh komik disebut...', sampleAns: 'Balon kata' },
        { title: 'Mengenal Alat Musik Tradisional Angklung dan Gamelan', subtitle: 'Angklung bambu Jawa Barat dan Gamelan Jawa', cat: 'Alat Musik Nusantara', fact: 'Angklung terbuat dari bambu dan menghasilkan nada merdu saat digetarkan!', summary: 'Cara memainkan angklung (digetar) dan gamelan (ditabuh) secara orkestra gotong royong.', samplePrompt: 'Alat musik bambu asal Jawa Barat yang dimainkan dengan digetarkan adalah...', sampleAns: 'Angklung' },
        { title: 'Unsur Ruang, Waktu, dan Tenaga dalam Seni Tari', subtitle: 'Gerak lemah gemulai vs gerak patah-patah perkasa', cat: 'Teori Tari', fact: 'Tenaga yang digunakan penari menentukan kekuatan pesan tarian kepada penonton!', summary: 'Mengeksplorasi level gerak tinggi, sedang, dan rendah dalam koreografi tarian anak.', samplePrompt: 'Gerak tari melompat tinggi berada pada level gerak...', sampleAns: 'Level tinggi' },
        { title: 'Membuat Cetak Sablon Sederhana (Seni Grafis)', subtitle: 'Teknik cap daun dan cetak stensil di kertas', cat: 'Seni Grafis', fact: 'Seni grafis memungkinkan karya digandakan berkali-kali dengan cetakan yang sama!', summary: 'Membuat cap stempel dari pelepah pisang atau umbi wortel bertinta.', samplePrompt: 'Pelepah daun pisang dapat dimanfaatkan untuk membuat teknik cetak...', sampleAns: 'Cetak cap / stempel' },
        { title: 'Apresiasi Karya Seni Lukis Tokoh Indonesia', subtitle: 'Karya lukis Raden Saleh dan Affandi', cat: 'Sejarah Seni', fact: 'Affandi melukis langsung memencet cat dari tube ke kanvas menggunakan jari tangannya!', summary: 'Mengenal lukisan penangkapan Pangeran Diponegoro karya Raden Saleh sang maestro nusantara.', samplePrompt: 'Pelukis legendaris Indonesia beraliran ekspresionisme adalah...', sampleAns: 'Affandi' }
      ],
      5: [
        { title: 'Prinsip Perspektif Satu Titik Hilang', subtitle: 'Menggambar jalan dan lorong rel kereta yang tampak menyempit', cat: 'Seni Gambar Perspektif', fact: 'Teknik perspektif membuat gambar datar di kertas terlihat nyata memiliki kedalaman 3D!', summary: 'Menentukan garis horizon dan titik lenyap saat menggambar gedung dan pemandangan.', samplePrompt: 'Garis batas antara bumi dan langit dalam gambar perspektif disebut...', sampleAns: 'Garis horizon' },
        { title: 'Mengenal Musikalisasi Puisi dan Ansambel Sekolah', subtitle: 'Perpaduan gitar akustik, pianika, dan vokal merdu', cat: 'Pertunjukan Musik', fact: 'Musikalisasi puisi membuat bait sastra terdengar lebih menyentuh hati sanubari pendengar!', summary: 'Menggubah melodi pengiring puisi pahlawan dan memainkannya dalam kelompok ansambel.', samplePrompt: 'Penyajian puisi yang diiringi dengan alunan musik disebut...', sampleAns: 'Musikalisasi puisi' },
        { title: 'Pola Lantai dalam Tari Kelompok Nusantara', subtitle: 'Garis lurus vertikal, horizontal, diagonal, dan lingkaran', cat: 'Koreografi Tari', fact: 'Pola lantai Tari Saman adalah garis horizontal lurus yang melambangkan kesetaraan!', summary: 'Merancang formasi perubahan pola lantai agar pertunjukan tari tampak memukau.', samplePrompt: 'Formasi penari yang berbaris menyamping lurus disebut pola lantai...', sampleAns: 'Horizontal' },
        { title: 'Seni Kriya Batik Celup Ikat (Jumputan)', subtitle: 'Membuat motif kain pelangi dengan kelereng dan karet', cat: 'Kriya Tekstil', fact: 'Batik jumputan Palembang menghasilkan corak lingkaran pelangi yang cerah mempesona!', summary: 'Teknik mengikat kain katun putih dengan karet gelang lalu dicelup ke pewarna tekstil.', samplePrompt: 'Kain yang diikat dengan karet lalu dicelup pewarna disebut batik...', sampleAns: 'Jumputan' },
        { title: 'Membuat Maket Arsitektur Rumah Tradisional 3D', subtitle: 'Bahan kardus bekas, lidi, dan stik es krim', cat: 'Kriya Arsitektur', fact: 'Membuat maket melatih kemampuan spasial dan ketelitian tangan calon arsitek cilik!', summary: 'Merancang denah skala, memotong kardus presisi, dan merangkai miniatur rumah panggung.', samplePrompt: 'Miniatur tiga dimensi sebuah bangunan disebut...', sampleAns: 'Maket' }
      ],
      6: [
        { title: 'Membuat Poster Bertema Peduli Lingkungan dan Pendidikan', subtitle: 'Kombinasi slogan singkat dan ilustrasi memikat', cat: 'Desain Komunikasi Visual', fact: 'Poster yang baik menarik perhatian mata dalam 3 detik pertama saat dilihat!', summary: 'Prinsip tata letak poster: kontras warna, keterbacaan huruf (tipografi), dan pesan persuasif.', samplePrompt: 'Kombinasi gambar dan tulisan ajakan yang dipasang di tempat umum disebut...', sampleAns: 'Poster' },
        { title: 'Mengenal Teater Boneka dan Sandiwara Boneka Tangan', subtitle: 'Naskah cerita, dialog karakter, dan tata panggung', cat: 'Seni Teater', fact: 'Teater boneka telah digunakan ribuan tahun untuk mendongengkan kisah budi pekerti!', summary: 'Membuat panggung boneka mini dari kardus dan membawakan karakter suara yang ekspresif.', samplePrompt: 'Pertunjukan drama yang dimainkan menggunakan boneka disebut...', sampleAns: 'Teater boneka' },
        { title: 'Menganalisis Makna Filosofis Tari Bedhaya dan Tari Kecak', subtitle: 'Keagungan spiritual tari klasik nusantara', cat: 'Apresiasi Tari', fact: 'Tari Kecak Bali ditarikan puluhan pria bertelanjang dada dengan irama suara "Cak-cak-cak"!', summary: 'Meneliti filosofi gerakan tari sakral keraton dan tari pergaulan rakyat nusantara.', samplePrompt: 'Tarian khas Bali yang diiringi paduan suara vokal puluhan pria adalah tari...', sampleAns: 'Tari Kecak' },
        { title: 'Merancang Desain Produk Kemasan Makanan Tradisional', subtitle: 'Kemasan ramah lingkungan daun pisang dan kotak kertas', cat: 'Desain Produk', fact: 'Kemasan daun pisang memberi aroma alami khas yang menggugah selera makan!', summary: 'Merancang label merek, logo produk, informasi gizi, dan wadah higienis untuk jajanan pasar.', samplePrompt: 'Wadah pelindung yang membungkus sebuah produk makanan disebut...', sampleAns: 'Kemasan' },
        { title: 'Pameran Karya Seni Rupa Siswa Sekolah Dasar', subtitle: 'Kurator cilik, tata ruang galeri, dan buku tamu pameran', cat: 'Manajemen Pameran', fact: 'Pameran seni melatih rasa percaya diri siswa untuk menampilkan karya terbaiknya!', summary: 'Mempersiapkan pameran akhir tahun sekolah: menyusun meja pajang, memberi label nama karya.', samplePrompt: 'Kegiatan memajang karya seni agar dilihat dan diapresiasi orang lain disebut...', sampleAns: 'Pameran seni' }
      ]
    },
    agama: {
      1: [
        { title: 'Mengenal Sifat Kasih Sayang Tuhan Yang Maha Esa', subtitle: 'Tuhan Maha Pengasih dan Maha Penyayang', cat: 'Ketuhanan', fact: 'Semua yang ada di langit dan bumi diciptakan Tuhan dengan penuh cinta kasih untuk kita!', summary: 'Mensyukuri napas, tubuh sehat, dan keluarga bahagia sebagai anugerah terindah.', samplePrompt: 'Tuhan menciptakan alam semesta karena memiliki sifat Maha...', sampleAns: 'Pengasih dan Penyayang' },
        { title: 'Adab Berdoa Sebelum Belajar dan Sebelum Makan', subtitle: 'Memohon berkah dan bersyukur setiap saat', cat: 'Ibadah Harian', fact: 'Berdoa sebelum belajar membuat hati tenang dan otak kita mudah mengingat ilmu!', summary: 'Membiasakan berdoa dengan khusyuk mengangkat tangan dan bersuara lembut.', samplePrompt: 'Sebelum makan kita harus selalu membaca...', sampleAns: 'Doa sebelum makan' },
        { title: 'Berbakti dan Berbicara Lemah Lembut Kepada Orang Tua', subtitle: 'Surga di telapak kaki ibu, ayah pahlawan kita', cat: 'Akhlak Mulia', fact: 'Senyuman dan doa orang tua adalah kunci keberkahan hidup setiap anak!', summary: 'Mendengarkan nasehat ibu, mencium tangan ayah saat berangkat sekolah, dan membantu di rumah.', samplePrompt: 'Sikap kita saat diajak berbicara oleh ayah dan ibu adalah...', sampleAns: 'Mendengarkan dengan sopan' },
        { title: 'Menyayangi Saudara dan Teman di Sekolah', subtitle: 'Tidak boleh bertengkar dan suka berbagi mainan', cat: 'Kasih Sayang', fact: 'Anak yang suka menolong teman akan memiliki banyak sahabat sejati di mana pun berada!', summary: 'Berbagi bekal kue, meminjamkan pensil, dan menghibur teman yang sedang bersedih.', samplePrompt: 'Jika melihat teman terjatuh di halaman sekolah, sikap kita adalah...', sampleAns: 'Menolongnya berdiri' },
        { title: 'Menjaga Kebersihan Tubuh Adalah Sebagian dari Iman', subtitle: 'Mandi bersih, menyikat gigi, dan berwudhu / bersuci', cat: 'Kesucian Diri', fact: 'Kebersihan adalah pangkal kesehatan dan dicintai oleh Tuhan Yang Maha Suci!', summary: 'Membiasakan mencuci tangan dengan sabun sebelum makan dan memakai baju yang bersih.', samplePrompt: 'Kebersihan adalah bagian dari...', sampleAns: 'Iman' }
      ],
      2: [
        { title: 'Kejujuran: Mengakui Kesalahan dengan Berani', subtitle: 'Anak jujur disayang Tuhan, orang tua, dan guru', cat: 'Akhlak Terpuji', fact: 'Sekali kita berbohong, kita akan terpaksa berbohong lagi untuk menutupinya. Jadilah anak jujur!', summary: 'Berani berkata sebenarnya saat memecahkan barang dan mengembalikan uang kembalian belanja.', samplePrompt: 'Jika kita tidak sengaja merusakkan barang teman, sikap jujur adalah...', sampleAns: 'Mengakui dan meminta maaf' },
        { title: 'Adab Masuk dan Keluar Rumah Mengucap Salam', subtitle: 'Menebarkan doa kedamaian bagi seisi rumah', cat: 'Adab Keseharian', fact: 'Ucapan salam mendoakan keselamatan, rahmat, dan keberkahan bagi orang yang mendengarnya!', summary: 'Mengucap salam saat mengetuk pintu dan mencopot sepatu dengan rapi di rak sepatu.', samplePrompt: 'Saat hendak masuk ke dalam rumah orang lain, kita harus mengucap...', sampleAns: 'Salam' },
        { title: 'Menghormati Bapak dan Ibu Guru di Sekolah', subtitle: 'Guru adalah orang tua kedua kita yang mendidik dengan tulus', cat: 'Adab Menuntut Ilmu', fact: 'Menghormati guru membuat ilmu yang kita pelajari meresap berkah ke dalam dada!', summary: 'Menyapa guru dengan ramah, mendengarkan saat guru menerangkan, dan mengerjakan tugas tepat waktu.', samplePrompt: 'Orang tua kedua kita saat berada di sekolah adalah...', sampleAns: 'Bapak dan Ibu Guru' },
        { title: 'Menyayangi Hewan Peliharaan dan Tanaman Ciptaan Tuhan', subtitle: 'Memberi makan kucing jalanan dan menyiram bunga', cat: 'Kepedulian Makhluk', fact: 'Seorang wanita diampuni dosanya hanya karena memberi minum anjing yang kehausan di sumur!', summary: 'Tidak menyiksa hewan, tidak memetik bunga sembarangan, dan menjaga kelestarian alam.', samplePrompt: 'Memberi makan kucing peliharaan secara teratur adalah wujud kasih sayang pada...', sampleAns: 'Ciptaan Tuhan' },
        { title: 'Toleransi Menghormati Teman Berbeda Agama', subtitle: 'Hidup rukun dan damai di bumi nusantara', cat: 'Toleransi Beragama', fact: 'Indonesia memiliki semboyan persatuan Bhinneka Tunggal Ika yang menaungi 6 agama resmi!', summary: 'Tidak mengganggu teman yang sedang beribadah dan menjaga ketenangan rumah ibadah.', samplePrompt: 'Sikap kita saat teman sedang melaksanakan ibadah adalah...', sampleAns: 'Menghormati dan tidak berisik' }
      ],
      3: [
        { title: 'Sifat Rendah Hati (Tawadhu) dan Menjauhi Sifat Sombong', subtitle: 'Padi yang berisi semakin merunduk', cat: 'Karakter Mulia', fact: 'Iblis terusir dari surga karena sifat sombong merasa dirinya lebih baik dari yang lain!', summary: 'Tidak menyombongkan kepintaran atau kekayaan orang tua, tetap sederhana dan ramah.', samplePrompt: 'Sikap tidak sombong dan tidak pamer disebut sikap...', sampleAns: 'Rendah hati' },
        { title: 'Pentingnya Berkata Santun dan Menjaga Lisan', subtitle: 'Lidah lebih tajam dari pedang jika tidak dijaga', cat: 'Budi Pekerti', fact: 'Perkataan yang baik adalah sedekah yang mendatangkan pahala dan kedamaian!', summary: 'Menghindari kata-kata kotor, tidak mengejek nama orang tua teman, dan gemar memuji kebaikan.', samplePrompt: 'Perkataan yang baik dan menyenangkan hati orang lain bernilai...', sampleAns: 'Sedekah / Pahala' },
        { title: 'Manfaat Sifat Sabar dan Tabah Menghadapi Ujian', subtitle: 'Sabar saat belajar materi sulit dan saat sakit', cat: 'Ketabahan', fact: 'Orang yang sabar selalu ditemani oleh pertolongan Tuhan dalam setiap kesulitannya!', summary: 'Tidak cepat marah saat kalah dalam permainan dan terus berusaha sampai berhasil.', samplePrompt: 'Sikap tenang dan tidak mudah putus asa saat menghadapi cobaan disebut...', sampleAns: 'Sabar' },
        { title: 'Saling Menolong Tanpa Memandang Suku dan Agama', subtitle: 'Tangan di atas lebih baik daripada tangan di bawah', cat: 'Kedermawanan', fact: 'Membantu orang lain yang kesusahan akan membuka pintu rezeki dan kebahagiaan hati!', summary: 'Menyumbang korban bencana alam, menyisihkan uang saku untuk kotak amal sekolah.', samplePrompt: 'Membantu orang lain yang tertimpa musibah harus dilakukan dengan rasa...', sampleAns: 'Ikhlas dan tulus' },
        { title: 'Menjaga Amanah dan Menepati Janji', subtitle: 'Tanda orang yang beriman dan dipercaya sesama', cat: 'Integritas Diri', fact: 'Nabi Muhammad SAW bergelar Al-Amin yang artinya orang yang sangat dapat dipercaya!', summary: 'Mengembalikan barang yang dititipkan dengan utuh dan selalu menepati janji temu.', samplePrompt: 'Gelar Al-Amin yang disandang Nabi Muhammad memiliki arti...', sampleAns: 'Dapat dipercaya' }
      ],
      4: [
        { title: 'Meneladani Sifat Para Nabi dan Tokoh Berbudi Luhur', subtitle: 'Kisah ketabahan Nabi Nuh, Ibrahim, dan Musa', cat: 'Kisah Teladan', fact: 'Nabi Ibrahim berani mencari kebenaran hakiki dengan akal pikiran yang jernih!', summary: 'Memetik hikmah ketabahan para tokoh nabi dalam menegakkan kebenaran dan keadilan.', samplePrompt: 'Sifat utama para nabi yang patut kita teladani adalah keteguhan dan...', sampleAns: 'Kejujuran' },
        { title: 'Menghindari Sifat Iri Dengki dan Sifat Kikir', subtitle: 'Penyakit hati yang merusak amal kebaikan', cat: 'Penyucian Hati', fact: 'Iri hati seperti api yang memakan kayu bakar, menghanguskan pahala kebaikan kita!', summary: 'Ikut senang saat teman mendapat prestasi dan gemar berbagi rezeki dengan yang membutuhkan.', samplePrompt: 'Perasaan tidak senang melihat orang lain mendapat kenikmatan disebut...', sampleAns: 'Iri dengki' },
        { title: 'Kewajiban Ibadah Shalat / Doa Lima Waktu', subtitle: 'Mendirikan tiang agama dalam kehidupan', cat: 'Rukun Ibadah', fact: 'Ibadah yang teratur melatih disiplin waktu dan menjauhkan diri dari perbuatan buruk!', summary: 'Mengenal waktu-waktu ibadah wajib dan rukun pelaksanaannya secara khusyuk.', samplePrompt: 'Ibadah wajib yang dikerjakan lima kali sehari oleh umat Islam adalah...', sampleAns: 'Shalat' },
        { title: 'Adab Bertetangga dan Memuliakan Tamu', subtitle: 'Tetangga adalah saudara terdekat saat kita membutuhkan bantuan', cat: 'Muamalah Sosial', fact: 'Menyakiti tetangga dengan suara gaduh atau bau sampah dilarang keras oleh agama!', summary: 'Berbagi masakan dengan tetangga sebelah dan menyambut tamu dengan wajah berseri.', samplePrompt: 'Orang yang rumahnya paling dekat dengan rumah kita disebut...', sampleAns: 'Tetangga' },
        { title: 'Bekerja Keras dan Tidak Suka Meminta-minta', subtitle: 'Mencari rezeki yang halal dan barokah', cat: 'Etos Kerja', fact: 'Tangan yang bekerja mencari nafkah halal dicintai oleh Tuhan dan para malaikat!', summary: 'Belajar dengan gigih, mandiri menyiapkan keperluan sekolah, dan tidak bergantung pada orang lain.', samplePrompt: 'Mengerjakan tugas sekolah sendiri dengan sungguh-sungguh adalah bentuk...', sampleAns: 'Kerja keras dan mandiri' }
      ],
      5: [
        { title: 'Makna Puasa dan Menahan Diri dari Hawa Nafsu', subtitle: 'Melatih empati merasakan lapar saudara miskin', cat: 'Ibadah Puasa', fact: 'Puasa menyehatkan organ pencernaan dan melatih ketenangan jiwa manusia!', summary: 'Syarat dan rukun puasa, menahan lapar dahaga, serta menjaga lisan dari pertengkaran.', samplePrompt: 'Tujuan utama ibadah puasa adalah melatih ketakwaan dan...', sampleAns: 'Menahan hawa nafsu' },
        { title: 'Kewajiban Zakat, Infaq, dan Sedekah untuk Sesama', subtitle: 'Membersihkan harta dan menyantuni fakir miskin', cat: 'Kedermawanan', fact: 'Zakat fitrah wajib ditunaikan sebelum shalat Idul Fitri untuk membahagiakan kaum dhuafa!', summary: 'Perbedaan zakat wajib dan sedekah sukarela serta 8 golongan penerima zakat.', samplePrompt: 'Zakat yang wajib dikeluarkan setiap bulan Ramadhan disebut zakat...', sampleAns: 'Fitrah' },
        { title: 'Adab Menggunakan Media Sosial dan Menolak Berita Bohong', subtitle: 'Tabayyun (cek kebenaran informasi sebelum percaya)', cat: 'Etika Digital', fact: 'Menyebarkan kabar bohong (fitnah) dosanya lebih kejam daripada pembunuhan!', summary: 'Meneliti sumber berita, tidak menyebarkan aib teman di internet, dan berkata sopan di medsos.', samplePrompt: 'Sikap memeriksa kebenaran suatu berita terlebih dahulu disebut...', sampleAns: 'Tabayyun' },
        { title: 'Menjaga Persaudaraan Umat (Ukhuwah Insaniyah)', subtitle: 'Semua manusia berasal dari satu nenek moyang Adam dan Hawa', cat: 'Persaudaraan', fact: 'Perbedaan warna kulit dan bahasa adalah tanda kebesaran Tuhan yang harus disyukuri!', summary: 'Menjaga kerukunan antarumat beragama dan bersatu padu membangun bangsa Indonesia.', samplePrompt: 'Persaudaraan antarsesama umat manusia disebut ukhuwah...', sampleAns: 'Insaniyah' },
        { title: 'Menghargai Waktu dan Menjauhi Perbuatan Sia-sia', subtitle: 'Demi masa, sesungguhnya manusia berada dalam kerugian', cat: 'Manajemen Waktu', fact: 'Surat Al-Ashr mengingatkan manusia bahwa waktu yang telah berlalu tidak akan pernah kembali!', summary: 'Mengisi waktu luang dengan membaca buku, membantu orang tua, dan memperbanyak amal kebajikan.', samplePrompt: 'Pentingnya memanfaatkan waktu ditegaskan dalam Al-Quran surat...', sampleAns: 'Al-Ashr' }
      ],
      6: [
        { title: 'Mengenal Hari Kiamat dan Pertanggungjawaban Amal', subtitle: 'Menanam kebaikan di dunia untuk menuai surga di akhirat', cat: 'Akidah Rukun Iman', fact: 'Setiap perbuatan sekecil biji zarrah pun akan dicatat dengan teliti oleh malaikat pencatat!', summary: 'Meyakini adanya kehidupan abadi setelah dunia dan termotivasi selalu berbuat jujur.', samplePrompt: 'Malaikat yang bertugas mencatat amal baik manusia adalah malaikat...', sampleAns: 'Raqib' },
        { title: 'Kisah Keteguhan Hati Nabi Ulul Azmi', subtitle: 'Nuh, Ibrahim, Musa, Isa, dan Muhammad SAW', cat: 'Teladan Ulul Azmi', fact: 'Gelar Ulul Azmi diberikan kepada 5 nabi yang memiliki kesabaran dan ketabahan luar biasa!', summary: 'Mempelajari mukjizat dan keteguhan nabi-nabi pilihan dalam menghadapi rintangan dakwah.', samplePrompt: 'Nabi yang memiliki mukjizat selamat dari kobaran api adalah Nabi...', sampleAns: 'Ibrahim AS' },
        { title: 'Menghindari Minuman Keras, Judi, dan Pertengkaran', subtitle: 'Perbuatan keji yang merusak masa depan pemuda', cat: 'Larangan Moral', fact: 'Zat adiktif dan narkoba merusak sel-sel otak secara permanen dan menghancurkan masa depan!', summary: 'Menolak ajakan merokok dan zat berbahaya serta memilih sahabat pergaulan yang baik.', samplePrompt: 'Menghindari narkoba dan miras adalah kewajiban untuk menjaga kesehatan...', sampleAns: 'Akal dan raga' },
        { title: 'Adab Pergaulan Remaja yang Sehat dan Berakhlak', subtitle: 'Menjaga pandangan, menutup aurat, dan menghormati lawan jenis', cat: 'Etika Remaja', fact: 'Masa remaja adalah masa emas untuk mengukir prestasi gemilang!', summary: 'Batasan pergaulan sopan antarlawan jenis dan membentengi diri dengan kegiatan positif.', samplePrompt: 'Menghormati lawan jenis dilakukan dengan bersikap sopan dan menjaga...', sampleAns: 'Pandangan dan kehormatan' },
        { title: 'Membangun Karakter Pemimpin yang Adil dan Melayani', subtitle: 'Pemimpin yang jujur dicintai oleh seluruh rakyatnya', cat: 'Kepemimpinan', fact: 'Khalifah Umar bin Khattab sering berkeliling malam memikul gandum untuk rakyat miskin!', summary: 'Ciri pemimpin berakhlak mulia: mengutamakan kepentingan rakyat, berani adil, dan amanah.', samplePrompt: 'Sifat kepemimpinan yang mengutamakan kepentingan rakyat dan adil disebut...', sampleAns: 'Amanah' }
      ]
    }
  };

  const configs = subjectConfigs[subjectId]?.[grade] || [];
  return configs.map((cfg, index) => {
    const chapter = index + 1;
    return {
      id: `${subjectId}_g${grade}_t${chapter}`,
      subjectId,
      grade,
      chapterNumber: chapter,
      title: cfg.title,
      subtitle: cfg.subtitle,
      category: cfg.cat,
      durationMinutes: 6 + chapter,
      funFact: cfg.fact,
      summary: cfg.summary,
      contentParagraphs: [
        `Halo Teman Pintar Kelas ${grade}! Di bab ini kita belajar tentang "${cfg.title}".`,
        cfg.summary + ' Materi ini penting untuk menambah wawasan pengetahuan dan membentuk karakter budi pekerti yang luhur.',
        `Pesan Boni: pelajari dengan hati yang gembira dan terapkan nilai-nilai kebaikan ini dalam pergaulan sehari-hari!`
      ],
      keyPoints: [
        `Pahami inti sari dari ${cfg.title}.`,
        'Praktikkan nilai-nilai luhur ini di rumah dan sekolah.',
        'Jadilah teladan kebaikan bagi teman-temanmu.'
      ],
      illustrations: [
        { emoji: '🌟', title: 'Nilai Karakter', caption: cfg.title },
        { emoji: '📖', title: 'Pengetahuan', caption: cfg.subtitle },
        { emoji: '🤝', title: 'Penerapan', caption: 'Budi pekerti luhur' }
      ],
      examples: [
        {
          question: `Bagaimana cara mengamalkan nilai dari "${cfg.title}" dalam kehidupan sehari-hari?`,
          steps: [
            'Langkah 1: Mengerti tujuan dan hikmah pelajaran.',
            'Langkah 2: Menyadari dampak baik bagi diri sendiri dan sesama.',
            'Langkah 3: Melakukannya secara ikhlas dan konsisten setiap hari.'
          ],
          answer: `Menerapkan pesan ${cfg.title} dengan penuh keikhlasan dan kejujuran.`,
          tip: 'Kebaikan kecil yang dilakukan terus-menerus akan berbuah manis.'
        }
      ],
      exercises: [
        {
          id: `${subjectId}_g${grade}_t${chapter}_ex1`,
          type: 'multiple_choice',
          prompt: cfg.samplePrompt,
          options: [
            cfg.sampleAns,
            'Mengabaikannya begitu saja',
            'Berbuat curang',
            'Menyerah tanpa usaha'
          ],
          correctOptionIndex: 0,
          explanation: `Jawaban yang benar adalah ${cfg.sampleAns}. Hal ini sesuai dengan materi ${cfg.title}.`,
          hint: 'Pilihlah jawaban yang paling terpuji dan tepat.',
          praiseMessage: 'Luar biasa! Pemahamanmu sangat matang!',
          points: 25
        },
        {
          id: `${subjectId}_g${grade}_t${chapter}_ex2`,
          type: 'true_false',
          prompt: `Mengamalkan nilai-nilai ${cfg.title} membawa kedamaian dan kebahagiaan bagi diri dan lingkungan.`,
          isTrue: true,
          explanation: 'Benar! Kebaikan dan ilmu yang diamalkan selalu mendatangkan kedamaian.',
          hint: 'Apakah ilmu yang baik membawa manfaat?',
          praiseMessage: 'Tepat sekali! Hebat!',
          points: 25
        },
        {
          id: `${subjectId}_g${grade}_t${chapter}_ex3`,
          type: 'fill_blank',
          prompt: `Jawaban singkat yang tepat untuk materi ini adalah: [ ? ] (${cfg.sampleAns.split(' ')[0]})`,
          acceptableAnswers: [cfg.sampleAns.split(' ')[0], cfg.sampleAns.toLowerCase()],
          wordBank: [cfg.sampleAns.split(' ')[0], 'salah', 'diam', 'lupa'],
          placeholderText: 'Ketik jawaban...',
          explanation: `Kata yang tepat adalah ${cfg.sampleAns}.`,
          hint: 'Perhatikan kata kunci dari materi.',
          praiseMessage: 'Hebat! Jawabanmu tepat sekali!',
          points: 25
        },
        {
          id: `${subjectId}_g${grade}_t${chapter}_ex4`,
          type: 'matching',
          prompt: 'Jodohkan konsep materi dengan maknanya:',
          pairs: [
            { id: 'p1', leftText: 'Nilai Luhur', leftEmoji: '⭐', rightText: 'Pedoman Budi Pekerti Mulia', rightEmoji: '💎' },
            { id: 'p2', leftText: 'Toleransi Rukun', leftEmoji: '🤝', rightText: 'Saling Menghargai Sesama', rightEmoji: '🕊️' },
            { id: 'p3', leftText: 'Prestasi Juara', leftEmoji: '🏆', rightText: 'Hasil Belajar Sungguh-sungguh', rightEmoji: '🎯' }
          ],
          explanation: 'Nilai luhur adalah pedoman mulia, toleransi menjaga kerukunan, prestasi buah kerja keras.',
          hint: 'Hubungkan konsep dengan maknanya.',
          praiseMessage: 'Sempurna! Kamu memahami seluruh konsep materi!',
          points: 25
        }
      ],
      audioScript: `Selamat datang di pelajaran ${cfg.title} untuk kelas ${grade}. Mari belajar dengan ceria dan penuh semangat bersama Boni!`
    };
  });
}
