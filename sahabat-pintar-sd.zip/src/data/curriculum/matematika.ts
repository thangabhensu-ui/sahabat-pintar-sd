import { Lesson, Grade } from '../../types';

export const MATEMATIKA_LESSONS: Lesson[] = [
  // ================= KELAS 1 =================
  {
    id: 'mat_g1_t1',
    subjectId: 'matematika',
    grade: 1,
    chapterNumber: 1,
    title: 'Mengenal Bilangan 1 Sampai 10',
    subtitle: 'Menghitung jumlah benda di sekitar kita',
    category: 'Bilangan Cacah',
    durationMinutes: 5,
    funFact: 'Angka 0 pertama kali ditemukan dan digunakan secara luas di peradaban timur untuk melambangkan ketiadaan benda!',
    summary: 'Belajar membilang dan menulis lambang bilangan 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 dengan benda konkret.',
    contentParagraphs: [
      'Halo jagoan hitung cilik! Angka ada di mana-mana di sekitar kita.',
      'Ayo hitung jari tangan kananmu:\n1 - Ibu jari\n2 - Telunjuk\n3 - Jari tengah\n4 - Jari manis\n5 - Kelingking',
      'Jika ditambah dengan jari tangan kirimu, semuanya menjadi 10 jari! Menghitung benda nyata membuat belajar matematika jadi sangat asyik.'
    ],
    keyPoints: [
      'Lambang bilangan 1 sampai 10: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10.',
      'Nama bilangan ditulis dengan huruf: satu, dua, tiga, dst.',
      'Hitung benda satu per satu tanpa terlewat.'
    ],
    illustrations: [
      { emoji: '🖐️', title: '5 Jari', caption: 'Satu tangan penuh' },
      { emoji: '🍎', title: 'Apel', caption: 'Benda untuk dihitung' },
      { emoji: '🔟', title: 'Angka 10', caption: 'Dua tangan penuh' }
    ],
    examples: [
      {
        question: 'Boni memiliki 3 balon merah dan 2 balon kuning. Berapa seluruh balon Boni?',
        steps: [
          'Balon merah = 3.',
          'Balon kuning = 2.',
          'Hitung bersama: 1, 2, 3, 4, 5.'
        ],
        answer: '5 buah balon.',
        tip: 'Gabungkan kedua kelompok benda.'
      }
    ],
    exercises: [
      {
        id: 'mat_g1_t1_ex1',
        type: 'multiple_choice',
        prompt: 'Lambang bilangan dari kata "TUJUH" adalah...',
        options: ['5', '6', '7', '8'],
        correctOptionIndex: 2,
        explanation: 'Kata "TUJUH" ditulis dengan angka 7.',
        hint: 'Satu angka setelah angka 6.',
        praiseMessage: 'Pintar sekali! Angka 7 tepat!',
        points: 25
      },
      {
        id: 'mat_g1_t1_ex2',
        type: 'true_false',
        prompt: 'Jumlah jari pada kedua tangan kita yang normal adalah 10.',
        isTrue: true,
        explanation: 'Benar! Tangan kanan memiliki 5 jari dan tangan kiri 5 jari, totalnya 10 jari.',
        hint: 'Hitung jari tanganmu sekarang.',
        praiseMessage: 'Tepat sekali! Hebat!',
        points: 25
      },
      {
        id: 'mat_g1_t1_ex3',
        type: 'fill_blank',
        prompt: 'Lengkapilah urutan angka maju: 1, 2, 3, 4, [ ? ], 6',
        acceptableAnswers: ['5'],
        wordBank: ['5', '7', '8', '0'],
        placeholderText: 'Ketik angka...',
        explanation: 'Setelah angka 4 adalah angka 5.',
        hint: 'Angka di antara 4 dan 6.',
        praiseMessage: 'Hebat! Urutan angkamu tepat!',
        points: 25
      },
      {
        id: 'mat_g1_t1_ex4',
        type: 'matching',
        prompt: 'Jodohkan lambang bilangan dengan nama bilangannya:',
        pairs: [
          { id: 'p1', leftText: '3', leftEmoji: '3️⃣', rightText: 'Tiga', rightEmoji: '🟢' },
          { id: 'p2', leftText: '8', leftEmoji: '8️⃣', rightText: 'Delapan', rightEmoji: '🔵' },
          { id: 'p3', leftText: '10', leftEmoji: '🔟', rightText: 'Sepuluh', rightEmoji: '⭐' }
        ],
        explanation: '3 adalah tiga, 8 adalah delapan, 10 adalah sepuluh.',
        hint: 'Cocokkan angka dan kata.',
        praiseMessage: 'Pasangan sempurna! Luar biasa!',
        points: 25
      }
    ],
    audioScript: 'Satu, dua, tiga, empat, lima, enam, tujuh, delapan, sembilan, sepuluh! Berhitung itu mudah dan menyenangkan bersama Boni.'
  },
  {
    id: 'mat_g1_t2',
    subjectId: 'matematika',
    grade: 1,
    chapterNumber: 2,
    title: 'Penjumlahan Ceria (Hasil Sampai 20)',
    subtitle: 'Konsep menggabungkan dua kumpulan benda',
    category: 'Operasi Hitung',
    durationMinutes: 6,
    funFact: 'Tanda tambah (+) konon berasal dari kata bahasa Latin "et" yang artinya "dan"!',
    summary: 'Memahami arti penjumlahan sebagai penambahan jumlah benda dan menghitung maju.',
    contentParagraphs: [
      'Penjumlahan artinya menyatukan dua kumpulan benda sehingga jumlahnya menjadi lebih banyak.',
      'Simbol penjumlahan adalah tanda tambah (+).\nContoh: 4 pensil + 3 pensil = 7 pensil.',
      'Trik mudah: simpan angka yang lebih besar di dalam pikiranmu, lalu gunakan jarimu untuk menghitung maju!'
    ],
    keyPoints: [
      'Penjumlahan membuat jumlah semakin bertambah.',
      'Simbol (+) dibaca tambah.',
      'Simpan angka besar di kepala, hitung maju angka kecil.'
    ],
    illustrations: [
      { emoji: '➕', title: 'Tanda Tambah', caption: 'Menggabungkan kelompok' },
      { emoji: '🧁', title: 'Kue Manis', caption: '3 + 2 = 5 kue' },
      { emoji: '🧮', title: 'Sempoa', caption: 'Alat bantu berhitung' }
    ],
    examples: [
      {
        question: 'Berapakah hasil dari 8 + 5?',
        steps: [
          'Simpan angka 8 di kepala.',
          'Buka 5 jari di tangan.',
          'Hitung maju dari 8: 9, 10, 11, 12, 13.'
        ],
        answer: '8 + 5 = 13.',
        tip: 'Trik simpan angka besar di kepala sangat cepat!'
      }
    ],
    exercises: [
      {
        id: 'mat_g1_t2_ex1',
        type: 'multiple_choice',
        prompt: 'Hasil dari 6 + 7 adalah...',
        options: ['12', '13', '14', '15'],
        correctOptionIndex: 1,
        explanation: '6 + 7 = 13. Simpan 7 di kepala, hitung maju 6 langkah: 8, 9, 10, 11, 12, 13.',
        hint: '7 ditambah 6.',
        praiseMessage: 'Tepat sekali! 13 adalah jawaban yang benar.',
        points: 25
      },
      {
        id: 'mat_g1_t2_ex2',
        type: 'true_false',
        prompt: 'Hasil dari 9 + 0 tetap sama dengan 9.',
        isTrue: true,
        explanation: 'Benar! Angka berapapun yang ditambah dengan 0 hasilnya tetap angka itu sendiri.',
        hint: 'Menambah dengan nol artinya tidak menambah apa-apa.',
        praiseMessage: 'Pintar! Konsep angka nol kamu kuasai!',
        points: 25
      },
      {
        id: 'mat_g1_t2_ex3',
        type: 'fill_blank',
        prompt: 'Hitunglah penjumlahan ini: 10 + 4 = [ ? ]',
        acceptableAnswers: ['14'],
        wordBank: ['14', '15', '13', '16'],
        placeholderText: 'Ketik hasil angka...',
        explanation: '1 puluhan ditambah 4 satuan menjadi 14.',
        hint: 'Sepuluh ditambah empat.',
        praiseMessage: 'Hebat! Kamu jago berhitung!',
        points: 25
      },
      {
        id: 'mat_g1_t2_ex4',
        type: 'matching',
        prompt: 'Jodohkan soal penjumlahan dengan hasilnya:',
        pairs: [
          { id: 'p1', leftText: '4 + 4', leftEmoji: '➕', rightText: '8', rightEmoji: '🎱' },
          { id: 'p2', leftText: '9 + 3', leftEmoji: '➕', rightText: '12', rightEmoji: '🕛' },
          { id: 'p3', leftText: '10 + 5', leftEmoji: '➕', rightText: '15', rightEmoji: '⭐' }
        ],
        explanation: '4+4=8, 9+3=12, 10+5=15.',
        hint: 'Hitung satu per satu.',
        praiseMessage: 'Semua jawabanmu benar! Keren!',
        points: 25
      }
    ],
    audioScript: 'Penjumlahan membuat benda semakin banyak! Simpan angka besar di kepala, lalu hitung maju dengan jarimu. Ayo latihan!'
  },
  {
    id: 'mat_g1_t3',
    subjectId: 'matematika',
    grade: 1,
    chapterNumber: 3,
    title: 'Pengurangan Mengambil dan Menghitung Mundur',
    subtitle: 'Konsep benda berkurang atau tersisa',
    category: 'Operasi Hitung',
    durationMinutes: 6,
    funFact: 'Dalam pengurangan, angka pertama yang dikurangi harus lebih besar atau sama dengan angka pengurangnya!',
    summary: 'Memahami arti pengurangan menggunakan benda konkret dan menghitung mundur.',
    contentParagraphs: [
      'Pengurangan artinya kita mengambil sebagian benda dari kelompoknya sehingga sisanya menjadi lebih sedikit.',
      'Simbol pengurangan adalah tanda minus (-).\nContoh: Boni punya 8 permen, lalu ia memberikan 3 permen ke adiknya. Sisa permen Boni sekarang adalah 5 permen (8 - 3 = 5).',
      'Kita bisa melakukan pengurangan dengan cara menghitung mundur!'
    ],
    keyPoints: [
      'Pengurangan membuat jumlah menjadi berkurang.',
      'Simbol (-) dibaca kurang.',
      'Gunakan teknik hitung mundur.'
    ],
    illustrations: [
      { emoji: '➖', title: 'Tanda Kurang', caption: 'Mengambil sebagian' },
      { emoji: '🎈', title: 'Balon Pecah', caption: 'Benda berkurang' },
      { emoji: '🍬', title: 'Permen', caption: '8 - 3 = 5 permen' }
    ],
    examples: [
      {
        question: 'Siti membawa 12 kue donat. Sebanyak 4 kue dimakan bersama teman. Berapa sisa donat Siti?',
        steps: [
          'Kue mula-mula = 12.',
          'Kue dimakan = 4.',
          'Hitung mundur 4 langkah dari 12: 11, 10, 9, 8.'
        ],
        answer: '12 - 4 = 8 donat tersisa.',
        tip: 'Hitung mundur perlahan-lahan.'
      }
    ],
    exercises: [
      {
        id: 'mat_g1_t3_ex1',
        type: 'multiple_choice',
        prompt: 'Hasil dari 15 - 5 adalah...',
        options: ['8', '9', '10', '11'],
        correctOptionIndex: 2,
        explanation: '15 - 5 = 10. Jika kita kurangi 5 dari 15, hasilnya pas 10.',
        hint: '15 dikurangi 5.',
        praiseMessage: 'Pintar! Jawabannya pas 10.',
        points: 25
      },
      {
        id: 'mat_g1_t3_ex2',
        type: 'true_false',
        prompt: 'Pengurangan membuat jumlah benda menjadi lebih banyak dari awalnya.',
        isTrue: false,
        explanation: 'Salah! Pengurangan membuat jumlah benda menjadi lebih sedikit atau berkurang.',
        hint: 'Apakah mengambil benda membuat benda bertambah?',
        praiseMessage: 'Tepat sekali! Pengurangan membuat benda berkurang.',
        points: 25
      },
      {
        id: 'mat_g1_t3_ex3',
        type: 'fill_blank',
        prompt: 'Berapakah hasil dari 9 - 4 = [ ? ]',
        acceptableAnswers: ['5'],
        wordBank: ['5', '6', '4', '7'],
        placeholderText: 'Ketik sisa...',
        explanation: '9 dikurangi 4 adalah 5.',
        hint: 'Gunakan 9 jari, lipat 4 jari.',
        praiseMessage: 'Hebat! 5 jari yang tersisa!',
        points: 25
      },
      {
        id: 'mat_g1_t3_ex4',
        type: 'matching',
        prompt: 'Jodohkan soal pengurangan dengan sisa hasilnya:',
        pairs: [
          { id: 'p1', leftText: '10 - 3', leftEmoji: '➖', rightText: '7', rightEmoji: '🎯' },
          { id: 'p2', leftText: '14 - 6', leftEmoji: '➖', rightText: '8', rightEmoji: '🎱' },
          { id: 'p3', leftText: '20 - 10', leftEmoji: '➖', rightText: '10', rightEmoji: '🔟' }
        ],
        explanation: '10-3=7, 14-6=8, 20-10=10.',
        hint: 'Hitung mundur dengan teliti.',
        praiseMessage: 'Sempurna! Penguranganmu sangat teliti!',
        points: 25
      }
    ],
    audioScript: 'Pengurangan artinya benda diambil atau berkurang. Hitung mundur dari angka awal untuk menemukan sisanya. Ayo coba bersama Boni!'
  },
  {
    id: 'mat_g1_t4',
    subjectId: 'matematika',
    grade: 1,
    chapterNumber: 4,
    title: 'Mengenal Bentuk Bangun Datar Dasar',
    subtitle: 'Segitiga, segiempat, dan lingkaran di sekitar kita',
    category: 'Geometri Sederhana',
    durationMinutes: 5,
    funFact: 'Roda sepeda dan mobil berbentuk lingkaran agar dapat berputar menggelinding dengan mulus dan lancar di jalan!',
    summary: 'Mengenal ciri-ciri segitiga (3 sisi), segiempat (4 sisi), dan lingkaran (1 sisi lengkung).',
    contentParagraphs: [
      'Ayo kita amati benda-benda di ruangan kelas dan rumah!',
      '1. LINGKARAN: Tidak memiliki sudut, hanya 1 garis lengkung. Contoh: koin, piring, jam dinding bulat, roda sepeda.\n2. SEGITIGA: Memiliki 3 sisi dan 3 sudut lancip. Contoh: potongan pizza, atap rumah, penggaris segitiga.\n3. SEGIEMPAT (Persegi): Memiliki 4 sisi sama panjang dan 4 sudut. Contoh: ubin lantai, kertas origami, buku tulis.'
    ],
    keyPoints: [
      'Lingkaran tidak memiliki sudut siku-siku.',
      'Segitiga memiliki 3 sisi dan 3 sudut.',
      'Segiempat memiliki 4 sisi dan 4 sudut.'
    ],
    illustrations: [
      { emoji: '⭕', title: 'Lingkaran', caption: 'Tanpa sudut siku' },
      { emoji: '🔺', title: 'Segitiga', caption: '3 sisi lancip' },
      { emoji: '🟦', title: 'Segiempat', caption: '4 sisi datar' }
    ],
    examples: [
      {
        question: 'Piring makan berbentuk bulat melingkar tanpa sudut. Bangun datar apakah piring tersebut?',
        steps: [
          'Bentuknya bulat melingkar.',
          'Tidak memiliki garis patah atau sudut.',
          'Bangun datar tersebut adalah Lingkaran.'
        ],
        answer: 'Lingkaran.',
        tip: 'Seperti bentuk koin logam.'
      }
    ],
    exercises: [
      {
        id: 'mat_g1_t4_ex1',
        type: 'multiple_choice',
        prompt: 'Bangun datar yang memiliki tepat 3 sisi dan 3 sudut adalah...',
        options: ['Lingkaran', 'Segitiga', 'Persegi', 'Kubus'],
        correctOptionIndex: 1,
        explanation: 'Segitiga memiliki 3 sisi dan 3 sudut.',
        hint: 'Nama bangunnya diawali kata "Segi-Tiga".',
        praiseMessage: 'Tepat sekali! Segitiga memiliki 3 sisi.',
        points: 25
      },
      {
        id: 'mat_g1_t4_ex2',
        type: 'true_false',
        prompt: 'Roda sepeda dibuat berbentuk lingkaran agar mudah berputar.',
        isTrue: true,
        explanation: 'Benar! Bentuk lingkaran tidak memiliki sudut tajam sehingga dapat menggelinding dengan lancar.',
        hint: 'Bayangkan jika roda berbentuk kotak!',
        praiseMessage: 'Pintar! Roda lingkaran adalah penemuan hebat.',
        points: 25
      },
      {
        id: 'mat_g1_t4_ex3',
        type: 'fill_blank',
        prompt: 'Ubin lantai ruangan biasanya berbentuk segi [ ? ] (tiga / empat / bulat)',
        acceptableAnswers: ['empat', 'Empat'],
        wordBank: ['empat', 'tiga', 'lima', 'enam'],
        placeholderText: 'Ketik jumlah segi...',
        explanation: 'Ubin keramik lantai memiliki 4 sisi sama panjang (segiempat atau persegi).',
        hint: 'Memiliki 4 sisi sama panjang.',
        praiseMessage: 'Tepat sekali! Segiempat!',
        points: 25
      },
      {
        id: 'mat_g1_t4_ex4',
        type: 'matching',
        prompt: 'Jodohkan benda nyata dengan bentuk bangun datarnya:',
        pairs: [
          { id: 'p1', leftText: 'Koin Uang Logam', leftEmoji: '🪙', rightText: 'Lingkaran', rightEmoji: '⭕' },
          { id: 'p2', leftText: 'Potongan Pizza', leftEmoji: '🍕', rightText: 'Segitiga', rightEmoji: '🔺' },
          { id: 'p3', leftText: 'Papan Tulis Kelas', leftEmoji: '📋', rightText: 'Segiempat', rightEmoji: '🟦' }
        ],
        explanation: 'Koin lingkaran, potongan pizza segitiga, papan tulis segiempat.',
        hint: 'Amati bentuk fisiknya.',
        praiseMessage: 'Luar biasa! Matamu sangat teliti mengenali bentuk!',
        points: 25
      }
    ],
    audioScript: 'Segitiga punya tiga sisi, segiempat punya empat sisi, dan lingkaran melengkung indah tanpa sudut. Ayo cari bentuk-bentuk ini di sekitarmu!'
  },
  {
    id: 'mat_g1_t5',
    subjectId: 'matematika',
    grade: 1,
    chapterNumber: 5,
    title: 'Mengenal Jam dan Satuan Waktu Pagi Siang Malam',
    subtitle: 'Membaca jam dinding bulat tepat waktu',
    category: 'Pengukuran Waktu',
    durationMinutes: 6,
    funFact: 'Dalam satu hari semalam ada 24 jam! Jarum pendek jam berputar penuh mengelilingi angka jam sebanyak 2 kali.',
    summary: 'Mengenal jarum panjang (menit) dan jarum pendek (jam) pada jam analog.',
    contentParagraphs: [
      'Waktu sangat berharga bagi anak yang rajin dan disiplin!',
      'Pada jam dinding ada dua jarum utama:\n- JARUM PENDEK: menunjukkan JAM.\n- JARUM PANJANG: menunjukkan MENIT.',
      'Jika jarum panjang menunjuk tepat ke angka 12, dan jarum pendek menunjuk ke angka 7, itu berarti tepat pukul 07.00 pagi saat kita mulai upacara di sekolah!'
    ],
    keyPoints: [
      'Jarum pendek menunjukkan jam.',
      'Jarum panjang menunjukkan menit.',
      'Jika jarum panjang di angka 12, waktu disebut tepat.',
      'Jadilah anak yang disiplin waktu.'
    ],
    illustrations: [
      { emoji: '⏰', title: 'Jam Analog', caption: 'Jarum penunjuk waktu' },
      { emoji: '🌅', title: 'Pagi Hari', caption: 'Pukul 06.00 pagi' },
      { emoji: '🌙', title: 'Malam Hari', caption: 'Pukul 20.00 tidur' }
    ],
    examples: [
      {
        question: 'Jarum pendek menunjuk angka 3, dan jarum panjang menunjuk angka 12. Pukul berapakah jam tersebut?',
        steps: [
          'Lihat jarum pendek: angka 3.',
          'Lihat jarum panjang: angka 12 (artinya tepat .00).',
          'Jadi jam menunjukkan pukul 03.00 (tiga tepat).'
        ],
        answer: 'Pukul 03.00 (jam tiga tepat).',
        tip: 'Jarum panjang di angka 12 selalu berarti menit 00.'
      }
    ],
    exercises: [
      {
        id: 'mat_g1_t5_ex1',
        type: 'multiple_choice',
        prompt: 'Jarum pendek pada jam dinding berfungsi untuk menunjukkan...',
        options: ['Detik', 'Menit', 'Jam', 'Tanggal'],
        correctOptionIndex: 2,
        explanation: 'Jarum pendek menunjukkan satuan jam.',
        hint: 'Jarum yang ukurannya lebih pendek.',
        praiseMessage: 'Pintar! Jarum pendek adalah penunjuk jam.',
        points: 25
      },
      {
        id: 'mat_g1_t5_ex2',
        type: 'true_false',
        prompt: 'Dalam satu hari dan satu malam penuh terdapat 24 jam.',
        isTrue: true,
        explanation: 'Benar! Bumi berputar pada porosnya selama 24 jam dalam sehari.',
        hint: 'Waktu dari pagi, siang, sore, hingga malam.',
        praiseMessage: 'Tepat sekali!',
        points: 25
      },
      {
        id: 'mat_g1_t5_ex3',
        type: 'fill_blank',
        prompt: 'Jika jarum pendek menunjuk angka 6 dan jarum panjang di angka 12, maka waktu menunjukkan pukul [ ? ].00',
        acceptableAnswers: ['6', '06'],
        wordBank: ['6', '12', '7', '8'],
        placeholderText: 'Ketik angka jam...',
        explanation: 'Pukul 06.00 (jam enam tepat).',
        hint: 'Angka yang ditunjuk jarum pendek.',
        praiseMessage: 'Hebat! Kamu bisa membaca jam!',
        points: 25
      },
      {
        id: 'mat_g1_t5_ex4',
        type: 'matching',
        prompt: 'Jodohkan waktu dengan kegiatan khas anak sekolah:',
        pairs: [
          { id: 'p1', leftText: 'Pukul 07.00 Pagi', leftEmoji: '🌅', rightText: 'Masuk Kelas Belajar', rightEmoji: '🏫' },
          { id: 'p2', leftText: 'Pukul 12.00 Siang', leftEmoji: '☀️', rightText: 'Makan Siang & Sholat', rightEmoji: '🍱' },
          { id: 'p3', leftText: 'Pukul 21.00 Malam', leftEmoji: '🌙', rightText: 'Tidur Malam Nyenyak', rightEmoji: '🛌' }
        ],
        explanation: '07.00 masuk sekolah, 12.00 makan siang, 21.00 tidur malam.',
        hint: 'Disiplin waktu harian.',
        praiseMessage: 'Luar biasa! Anak pintar selalu disiplin waktu!',
        points: 25
      }
    ],
    audioScript: 'Tik tok tik tok, suara jam berdetik! Jarum pendek menunjukkan jam, jarum panjang menunjukkan menit. Hargai waktumu dengan belajar rajin!'
  }
];

// Helper to get Matematika lessons for Grades 1 to 6 (at least 5 rich topics each)
export function getMatematikaLessonsForGrade(grade: Grade): Lesson[] {
  const existing = MATEMATIKA_LESSONS.filter((l) => l.grade === grade);
  if (existing.length >= 5) return existing;

  const gradeConfigs: Record<number, Array<{ title: string; subtitle: string; cat: string; fact: string; summary: string }>> = {
    2: [
      { title: 'Perkalian sebagai Penjumlahan Berulang', subtitle: 'Konsep 3 x 4 = 4 + 4 + 4', cat: 'Perkalian Dasar', fact: 'Perkalian adalah cara cepat menghitung benda dalam beberapa kelompok yang sama isinya!', summary: 'Memahami arti perkalian dasar 1 sampai 5 melalui penjumlahan berulang.' },
      { title: 'Pembagian sebagai Pengurangan Berulang', subtitle: 'Membagi permen secara adil sampai habis', cat: 'Pembagian Dasar', fact: '12 permen dibagi 3 anak artinya setiap anak mendapat 4 permen secara adil.', summary: 'Konsep pembagian: membagi benda rata sampai tersisa angka 0.' },
      { title: 'Nilai Tempat Ratusan, Puluhan, dan Satuan', subtitle: 'Mengenal bilangan cacah sampai 999', cat: 'Nilai Tempat', fact: 'Angka 358 terdiri dari 3 ratusan, 5 puluhan, dan 8 satuan!', summary: 'Membedakan tempat nilai angka dan menyusun lambang bilangan 3 digit.' },
      { title: 'Mengukur Panjang dengan Penggaris (cm dan m)', subtitle: 'Satuan baku sentimeter dan meter', cat: 'Pengukuran', fact: '1 meter sama dengan 100 sentimeter! Penggaris sekolahmu biasanya 30 cm.', summary: 'Cara mengukur panjang buku, pensil, dan meja dimulai dari angka 0 pada penggaris.' },
      { title: 'Mengenal Berat Benda dengan Timbangan (kg dan gram)', subtitle: 'Menimbang buah dan beras di pasar', cat: 'Pengukuran Berat', fact: '1 kilogram sama dengan 1.000 gram. Timbangan membantu pedagang berbuat adil!', summary: 'Mengenal alat ukur timbangan dan membandingkan benda lebih berat atau lebih ringan.' }
    ],
    3: [
      { title: 'Operasi Hitung Campuran Penjumlahan & Pengurangan', subtitle: 'Menyelesaikan soal cerita sehari-hari', cat: 'Operasi Bilangan', fact: 'Kerjakan operasi di dalam tanda kurung terlebih dahulu sebelum operasi lainnya!', summary: 'Strategi menyelesaikan soal cerita bertahap dengan model matematika rapi.' },
      { title: 'Mengenal Pecahan Sederhana (1/2, 1/3, 1/4)', subtitle: 'Pembilang di atas dan penyebut di bawah', cat: 'Pecahan Dasar', fact: 'Potongan pizza yang dibagi 4 sama besar bernilai 1/4 (seperempat) per potong!', summary: 'Arti pecahan sebagai bagian dari benda utuh yang dibagi sama besar.' },
      { title: 'Keliling Bangun Persegi dan Persegi Panjang', subtitle: 'Menghitung total panjang garis pembatas luar', cat: 'Geometri', fact: 'Keliling persegi adalah 4 dikalikan panjang sisinya (K = 4 x s)!', summary: 'Menghitung keliling lapangan dengan menjumlahkan seluruh sisi-sisinya.' },
      { title: 'Tabel dan Diagram Gambar (Piktogram)', subtitle: 'Menyajikan data favorit siswa secara visual', cat: 'Statistika Cilik', fact: 'Satu gambar bintang di diagram bisa mewakili 5 atau 10 data siswa!', summary: 'Membaca dan membuat piktogram sederhana dari data hobi dan makanan favorit.' },
      { title: 'Mengenal Hubungan Antar Satuan Waktu', subtitle: 'Jam, menit, detik, hari, dan minggu', cat: 'Pengukuran', fact: '1 jam = 60 menit, 1 menit = 60 detik, dan 1 minggu = 7 hari!', summary: 'Konversi satuan waktu dan menghitung lama suatu kegiatan berlangsung.' }
    ],
    4: [
      { title: 'Pecahan Senilai dan Menyederhanakan Pecahan', subtitle: 'Mengapa 2/4 sama nilainya dengan 1/2', cat: 'Pecahan Lanjutan', fact: 'Pecahan senilai diperoleh dengan mengalikan atau membagi pembilang dan penyebut dengan angka yang sama!', summary: 'Teknik mencari pecahan senilai dan cara menyederhanakan pecahan ke bentuk terkecil.' },
      { title: 'Faktor dan Kelipatan Bilangan (FPB dan KPK)', subtitle: 'Mencari kelipatan persekutuan terkecil', cat: 'Teori Bilangan', fact: 'KPK digunakan untuk menentukan kapan dua lampu hias akan berkedip bersamaan!', summary: 'Mencari faktor prima dengan pohon faktor, menentukan FPB dan KPK dua bilangan.' },
      { title: 'Luas Bangun Persegi dan Persegi Panjang', subtitle: 'Rumus Luas = Panjang x Lebar', cat: 'Geometri Luas', fact: 'Luas diukur dalam satuan persegi seperti cm² atau m²!', summary: 'Memahami konsep ubin satuan dan menghitung luas ruangan dengan rumus L = p x l.' },
      { title: 'Mengenal Sudut dan Mengukur dengan Busur Derajat', subtitle: 'Sudut lancip, siku-siku, dan tumpul', cat: 'Pengukuran Sudut', fact: 'Sudut siku-siku besarnya tepat 90 derajat seperti sudut pojok meja dan buku!', summary: 'Menggunakan busur derajat 0 sampai 180 derajat dan mengelompokkan jenis sudut.' },
      { title: 'Diagram Batang Pengolahan Data Siswa', subtitle: 'Membaca tinggi balok diagram secara akurat', cat: 'Statistika', fact: 'Diagram batang memudahkan kepala sekolah melihat jumlah siswa di setiap kelas!', summary: 'Membaca sumbu mendatar (kategori) dan sumbu tegak (jumlah) pada diagram batang.' }
    ],
    5: [
      { title: 'Penjumlahan dan Pengurangan Pecahan Beda Penyebut', subtitle: 'Menyamakan penyebut menggunakan KPK', cat: 'Operasi Pecahan', fact: 'Pecahan beda penyebut seperti 1/2 + 1/3 harus disamakan dulu menjadi per-6!', summary: 'Langkah menyamakan penyebut dengan KPK lalu menjumlahkan pembilangnya.' },
      { title: 'Perkalian dan Pembagian Pecahan serta Desimal', subtitle: 'Menghitung pecahan biasa, campuran, dan koma', cat: 'Operasi Pecahan', fact: 'Membagi pecahan sama dengan mengalikan dengan kebalikan pecahannya: a/b : c/d = a/b x d/c!', summary: 'Perkalian langsung pembilang x pembilang, dan mengubah pecahan ke bentuk desimal.' },
      { title: 'Perbandingan dan Skala pada Peta Indonesia', subtitle: 'Membaca jarak asli dari jarak pada peta', cat: 'Rasio & Skala', fact: 'Skala 1 : 1.000.000 artinya 1 cm di peta mewakili 10 kilometer di bumi asli!', summary: 'Rumus Jarak Sebenarnya (JS) = Jarak Peta (JP) / Skala (S).' },
      { title: 'Volume Kubus dan Balok Menggunakan Kubus Satuan', subtitle: 'Rumus V = s³ dan V = p x l x t', cat: 'Bangun Ruang', fact: 'Volume mengukur isi ruang di dalam benda 3 dimensi dalam satuan kubik (cm³ atau liter)!', summary: 'Menghitung isi bak mandi dan kotak kardus dengan rumus panjang x lebar x tinggi.' },
      { title: 'Jaring-jaring Kubus dan Balok', subtitle: 'Membelah dan merakit bangun ruang 3 dimensi', cat: 'Geometri Ruang', fact: 'Ada 11 pola jaring-jaring berbeda yang semuanya bisa dilipat menjadi kubus sempurna!', summary: 'Menganalisis sisi alas dan sisi tutup pada jaring-jaring bangun ruang kubus dan balok.' }
    ],
    6: [
      { title: 'Bilangan Bulat Negatif dalam Kehidupan Sehari-hari', subtitle: 'Suhu di bawah nol dan kedalaman laut', cat: 'Bilangan Bulat', fact: 'Suhu di puncak Gunung Jayawijaya Papua bisa mencapai -2°C (minus dua derajat Celsius)!', summary: 'Mengenal garis bilangan bulat positif, nol, dan negatif serta operasi hitungnya.' },
      { title: 'Operasi Hitung Campuran Bilangan Bulat', subtitle: 'Aturan KurBaTaKu (Kurung, Bagi, Kali, Tambah, Kurang)', cat: 'Operasi Lanjutan', fact: 'Perkalian dua bilangan negatif menghasilkan bilangan positif: (-3) x (-4) = +12!', summary: 'Menerapkan prioritas operasi tanda kurung, perkalian/pembagian, lalu penjumlahan/pengurangan.' },
      { title: 'Unsur-unsur Lingkaran, Keliling, dan Luas', subtitle: 'Jari-jari (r), diameter (d), dan konstanta Pi (π)', cat: 'Geometri Lingkaran', fact: 'Konstanta Pi (π) bernilai mendekati 22/7 atau 3,14 dan sudah digunakan sejak zaman kuno!', summary: 'Menghitung Keliling = 2 x π x r dan Luas Lingkaran = π x r² dengan teliti.' },
      { title: 'Luas Permukaan dan Volume Bangun Ruang Gabungan', subtitle: 'Prisma, tabung, kerucut, dan bola', cat: 'Bangun Ruang', fact: 'Drum minyak berbentuk tabung memiliki rumus volume V = π x r² x tinggi tabung!', summary: 'Menghitung volume gabungan balok dan prisma segitiga atau tabung dan kerucut.' },
      { title: 'Statistika Dasar: Mean (Rata-rata), Median, dan Modus', subtitle: 'Mengolah nilai rapor dan data tinggi badan siswa', cat: 'Statistika Dasar', fact: 'Rata-rata (mean) didapat dari menjumlahkan seluruh nilai lalu dibagi banyaknya data!', summary: 'Menghitung mean nilai ulangan, mencari median (nilai tengah), dan modus (data tersering).' }
    ]
  };

  const configs = gradeConfigs[grade] || [];
  return configs.map((cfg, index) => {
    const chapter = index + 1;
    return {
      id: `mat_g${grade}_t${chapter}`,
      subjectId: 'matematika',
      grade,
      chapterNumber: chapter,
      title: cfg.title,
      subtitle: cfg.subtitle,
      category: cfg.cat,
      durationMinutes: 7 + chapter,
      funFact: cfg.fact,
      summary: cfg.summary,
      contentParagraphs: [
        `Selamat datang di kelas Matematika Kelas ${grade}! Hari ini kita membahas "${cfg.title}".`,
        cfg.summary + ' Pelajaran ini melatih logika berhitung, ketelitian, dan daya analisis siswa.',
        `Tips Boni: jangan takut dengan angka! Kerjakan langkah demi langkah dengan sabar dan teliti.`
      ],
      keyPoints: [
        `Kuasai konsep inti dari ${cfg.title}.`,
        'Tuliskan langkah-langkah rumus secara teratur.',
        'Periksa kembali hasil hitunganmu sebelum menyimpulkan.'
      ],
      illustrations: [
        { emoji: '🧮', title: 'Hitungan', caption: cfg.title },
        { emoji: '📐', title: 'Geometri & Rumus', caption: cfg.subtitle },
        { emoji: '💡', title: 'Logika', caption: 'Latihan mandiri' }
      ],
      examples: [
        {
          question: `Bagaimana rumus atau langkah menyelesaikan soal terkait "${cfg.title}"?`,
          steps: [
            'Langkah 1: Identifikasi angka yang diketahui dalam soal cerita.',
            'Langkah 2: Tentukan rumus atau operasi matematika yang sesuai.',
            'Langkah 3: Hitung dengan teliti dan beri satuan yang tepat.'
          ],
          answer: `Menerapkan langkah penyelesaian ${cfg.title} secara tepat dan logis.`,
          tip: 'Selalu tuliskan satuan di akhir jawabanmu.'
        }
      ],
      exercises: [
        {
          id: `mat_g${grade}_t${chapter}_ex1`,
          type: 'multiple_choice',
          prompt: `Apa langkah paling awal dalam menyelesaikan soal ${cfg.title}?`,
          options: [
            'Membaca soal dan mencatat data yang diketahui',
            'Langsung menebak angka sembarangan',
            'Menutup buku pelajaran',
            'Menghapus soal'
          ],
          correctOptionIndex: 0,
          explanation: 'Langkah pertama adalah membaca soal dengan teliti dan mencatat hal yang diketahui.',
          hint: 'Pahami dulu isi soal cerita.',
          praiseMessage: 'Pintar! Logika analisismu luar biasa!',
          points: 25
        },
        {
          id: `mat_g${grade}_t${chapter}_ex2`,
          type: 'true_false',
          prompt: `Ketelitian dan kesabaran adalah kunci utama berhasil dalam matematika materi ${cfg.title}.`,
          isTrue: true,
          explanation: 'Benar! Menghitung membutuhkan ketelitian agar tidak ada angka yang terlewat.',
          hint: 'Apakah teliti itu penting dalam berhitung?',
          praiseMessage: 'Tepat sekali! Sikap teliti membuatmu juara!',
          points: 25
        },
        {
          id: `mat_g${grade}_t${chapter}_ex3`,
          type: 'fill_blank',
          prompt: `Simbol matematika untuk membagi dua bilangan secara adil adalah tanda [ ? ] (: atau /)`,
          acceptableAnswers: [':', '/'],
          wordBank: [':', '+', '-', 'x'],
          placeholderText: 'Ketik simbol pembagian...',
          explanation: 'Tanda titik dua (:) atau garis miring (/) melambangkan pembagian.',
          hint: 'Tanda bagi titik dua.',
          praiseMessage: 'Luar biasa! Simbol matematikamu tepat!',
          points: 25
        },
        {
          id: `mat_g${grade}_t${chapter}_ex4`,
          type: 'matching',
          prompt: 'Jodohkan istilah matematika dengan pasangannya:',
          pairs: [
            { id: 'p1', leftText: 'Operasi Tambah', leftEmoji: '➕', rightText: 'Hasil Bertambah Banyak', rightEmoji: '📈' },
            { id: 'p2', leftText: 'Operasi Kurang', leftEmoji: '➖', rightText: 'Hasil Sisa Berkurang', rightEmoji: '📉' },
            { id: 'p3', leftText: 'Operasi Kali', leftEmoji: '✖️', rightText: 'Penjumlahan Berulang Cepat', rightEmoji: '⚡' }
          ],
          explanation: 'Tambah membuat banyak, kurang membuat berkurang, kali adalah penjumlahan berulang.',
          hint: 'Makna operasi hitung dasar.',
          praiseMessage: 'Sempurna! Kamu memahami seluruh konsep matematika ini!',
          points: 25
        }
      ],
      audioScript: `Ayo belajar ${cfg.title} bersama Boni! Matematika itu mudah dan menyenangkan jika kita memahaminya langkah demi langkah.`
    };
  });
}
