import { Lesson, Grade } from '../../types';

export const IPAS_LESSONS: Lesson[] = [
  // ================= KELAS 1 =================
  {
    id: 'ipas_g1_t1',
    subjectId: 'ipas',
    grade: 1,
    chapterNumber: 1,
    title: 'Pancaindra Karunia Tuhan',
    subtitle: 'Mata, telinga, hidung, lidah, dan kulit kita',
    category: 'Tubuh Manusia',
    durationMinutes: 6,
    funFact: 'Lidah manusia memiliki sekitar 10.000 bintil pengecap rasa manis, asin, asam, dan pahit yang selalu berganti selnya setiap 2 minggu!',
    summary: 'Mengenal 5 alat indra manusia dan cara merawatnya agar selalu sehat dan berfungsi optimal.',
    contentParagraphs: [
      'Tubuh kita adalah ciptaan Tuhan yang sangat indah. Kita memiliki lima indra (Pancaindra):',
      '1. Mata untuk melihat pelangi dan membaca.\n2. Telinga untuk mendengar suara bel dan nyanyian.\n3. Hidung untuk membau harum bunga dan bernapas.\n4. Lidah untuk mengecap rasa makanan.\n5. Kulit untuk meraba halus, kasar, panas, dan dingin.',
      'Rawatlah pancaindramu dengan tidak membaca di tempat gelap dan makan makanan bergizi!'
    ],
    keyPoints: [
      'Ada 5 pancaindra: penglihat, pendengar, pembau, pengecap, dan peraba.',
      'Mata = melihat, telinga = mendengar.',
      'Hidung = membau, lidah = mengecap rasa, kulit = meraba.'
    ],
    illustrations: [
      { emoji: '👀', title: 'Mata', caption: 'Indra penglihat' },
      { emoji: '👅', title: 'Lidah', caption: 'Mengecap rasa manis asin' },
      { emoji: '👂', title: 'Telinga', caption: 'Mendengar musik' }
    ],
    examples: [
      {
        question: 'Indra manakah yang kita gunakan saat membedakan rasa gula yang manis dengan garam yang asin?',
        steps: [
          'Gula dan garam dirasakan di dalam mulut.',
          'Organ yang bertugas mengecap rasa adalah lidah.'
        ],
        answer: 'Lidah (indra pengecap).',
        tip: 'Lidah mengenali 4 rasa utama: manis, asin, asam, pahit.'
      }
    ],
    exercises: [
      {
        id: 'ipas_g1_t1_ex1',
        type: 'multiple_choice',
        prompt: 'Bagian tubuh yang berfungsi sebagai indra pendengar adalah...',
        options: ['Mata', 'Telinga', 'Hidung', 'Tangan'],
        correctOptionIndex: 1,
        explanation: 'Telinga berfungsi untuk mendengar berbagai bunyi di sekitar kita.',
        hint: 'Organ di sisi kanan dan kiri kepala.',
        praiseMessage: 'Pintar! Telinga membuat kita bisa mendengar cerita.',
        points: 25
      },
      {
        id: 'ipas_g1_t1_ex2',
        type: 'true_false',
        prompt: 'Membaca buku di tempat yang gelap dan remang-remang sangat baik untuk kesehatan mata.',
        isTrue: false,
        explanation: 'Salah! Membaca di tempat gelap membuat mata cepat lelah dan bisa merusak penglihatan.',
        hint: 'Mata membutuhkan cahaya yang cukup.',
        praiseMessage: 'Benar sekali! Selalu membaca di tempat yang terang ya.',
        points: 25
      },
      {
        id: 'ipas_g1_t1_ex3',
        type: 'fill_blank',
        prompt: 'Indra yang kita gunakan untuk merasakan kasarnya kulit buah nanas adalah [ ? ] (kulit / lidah / mata)',
        acceptableAnswers: ['kulit', 'Kulit'],
        wordBank: ['kulit', 'lidah', 'mata', 'hidung'],
        placeholderText: 'Ketik nama indra...',
        explanation: 'Kulit berfungsi sebagai indra peraba yang merasakan tekstur kasar dan halus.',
        hint: 'Selubung pelindung luar tubuh.',
        praiseMessage: 'Tepat sekali! Kulit adalah indra peraba.',
        points: 25
      },
      {
        id: 'ipas_g1_t1_ex4',
        type: 'matching',
        prompt: 'Jodohkan indra dengan fungsinya:',
        pairs: [
          { id: 'p1', leftText: 'Mata', leftEmoji: '👀', rightText: 'Melihat Pelangi', rightEmoji: '🌈' },
          { id: 'p2', leftText: 'Hidung', leftEmoji: '👃', rightText: 'Membau Parfum Bunga', rightEmoji: '🌸' },
          { id: 'p3', leftText: 'Lidah', leftEmoji: '👅', rightText: 'Mengecap Manis Madu', rightEmoji: '🍯' }
        ],
        explanation: 'Mata melihat pelangi, hidung membau bunga, lidah mengecap madu.',
        hint: 'Hubungkan dengan aktivitasnya.',
        praiseMessage: 'Hebat! Kamu memahami kelima pancaindramu!',
        points: 25
      }
    ],
    audioScript: 'Pancaindra adalah karunia Tuhan yang luar biasa! Mata untuk melihat, telinga mendengar, hidung membau, lidah mengecap, dan kulit untuk meraba.'
  },
  {
    id: 'ipas_g1_t2',
    subjectId: 'ipas',
    grade: 1,
    chapterNumber: 2,
    title: 'Mengenal Tumbuhan dan Bagian-Bagiannya',
    subtitle: 'Akar, batang, daun, bunga, dan buah',
    category: 'Dunia Tumbuhan',
    durationMinutes: 6,
    funFact: 'Pohon bambu adalah tumbuhan dengan pertumbuhan tercepat di dunia, bisa tumbuh hingga 90 sentimeter hanya dalam satu hari!',
    summary: 'Mengenal bagian pokok tumbuhan hijau dan kegunaannya dalam kehidupan.',
    contentParagraphs: [
      'Tumbuhan adalah makhluk hidup yang membuat lingkungan kita menjadi hijau, asri, dan sejuk.',
      'Bagian-bagian tumbuhan:\n1. AKAR: berada di dalam tanah untuk menyerap air dan mengokohkan tanaman.\n2. BATANG: menyalurkan air dan menopang daun.\n3. DAUN: tempat membuat makanan tumbuhan dengan bantuan sinar matahari.\n4. BUNGA: bagian yang cantik untuk perkembangbiakan.\n5. BUAH: membungkus biji dan sering kita makan karena lezat dan kaya vitamin.'
    ],
    keyPoints: [
      'Akar menyerap air dari dalam tanah.',
      'Daun berwarna hijau dan memasak makanan.',
      'Siram tanaman secara teratur agar tidak layu.'
    ],
    illustrations: [
      { emoji: '🌱', title: 'Tunas', caption: 'Tumbuhan muda bertumbuh' },
      { emoji: '🌳', title: 'Pohon Hijau', caption: 'Akar, batang, dan daun rimbun' },
      { emoji: '🍎', title: 'Buah Manis', caption: 'Hasil tumbuhan berbuah' }
    ],
    examples: [
      {
        question: 'Bagian tumbuhan manakah yang berfungsi menyerap air dan zat hara dari dalam tanah?',
        steps: [
          'Bagian ini biasanya berada di bawah tanah.',
          'Bagian ini menyerap air dan menahan pohon agar tidak roboh tertiup angin.',
          'Nama bagian tersebut adalah Akar.'
        ],
        answer: 'Akar.',
        tip: 'Akar mencengkeram tanah dengan kuat.'
      }
    ],
    exercises: [
      {
        id: 'ipas_g1_t2_ex1',
        type: 'multiple_choice',
        prompt: 'Bagian tumbuhan yang bertugas menyerap air dari dalam tanah adalah...',
        options: ['Daun', 'Akar', 'Bunga', 'Buah'],
        correctOptionIndex: 1,
        explanation: 'Akar berada di dalam tanah dan bertugas menyerap air serta mineral.',
        hint: 'Tersembunyi di dalam tanah.',
        praiseMessage: 'Pintar sekali! Akar adalah pondasi tumbuhan.',
        points: 25
      },
      {
        id: 'ipas_g1_t2_ex2',
        type: 'true_false',
        prompt: 'Tumbuhan membutuhkan air dan sinar matahari untuk dapat tumbuh subur.',
        isTrue: true,
        explanation: 'Benar! Tanpa air dan sinar matahari, tumbuhan akan layu dan mati.',
        hint: 'Ingat apa yang dibutuhkan tanaman di pot rumahmu.',
        praiseMessage: 'Tepat sekali! Hebat!',
        points: 25
      },
      {
        id: 'ipas_g1_t2_ex3',
        type: 'fill_blank',
        prompt: 'Warna daun tumbuhan yang sehat pada umumnya adalah warna [ ? ] (hijau / hitam / ungu)',
        acceptableAnswers: ['hijau', 'Hijau'],
        wordBank: ['hijau', 'merah', 'hitam', 'cokelat'],
        placeholderText: 'Ketik warna daun...',
        explanation: 'Daun sehat berwarna hijau karena mengandung zat hijau daun (klorofil).',
        hint: 'Warna seperti rumput segar.',
        praiseMessage: 'Hebat! Hijau yang asri!',
        points: 25
      },
      {
        id: 'ipas_g1_t2_ex4',
        type: 'matching',
        prompt: 'Jodohkan bagian tumbuhan dengan tugasnya:',
        pairs: [
          { id: 'p1', leftText: 'Akar', leftEmoji: '🪴', rightText: 'Menyerap Air di Tanah', rightEmoji: '💧' },
          { id: 'p2', leftText: 'Daun', leftEmoji: '🍃', rightText: 'Memasak dengan Matahari', rightEmoji: '☀️' },
          { id: 'p3', leftText: 'Buah', leftEmoji: '🥭', rightText: 'Melindungi Biji & Dimakan', rightEmoji: '🍽️' }
        ],
        explanation: 'Akar menyerap air, daun memasak, buah melindungi biji.',
        hint: 'Peran masing-masing organ.',
        praiseMessage: 'Sempurna! Kamu sahabat tumbuhan yang baik!',
        points: 25
      }
    ],
    audioScript: 'Tumbuhan hijau adalah sahabat bumi! Sayangi tanaman di sekitarmu dengan menyiramnya setiap hari.'
  },
  {
    id: 'ipas_g1_t3',
    subjectId: 'ipas',
    grade: 1,
    chapterNumber: 3,
    title: 'Mengenal Hewan Peliharaan dan Tempat Hidupnya',
    subtitle: 'Hewan darat, hewan air, dan hewan udara',
    category: 'Dunia Hewan',
    durationMinutes: 6,
    funFact: 'Kucing mendengkur tidak hanya saat senang, tetapi juga untuk menenangkan diri dan mempercepat penyembuhan tulangnya!',
    summary: 'Mengenal jenis hewan di darat (kucing, sapi), di air (ikan), dan cara menyayangi hewan ciptaan Tuhan.',
    contentParagraphs: [
      'Di bumi ada banyak sekali hewan yang lucu dan menggemaskan.',
      '1. HEWAN DARAT: hidup dan berjalan di daratan. Contoh: kucing, anjing, kelinci, sapi, kambing.\n2. HEWAN AIR: hidup dan bernapas di dalam air menggunakan insang. Contoh: ikan mas, lumba-lumba, udang.\n3. HEWAN UDARA: memiliki sayap untuk terbang tinggi. Contoh: burung merpati, kupu-kupu, capung.',
      'Hewan peliharaan harus kita rawat dengan memberi makan secara teratur dan membersihkan kandangnya.'
    ],
    keyPoints: [
      'Hewan hidup di darat, air, dan udara.',
      'Ikan berenang di air menggunakan sirip.',
      'Burung terbang di udara menggunakan sayap.',
      'Sayangi hewan peliharaan dengan memberi makan.'
    ],
    illustrations: [
      { emoji: '🐱', title: 'Kucing', caption: 'Hewan darat berbulu' },
      { emoji: '🐟', title: 'Ikan', caption: 'Hewan berenang di air' },
      { emoji: '🕊️', title: 'Burung', caption: 'Hewan terbang di angkasa' }
    ],
    examples: [
      {
        question: 'Ikan mas hidup di dalam air kolam. Alat gerak apakah yang digunakan ikan mas untuk berenang?',
        steps: [
          'Ikan tidak memiliki kaki seperti kucing.',
          'Ikan menggerakkan tubuh dan siripnya untuk meluncur di air.'
        ],
        answer: 'Sirip dan ekor.',
        tip: 'Sirip membantu ikan berbelok dengan lincah.'
      }
    ],
    exercises: [
      {
        id: 'ipas_g1_t3_ex1',
        type: 'multiple_choice',
        prompt: 'Hewan di bawah ini yang hidup dan bernapas di dalam air adalah...',
        options: ['Ayam', 'Kucing', 'Ikan Gurame', 'Kambing'],
        correctOptionIndex: 2,
        explanation: 'Ikan Gurame adalah hewan air yang bernapas dengan insang.',
        hint: 'Berenang di air tawar.',
        praiseMessage: 'Tepat sekali! Ikan berenang riang di air.',
        points: 25
      },
      {
        id: 'ipas_g1_t3_ex2',
        type: 'true_false',
        prompt: 'Kucing peliharaan boleh dibiarkan kelaparan berhari-hari tanpa diberi makan.',
        isTrue: false,
        explanation: 'Salah! Menyayangi hewan berarti harus memberinya makan, minum, dan merawatnya dengan kasih sayang.',
        hint: 'Kasih sayang terhadap sesama makhluk.',
        praiseMessage: 'Pintar! Kita wajib menyayangi hewan ciptaan Tuhan.',
        points: 25
      },
      {
        id: 'ipas_g1_t3_ex3',
        type: 'fill_blank',
        prompt: 'Burung terbang bebas di langit menggunakan sepasang [ ? ] (sayap / kaki / telinga)',
        acceptableAnswers: ['sayap', 'Sayap'],
        wordBank: ['sayap', 'tangan', 'sirip', 'tanduk'],
        placeholderText: 'Ketik anggota gerak burung...',
        explanation: 'Burung memiliki sayap berbulu yang memungkinkannya terbang melayang di udara.',
        hint: 'Alat untuk mengepakkan udara.',
        praiseMessage: 'Tepat sekali! Sayap yang indah!',
        points: 25
      },
      {
        id: 'ipas_g1_t3_ex4',
        type: 'matching',
        prompt: 'Jodohkan hewan dengan habitat tempat hidup utamanya:',
        pairs: [
          { id: 'p1', leftText: 'Sapi Perah', leftEmoji: '🐄', rightText: 'Padang Rumput Darat', rightEmoji: '🌾' },
          { id: 'p2', leftText: 'Ikan Lumba-lumba', leftEmoji: '🐬', rightText: 'Lautan Air Luas', rightEmoji: '🌊' },
          { id: 'p3', leftText: 'Burung Elang', leftEmoji: '🦅', rightText: 'Terbang di Udara', rightEmoji: '☁️' }
        ],
        explanation: 'Sapi di darat, lumba-lumba di air, elang terbang di udara.',
        hint: 'Tempat hidup alami.',
        praiseMessage: 'Luar biasa! Pengetahuan alammu sangat luas!',
        points: 25
      }
    ],
    audioScript: 'Semua hewan ciptaan Tuhan memiliki tempat hidupnya masing-masing. Hewan darat, hewan air, dan hewan udara. Rawat dan lindungi mereka ya!'
  },
  {
    id: 'ipas_g1_t4',
    subjectId: 'ipas',
    grade: 1,
    chapterNumber: 4,
    title: 'Benda Padat, Cair, dan Gas di Rumah Kita',
    subtitle: 'Wujud zat yang sering kita jumpai',
    category: 'Sains Benda',
    durationMinutes: 5,
    funFact: 'Air adalah zat ajaib di bumi yang bisa berubah menjadi ketiga wujud: es batu (padat), air minum (cair), dan uap panas (gas)!',
    summary: 'Mengenal ciri benda padat (bentuk tetap), cair (mengikuti wadah), dan gas (mengisi ruangan).',
    contentParagraphs: [
      'Segala sesuatu di sekitar kita terbuat dari materi yang memiliki wujud berbeda:',
      '1. BENDA PADAT: Bentuknya tetap dan keras jika disentuh. Contoh: buku, pensil, meja, batu.\n2. BENDA CAIR: Bentuknya berubah mengikuti bentuk wadahnya dan dapat mengalir. Contoh: air minum, susu, kecap, minyak goreng.\n3. BENDA GAS: Tidak terlihat tapi bisa kita rasakan, memenuhi seluruh ruangan. Contoh: udara yang kita hirup, angin sejuk, udara di dalam balon tiup.'
    ],
    keyPoints: [
      'Benda padat bentuknya tetap saat dipindahkan.',
      'Benda cair mengalir dan berubah mengikuti wadah.',
      'Udara di dalam balon adalah benda gas.'
    ],
    illustrations: [
      { emoji: '🧊', title: 'Es Batu', caption: 'Contoh benda padat' },
      { emoji: '🥛', title: 'Susu', caption: 'Contoh benda cair' },
      { emoji: '🎈', title: 'Udara Balon', caption: 'Contoh benda gas' }
    ],
    examples: [
      {
        question: 'Ketika air teh dituangkan dari teko ke dalam cangkir bundar, bagaimanakah bentuk air teh tersebut?',
        steps: [
          'Air teh adalah benda cair.',
          'Sifat benda cair adalah bentuknya berubah mengikuti bentuk wadah yang ditempatinya.',
          'Jadi bentuk air teh menjadi bundar seperti cangkir.'
        ],
        answer: 'Bentuknya berubah menjadi seperti cangkir.',
        tip: 'Benda cair selalu menyesuaikan wadahnya.'
      }
    ],
    exercises: [
      {
        id: 'ipas_g1_t4_ex1',
        type: 'multiple_choice',
        prompt: 'Contoh benda di dapur yang termasuk benda cair adalah...',
        options: ['Sendok logam', 'Minyak goreng', 'Piring kaca', 'Panci'],
        correctOptionIndex: 1,
        explanation: 'Minyak goreng berwujud cair dan dapat mengalir.',
        hint: 'Bisa dituang ke dalam wajan.',
        praiseMessage: 'Pintar! Minyak goreng adalah benda cair.',
        points: 25
      },
      {
        id: 'ipas_g1_t4_ex2',
        type: 'true_false',
        prompt: 'Buku tulis jika dipindahkan dari tas ke atas meja akan berubah bentuk menjadi cair.',
        isTrue: false,
        explanation: 'Salah! Buku adalah benda padat yang bentuk dan ukurannya tetap.',
        hint: 'Buku tidak mencair saat ditaruh di meja.',
        praiseMessage: 'Tepat sekali! Benda padat bentuknya selalu tetap.',
        points: 25
      },
      {
        id: 'ipas_g1_t4_ex3',
        type: 'fill_blank',
        prompt: 'Udara yang kita tiupkan ke dalam balon termasuk benda berwujud [ ? ] (gas / padat / batu)',
        acceptableAnswers: ['gas', 'Gas'],
        wordBank: ['gas', 'padat', 'cair', 'kaca'],
        placeholderText: 'Ketik wujud zat...',
        explanation: 'Udara yang mengisi ruang di dalam balon berwujud gas.',
        hint: 'Zat tak kasat mata yang memenuhi balon.',
        praiseMessage: 'Luar biasa! Udara adalah gas.',
        points: 25
      },
      {
        id: 'ipas_g1_t4_ex4',
        type: 'matching',
        prompt: 'Jodohkan benda dengan wujud zatnya:',
        pairs: [
          { id: 'p1', leftText: 'Pensil Kayu', leftEmoji: '✏️', rightText: 'Benda Padat', rightEmoji: '🧱' },
          { id: 'p2', leftText: 'Sirup Manis', leftEmoji: '🧃', rightText: 'Benda Cair', rightEmoji: '💧' },
          { id: 'p3', leftText: 'Asap Cerobong', leftEmoji: '💨', rightText: 'Benda Gas', rightEmoji: '☁️' }
        ],
        explanation: 'Pensil padat, sirup cair, asap berwujud gas.',
        hint: 'Perhatikan sifat masing-masing.',
        praiseMessage: 'Sempurna! Kamu memahami 3 wujud zat!',
        points: 25
      }
    ],
    audioScript: 'Padat, cair, dan gas! Pensil itu padat, air minum itu cair, dan udara yang kita hirup adalah gas. Sains ada di sekeliling kita!'
  },
  {
    id: 'ipas_g1_t5',
    subjectId: 'ipas',
    grade: 1,
    chapterNumber: 5,
    title: 'Siang, Malam, dan Cuaca Indonesia',
    subtitle: 'Matahari, bulan, bintang, hujan, dan pelangi',
    category: 'Gejala Alam',
    durationMinutes: 6,
    funFact: 'Pelangi terbentuk ketika sinar matahari bersinar menembus butiran-butiran air hujan di udara yang membiaskan cahaya menjadi 7 warna indah!',
    summary: 'Mengenal perbedaan suasana siang dan malam, serta jenis cuaca: cerah, berawan, dan hujan.',
    contentParagraphs: [
      'Setiap hari kita mengalami pergantian waktu siang dan malam yang menakjubkan.',
      '1. SIANG HARI: Matahari bersinar terang memberikan cahaya dan kehangatan. Kita belajar di sekolah dan bermain bersama teman.\n2. MALAM HARI: Langit menjadi gelap, dihiasi bulan dan bintang-bintang yang berkilau indah. Waktunya istirahat dan tidur lelap.',
      'Cuaca di Indonesia ada bermacam-macam: cuaca cerah berpanas matahari, berawan sejuk, dan cuaca hujan air yang menyirami bumi.'
    ],
    keyPoints: [
      'Matahari terbit di timur pada pagi hari dan terbenam di barat.',
      'Bulan dan bintang menerangi malam hari.',
      'Jas hujan dan payung melindungi kita saat cuaca hujan.'
    ],
    illustrations: [
      { emoji: '☀️', title: 'Matahari', caption: 'Cahaya siang hari' },
      { emoji: '🌙', title: 'Bulan Sabit', caption: 'Penerang malam' },
      { emoji: '🌧️', title: 'Hujan', caption: 'Membasahi bumi' }
    ],
    examples: [
      {
        question: 'Benda langit apakah yang menjadi sumber cahaya utama di bumi pada siang hari?',
        steps: [
          'Benda ini sangat besar, panas, dan bersinar terang di langit.',
          'Terbit di timur saat pagi hari.',
          'Benda tersebut adalah Matahari.'
        ],
        answer: 'Matahari ☀️',
        tip: 'Matahari memberi energi bagi kehidupan di bumi.'
      }
    ],
    exercises: [
      {
        id: 'ipas_g1_t5_ex1',
        type: 'multiple_choice',
        prompt: 'Benda langit yang tampak bersinar indah dan berkelap-kelip di malam hari adalah...',
        options: ['Matahari', 'Bintang', 'Pelangi', 'Awan petir'],
        correctOptionIndex: 1,
        explanation: 'Bintang berkelap-kelip menghiasi langit malam yang gelap.',
        hint: 'Lagu anak "Bintang Kecil".',
        praiseMessage: 'Pintar! Bintang malam yang gemerlap!',
        points: 25
      },
      {
        id: 'ipas_g1_t5_ex2',
        type: 'true_false',
        prompt: 'Matahari terbit di sebelah timur pada pagi hari.',
        isTrue: true,
        explanation: 'Benar! Bumi berputar sehingga matahari tampak terbit di timur dan terbenam di barat.',
        hint: 'Arah matahari pagi.',
        praiseMessage: 'Tepat sekali!',
        points: 25
      },
      {
        id: 'ipas_g1_t5_ex3',
        type: 'fill_blank',
        prompt: 'Saat cuaca hujan deras di luar rumah, kita menggunakan [ ? ] agar seragam tidak basah (payung / kacamata / topi)',
        acceptableAnswers: ['payung', 'Payung'],
        wordBank: ['payung', 'bantal', 'piring', 'kacamata'],
        placeholderText: 'Ketik pelindung hujan...',
        explanation: 'Payung dan jas hujan melindungi kita dari tetesan air hujan.',
        hint: 'Benda pelindung hujan yang bisa dibuka-tutup.',
        praiseMessage: 'Hebat! Payung pelindung hujan!',
        points: 25
      },
      {
        id: 'ipas_g1_t5_ex4',
        type: 'matching',
        prompt: 'Jodohkan waktu dengan tanda-tanda alamnya:',
        pairs: [
          { id: 'p1', leftText: 'Siang Cerah', leftEmoji: '☀️', rightText: 'Matahari Terang Benderang', rightEmoji: '😎' },
          { id: 'p2', leftText: 'Malam Tenang', leftEmoji: '🌙', rightText: 'Bulan & Bintang Berpendar', rightEmoji: '✨' },
          { id: 'p3', leftText: 'Hujan Reda', leftEmoji: '🌦️', rightText: 'Muncul Pelangi Warna-warni', rightEmoji: '🌈' }
        ],
        explanation: 'Siang matahari, malam bulan bintang, setelah hujan pelangi.',
        hint: 'Fenomena alam yang indah.',
        praiseMessage: 'Luar biasa! Alam semesta sangat mengagumkan!',
        points: 25
      }
    ],
    audioScript: 'Matahari menyinari siang, bulan dan bintang menghiasi malam. Bersyukurlah atas cuaca hujan dan cerah yang menyuburkan tanah air kita Indonesia!'
  }
];

// Helper to provide 5 rich IPAS topics for Grades 1 to 6
export function getIpasLessonsForGrade(grade: Grade): Lesson[] {
  const existing = IPAS_LESSONS.filter((l) => l.grade === grade);
  if (existing.length >= 5) return existing;

  const gradeConfigs: Record<number, Array<{ title: string; subtitle: string; cat: string; fact: string; summary: string }>> = {
    2: [
      { title: 'Siklus Hidup Kupu-kupu (Metamorfosis)', subtitle: 'Dari telur, ulat, kepompong, hingga kupu-kupu indah', cat: 'Biologi Alam', fact: 'Di dalam kepompong, tubuh ulat berubah total menjadi kupu-kupu bersayap cantik!', summary: 'Tahapan metamorfosis sempurna pada serangga dan menjaga kelestariannya.' },
      { title: 'Sumber Energi di Sekitar Kita', subtitle: 'Matahari, air, angin, dan listrik', cat: 'Fisika Sederhana', fact: 'Matahari adalah sumber energi terbesar dan utama bagi seluruh kehidupan di bumi!', summary: 'Manfaat energi panas matahari untuk menjemur padi dan mengeringkan pakaian.' },
      { title: 'Merawat Hewan dan Tumbuhan di Lingkungan Rumah', subtitle: 'Kasih sayang terhadap sesama makhluk hidup', cat: 'Peduli Lingkungan', fact: 'Menyiram tanaman dengan air cucian beras bisa menjadi pupuk alami yang sangat subur!', summary: 'Kebiasaan baik membersihkan kandang hewan dan menyiram tanaman secara rutin.' },
      { title: 'Mengenal Peta dan Denah Rumah Sederhana', subtitle: 'Arah mata angin: utara, timur, selatan, barat', cat: 'Geografi Sosial', fact: 'Kompas selalu menunjuk ke arah utara karena tarikan magnet bumi!', summary: 'Membaca letak kamar, dapur, dan halaman menggunakan denah sederhana.' },
      { title: 'Keragaman Budaya dan Makanan Khas Daerah', subtitle: 'Rendang, gudeg, papeda, dan pempek nusantara', cat: 'Sosial Budaya', fact: 'Indonesia memiliki lebih dari 300 kelompok suku bangsa dengan ribuan kuliner lezat!', summary: 'Mengenal keberagaman pakaian adat, rumah adat, dan makanan tradisional nusantara.' }
    ],
    3: [
      { title: 'Perubahan Wujud Benda (Mencair, Membeku, Menguap)', subtitle: 'Air menjadi es, uap air, dan mengembun', cat: 'Sifat Zat', fact: 'Titik beku air murni adalah tepat pada suhu 0 derajat Celsius!', summary: 'Eksperimen sederhana es batu mencair dan air mendidih menghasilkan uap panas.' },
      { title: 'Ciri-Ciri Makhluk Hidup', subtitle: 'Bernapas, bergerak, makan, tumbuh, dan berkembang biak', cat: 'Sains Hayati', fact: 'Pohon putri malu akan mengatupkan daunnya seketika saat disentuh untuk melindungi diri!', summary: 'Perbedaan mendasar antara benda hidup (biotik) dan benda mati (abiotik).' },
      { title: 'Hak dan Kewajiban dalam Menjaga Kelestarian Alam', subtitle: 'Hemat air bersih dan memilah sampah organik', cat: 'Sosial Lingkungan', fact: 'Sampah plastik membutuhkan waktu ratusan tahun untuk bisa terurai di dalam tanah!', summary: 'Mengurangi sampah plastik (Reuse, Reduce, Recycle) demi bumi yang lestari.' },
      { title: 'Mengenal Uang dan Kebutuhan Hidup Manusia', subtitle: 'Membedakan kebutuhan pokok vs keinginan', cat: 'Ekonomi Sederhana', fact: 'Sebelum ada uang, manusia zaman dahulu melakukan barter (saling tukar barang)!', summary: 'Kebutuhan primer (sandang, pangan, papan) dan membiasakan rajin menabung.' },
      { title: 'Keindahan Bentang Alam Indonesia', subtitle: 'Gunung berapi, danau, sungai, pantai, dan hutan', cat: 'Geografi Alam', fact: 'Indonesia adalah negara kepulauan terbesar di dunia dengan lebih dari 17.000 pulau!', summary: 'Ciri-ciri dataran tinggi sejuk untuk teh dan dataran rendah subur untuk padi.' }
    ],
    4: [
      { title: 'Proses Fotosintesis Dapur Ajaib Daun Hijau', subtitle: 'Air + Karbon Dioksida + Cahaya = Oksigen + Makanan', cat: 'Tumbuhan & Energi', fact: 'Hutan hujan tropis Indonesia menghasilkan oksigen melimpah sebagai paru-paru dunia!', summary: 'Peran klorofil menangkap sinar matahari untuk memasak zat gula dan melepas oksigen.' },
      { title: 'Macam-Macam Gaya dan Pengaruhnya terhadap Benda', subtitle: 'Gaya otot, gaya gesek, gaya magnet, dan gravitasi', cat: 'Fisika Gerak', fact: 'Gaya gravitasi bumi membuat kita tidak melayang-layang jatuh ke luar angkasa!', summary: 'Bagaimana gaya tarikan dan dorongan dapat mengubah gerak dan bentuk benda.' },
      { title: 'Rantai Makanan dan Jaring-jaring Ekosistem Sawah', subtitle: 'Produsen, konsumen tingkat 1, dan pengurai', cat: 'Ekologi', fact: 'Jika burung hantu di sawah diburu, populasi tikus akan meledak merusak padi petani!', summary: 'Keseimbangan rantai makanan: padi dimakan tikus, tikus dimakan ular, ular dimakan elang.' },
      { title: 'Keragaman Kerajaan Hindu, Buddha, dan Islam di Nusantara', subtitle: 'Peninggalan candi, prasasti, dan masjid kuno', cat: 'Sejarah Budaya', fact: 'Candi Borobudur dibangun pada abad ke-8 sebagai candi Buddha terbesar di dunia!', summary: 'Kisah kejayaan Kerajaan Sriwijaya, Majapahit dengan Sumpah Palapa, dan Kesultanan Samudera Pasai.' },
      { title: 'Peta Indonesia dan Pemanfaatan Sumber Daya Alam', subtitle: 'Tambang minyak, hasil laut ikan, dan rempah-rempah', cat: 'Geografi Sosial', fact: 'Rempah-rempah Maluku seperti cengkih dan pala sangat diperebutkan pedagang dunia!', summary: 'Membaca peta tematik provinsi Indonesia dan melestarikan kekayaan laut nusantara.' }
    ],
    5: [
      { title: 'Sistem Pernapasan pada Manusia dan Hewan', subtitle: 'Hidung, tenggorokan, trakea, bronkus, dan alveolus', cat: 'Biologi Manusia', fact: 'Paru-paru manusia memiliki sekitar 300 juta alveolus untuk menukar oksigen dan CO2!', summary: 'Mekanisme bernapas menghirup O2 dan menghembuskan CO2 serta bahaya asap polusi.' },
      { title: 'Sistem Pencernaan Makanan Manusia', subtitle: 'Mulut, kerongkongan, lambung, usus halus, dan usus besar', cat: 'Biologi Manusia', fact: 'Panjang seluruh usus di dalam perut manusia dewasa bisa mencapai sekitar 7 meter!', summary: 'Proses pencernaan mekanik dan kimiawi oleh enzim serta menjaga lambung dari penyakit maag.' },
      { title: 'Sistem Peredaran Darah Jantung dan Pembuluh Darah', subtitle: 'Peredaran darah besar dan peredaran darah kecil', cat: 'Kesehatan Tubuh', fact: 'Jantung manusia berdetak sekitar 100.000 kali setiap hari tanpa pernah berhenti istirahat!', summary: 'Fungsi jantung memompa darah kaya oksigen melalui pembuluh arteri ke seluruh tubuh.' },
      { title: 'Peristiwa Perpindahan Panas (Kalor)', subtitle: 'Konduksi, konveksi, dan radiasi', cat: 'Fisika Kalor', fact: 'Panas sinar matahari sampai ke bumi melalui ruang hampa dengan cara radiasi!', summary: 'Sendok panas saat mengaduk teh (konduksi), air mendidih (konveksi), api unggun (radiasi).' },
      { title: 'Perjuangan Mempertahankan Kemerdekaan Indonesia', subtitle: 'Peristiwa Rengasdengklok hingga Proklamasi 17 Agustus 1945', cat: 'Sejarah Kemerdekaan', fact: 'Teks Proklamasi diketik oleh Sayuti Melik dan bendera dijahit tangan oleh Ibu Fatmawati!', summary: 'Nilai perjuangan para pahlawan bangsa dalam merebut dan mempertahankan kemerdekaan NKRI.' }
    ],
    6: [
      { title: 'Sistem Tata Surya dan Planet-Planet Pengeliling Matahari', subtitle: 'Merkurius hingga Neptunus mengorbit matahari', cat: 'Astronomi', fact: 'Planet Yupiter sangat besar sehingga bisa memuat lebih dari 1.300 planet seukuran bumi!', summary: 'Urutan 8 planet tata surya, sabuk asteroid, komet, serta gerak rotasi dan revolusi bumi.' },
      { title: 'Ciri-Ciri Pubertas pada Remaja Laki-Laki dan Perempuan', subtitle: 'Perubahan fisik, psikologis, dan menjaga kebersihan diri', cat: 'Kesehatan Remaja', fact: 'Pubertas adalah proses alami tubuh bertumbuh menjadi dewasa yang sehat dan kuat!', summary: 'Perubahan primer dan sekunder masa pubertas serta cara menjaga pergaulan positif.' },
      { title: 'Adaptasi Tumbuhan dan Hewan dengan Lingkungannya', subtitle: 'Kaktus di gurun, teratai di air, dan bunglon berkamuflase', cat: 'Adaptasi Makhluk', fact: 'Bunglon dapat mengubah warna kulitnya sesuai tempat ia berpijak untuk bersembunyi dari musuh!', summary: 'Bentuk adaptasi morfologi, fisiologi, dan tingkah laku makhluk hidup untuk bertahan hidup.' },
      { title: 'Pemanfaatan Energi Listrik dan Penghematan Energi', subtitle: 'Rangkaian seri, paralel, dan pembangkit listrik ramah lingkungan', cat: 'Fisika Energi', fact: 'Pembangkit Listrik Tenaga Surya (PLTS) memanfaatkan cahaya matahari bebas polusi!', summary: 'Membuat rangkaian listrik sederhana dengan baterai dan saklar serta budaya hemat listrik.' },
      { title: 'Mengenal Negara-Negara Sahabat Anggota ASEAN', subtitle: 'Kerja sama Indonesia di kawasan Asia Tenggara', cat: 'Hubungan Internasional', fact: 'ASEAN didirikan di Bangkok pada tahun 1967 dan kantor sekretariatnya berada di Jakarta!', summary: 'Profil 10 negara anggota ASEAN, lambang ikat padi, dan kerja sama ekonomi serta pendidikan.' }
    ]
  };

  const configs = gradeConfigs[grade] || [];
  return configs.map((cfg, index) => {
    const chapter = index + 1;
    return {
      id: `ipas_g${grade}_t${chapter}`,
      subjectId: 'ipas',
      grade,
      chapterNumber: chapter,
      title: cfg.title,
      subtitle: cfg.subtitle,
      category: cfg.cat,
      durationMinutes: 7 + chapter,
      funFact: cfg.fact,
      summary: cfg.summary,
      contentParagraphs: [
        `Halo Penjelajah Cilik Kelas ${grade}! Mari bertualang mempelajari "${cfg.title}".`,
        cfg.summary + ' Pelajaran IPAS membuka wawasan kita tentang keagungan alam semesta dan masyarakat nusantara.',
        `Boni mengajakmu selalu mengamati gejala di sekitarmu dengan rasa ingin tahu yang tinggi dan mencintai tanah air!`
      ],
      keyPoints: [
        `Pahami konsep sains dan sosial dari ${cfg.title}.`,
        'Amati bukti nyata fenomena ini di lingkungan sekitarmu.',
        'Jaga kelestarian alam dan rawat keharmonisan masyarakat.'
      ],
      illustrations: [
        { emoji: '🔬', title: 'Sains Eksplorasi', caption: cfg.title },
        { emoji: '🌍', title: 'Bumi & Sosial', caption: cfg.subtitle },
        { emoji: '🌱', title: 'Kelestarian', caption: 'Peduli lingkungan' }
      ],
      examples: [
        {
          question: `Bagaimana fenomena "${cfg.title}" berdampak langsung bagi manusia?`,
          steps: [
            'Langkah 1: Identifikasi faktor alam atau sosial yang terjadi.',
            'Langkah 2: Amati hubungan sebab-akibat fenomena tersebut.',
            'Langkah 3: Terapkan sikap bijak dan peduli terhadap lingkungan.'
          ],
          answer: `Menerapkan pemahaman ${cfg.title} untuk hidup selaras dengan alam dan sesama.`,
          tip: 'Amati gejala alam dengan rasa syukur.'
        }
      ],
      exercises: [
        {
          id: `ipas_g${grade}_t${chapter}_ex1`,
          type: 'multiple_choice',
          prompt: `Apa manfaat utama mempelajari fenomena ${cfg.title}?`,
          options: [
            `Memahami ${cfg.subtitle} dan menjaga kelestarian alam`,
            'Merusak lingkungan sekitar',
            'Mengabaikan kebersihan',
            'Menolak ilmu pengetahuan'
          ],
          correctOptionIndex: 0,
          explanation: `Dengan mempelajari materi ini kita dapat memahami ${cfg.subtitle} dan menjaga bumi.`,
          hint: 'Pilihlah tujuan mulia ilmu pengetahuan.',
          praiseMessage: 'Luar biasa! Pemikiranmu seperti ilmuwan cilik!',
          points: 25
        },
        {
          id: `ipas_g${grade}_t${chapter}_ex2`,
          type: 'true_false',
          prompt: `Menjaga keseimbangan alam pada materi ${cfg.title} adalah tanggung jawab seluruh anak Indonesia.`,
          isTrue: true,
          explanation: 'Benar! Menjaga bumi adalah tugas mulia kita bersama demi masa depan.',
          hint: 'Apakah kita wajib merawat lingkungan hidup?',
          praiseMessage: 'Tepat sekali! Hebat!',
          points: 25
        },
        {
          id: `ipas_g${grade}_t${chapter}_ex3`,
          type: 'fill_blank',
          prompt: `Sumber energi terbesar dan utama bagi seluruh kehidupan di muka bumi adalah [ ? ] (matahari / lilin / batu bara)`,
          acceptableAnswers: ['matahari', 'Matahari'],
          wordBank: ['matahari', 'baterai', 'lilin', 'lampu'],
          placeholderText: 'Ketik nama sumber energi...',
          explanation: 'Matahari memancarkan energi cahaya dan panas melimpah tanpa henti.',
          hint: 'Bintang raksasa di pusat tata surya.',
          praiseMessage: 'Hebat! Matahari sang sumber kehidupan!',
          points: 25
        },
        {
          id: `ipas_g${grade}_t${chapter}_ex4`,
          type: 'matching',
          prompt: 'Jodohkan konsep alam dengan penjelasannya:',
          pairs: [
            { id: 'p1', leftText: 'Pelestarian Alam', leftEmoji: '🌳', rightText: 'Menjaga Keseimbangan Ekosistem', rightEmoji: '🛡️' },
            { id: 'p2', leftText: 'Rasa Ingin Tahu', leftEmoji: '🔍', rightText: 'Mengamati dengan Teliti', rightEmoji: '🧐' },
            { id: 'p3', leftText: 'Kekayaan Nusantara', leftEmoji: '🇮🇩', rightText: 'Rahmat Tuhan untuk Indonesia', rightEmoji: '🌟' }
          ],
          explanation: 'Pelestarian menjaga ekosistem, rasa ingin tahu memicu riset, nusantara adalah karunia Tuhan.',
          hint: 'Hubungkan nilai-nilai sains.',
          praiseMessage: 'Sempurna! Kamu memahami IPAS secara komprehensif!',
          points: 25
        }
      ],
      audioScript: `Selamat datang di petualangan IPAS ${cfg.title} untuk kelas ${grade}. Alam Indonesia penuh keajaiban yang siap kita pelajari bersama Boni!`
    };
  });
}
