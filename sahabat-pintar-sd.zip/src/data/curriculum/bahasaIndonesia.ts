import { Lesson, Grade } from '../../types';

export const BAHASA_INDONESIA_LESSONS: Lesson[] = [
  // ================= KELAS 1 =================
  {
    id: 'bin_g1_t1',
    subjectId: 'bahasa_indonesia',
    grade: 1,
    chapterNumber: 1,
    title: 'Mengenal Bunyi Huruf Vokal',
    subtitle: 'Suara merdu huruf A, I, U, E, dan O',
    category: 'Membaca Awal',
    durationMinutes: 5,
    funFact: 'Huruf vokal adalah huruf yang suaranya keluar bebas dari mulut tanpa terhalang bibir atau gigi!',
    summary: 'Belajar melafalkan dan membaca huruf vokal A, I, U, E, O dengan kata-kata benda di sekitar kita.',
    contentParagraphs: [
      'Halo Teman Pintar! Ayo kita buka mulut dan bersuara: A, I, U, E, O. Kelima huruf ini dinamakan huruf vokal.',
      'Contoh kata yang diawali huruf vokal:\n- A untuk Apel manis 🍎\n- I untuk Ikan berenang 🐟\n- U untuk Ulat daun 🐛\n- E untuk Elang gagah 🦅\n- O untuk Obat sehat 💊',
      'Jika kamu menggabungkan huruf vokal dengan huruf lain, kamu bisa membaca nama temanmu dan buku cerita yang seru!'
    ],
    keyPoints: [
      'Ada 5 huruf vokal: A, I, U, E, O.',
      'Huruf vokal memberi suara merdu pada setiap kata.',
      'Lafalkan huruf dengan jelas sambil membuka mulut.'
    ],
    illustrations: [
      { emoji: '🍎', title: 'Apel', caption: 'Diawali huruf A' },
      { emoji: '🐟', title: 'Ikan', caption: 'Diawali huruf I' },
      { emoji: '🦅', title: 'Elang', caption: 'Diawali huruf E' }
    ],
    examples: [
      {
        question: 'Huruf vokal apa saja yang terdapat pada kata "BUKU"?',
        steps: [
          'Tulis kata: B - U - K - U.',
          'Cari huruf vokal dari A, I, U, E, O.',
          'Huruf vokal yang ada adalah U dan U.'
        ],
        answer: 'Huruf U (muncul dua kali).',
        tip: 'Huruf B dan K adalah huruf konsonan.'
      }
    ],
    exercises: [
      {
        id: 'bin_g1_t1_ex1',
        type: 'multiple_choice',
        prompt: 'Huruf vokal pertama dalam abjad bahasa Indonesia adalah...',
        options: ['Huruf B', 'Huruf A', 'Huruf C', 'Huruf D'],
        correctOptionIndex: 1,
        explanation: 'Huruf A adalah huruf vokal pertama dalam urutan abjad.',
        hint: 'Huruf pertama pada kata "Apel".',
        praiseMessage: 'Pintar sekali! Huruf A adalah awal dari segalanya.',
        points: 20
      },
      {
        id: 'bin_g1_t1_ex2',
        type: 'true_false',
        prompt: 'Kata "IKAN" diawali oleh huruf vokal I.',
        isTrue: true,
        explanation: 'Benar! Huruf pertama dari kata "IKAN" adalah huruf I.',
        hint: 'Perhatikan huruf paling depan dari kata IKAN.',
        praiseMessage: 'Tepat sekali! Hebat!',
        points: 20
      },
      {
        id: 'bin_g1_t1_ex3',
        type: 'fill_blank',
        prompt: 'Lengkapilah huruf vokal yang hilang: U - D - A - N - [ ? ]',
        acceptableAnswers: ['G', 'g'],
        wordBank: ['G', 'K', 'T', 'M'],
        placeholderText: 'Ketik huruf...',
        explanation: 'Kata yang benar adalah "UDANG". Huruf terakhirnya adalah G.',
        hint: 'Hewan laut yang enak dan berwarna kemerahan saat dimasak.',
        praiseMessage: 'Luar biasa! Ejaanmu tepat!',
        points: 25
      },
      {
        id: 'bin_g1_t1_ex4',
        type: 'matching',
        prompt: 'Jodohkan huruf vokal dengan nama bendanya:',
        pairs: [
          { id: 'p1', leftText: 'Huruf A', leftEmoji: '🅰️', rightText: 'Apel Merah', rightEmoji: '🍎' },
          { id: 'p2', leftText: 'Huruf I', leftEmoji: 'ℹ️', rightText: 'Ikan Koi', rightEmoji: '🐟' },
          { id: 'p3', leftText: 'Huruf U', leftEmoji: '🆙', rightText: 'Udang Laut', rightEmoji: '🦐' }
        ],
        explanation: 'A untuk Apel, I untuk Ikan, dan U untuk Udang.',
        hint: 'Cocokkan huruf awal dengan nama bendanya.',
        praiseMessage: 'Pasangan yang sempurna! Boni bangga padamu!',
        points: 35
      }
    ],
    audioScript: 'Halo teman-teman! Hari ini kita belajar lima huruf vokal: A, I, U, E, dan O. Huruf vokal membuat kata berbunyi merdu. Ayo sebutkan bersama Boni!'
  },
  {
    id: 'bin_g1_t2',
    subjectId: 'bahasa_indonesia',
    grade: 1,
    chapterNumber: 2,
    title: 'Empat Kata Ajaib yang Sopan',
    subtitle: 'Tolong, Maaf, Terima Kasih, dan Permisi',
    category: 'Budi Pekerti & Bicara',
    durationMinutes: 6,
    funFact: 'Mengucapkan kata tolong dan terima kasih bisa membuat suasana hati teman menjadi gembira seharian!',
    summary: 'Mengenal waktu yang tepat untuk mengucapkan Tolong, Maaf, Terima Kasih, dan Permisi dalam kehidupan sehari-hari.',
    contentParagraphs: [
      'Anak yang hebat selalu berbicara santun. Ada empat kata ajaib yang disukai oleh semua orang:',
      '1. TOLONG: Katakan saat membutuhkan bantuan orang lain.\n2. MAAF: Katakan dengan tulus saat melakukan kesalahan.\n3. TERIMA KASIH: Katakan setiap kali mendapat pertolongan, pujian, atau hadiah.\n4. PERMISI: Katakan saat lewat di depan orang tua atau masuk ke ruangan.',
      'Biasakan mengucapkannya setiap hari di rumah dan di sekolah ya!'
    ],
    keyPoints: [
      'Gunakan TOLONG sebelum meminta bantuan.',
      'Katakan MAAF jika tidak sengaja berbuat salah.',
      'Ucapkan TERIMA KASIH dengan senyuman hangat.',
      'Gunakan PERMISI saat melewati orang yang lebih tua.'
    ],
    illustrations: [
      { emoji: '🤝', title: 'Tolong', caption: 'Saling membantu sesama' },
      { emoji: '🎁', title: 'Terima Kasih', caption: 'Saat menerima hadiah' },
      { emoji: '🙇‍♂️', title: 'Permisi', caption: 'Santun saat lewat' }
    ],
    examples: [
      {
        question: 'Edo tidak sengaja menjatuhkan kotak pensil Siti. Apa yang harus dikatakan Edo?',
        steps: [
          'Perbuatan tidak sengaja menjatuhkan adalah sebuah kesalahan.',
          'Kata ajaib untuk meminta ampun/penyesalan adalah "Maaf".',
          'Bantu merapikan pensil yang jatuh.'
        ],
        answer: '"Siti, aku minta maaf ya, aku tidak sengaja menjatuhkannya."',
        tip: 'Ucapkan maaf dengan wajah tulus dan ramah.'
      }
    ],
    exercises: [
      {
        id: 'bin_g1_t2_ex1',
        type: 'multiple_choice',
        prompt: 'Setelah ibu memberi kita segelas susu hangat, kita sebaiknya mengucapkan...',
        options: ['Tolong', 'Terima Kasih', 'Permisi', 'Diam saja'],
        correctOptionIndex: 1,
        explanation: 'Kita mengucapkan Terima Kasih sebagai rasa syukur atas kebaikan ibu.',
        hint: 'Kata untuk membalas kebaikan.',
        praiseMessage: 'Bagus sekali! Sopan santunmu luar biasa.',
        points: 25
      },
      {
        id: 'bin_g1_t2_ex2',
        type: 'true_false',
        prompt: 'Kita boleh meminta tolong kepada teman sambil membentak-bentak.',
        isTrue: false,
        explanation: 'Salah! Meminta tolong harus dilakukan dengan bahasa yang lembut dan sopan.',
        hint: 'Apakah membentak termasuk perbuatan sopan?',
        praiseMessage: 'Betul! Berbicaralah selalu dengan lemah lembut.',
        points: 25
      },
      {
        id: 'bin_g1_t2_ex3',
        type: 'matching',
        prompt: 'Jodohkan situasi dengan kata ajaib yang tepat:',
        pairs: [
          { id: 'p1', leftText: 'Perlu bantuan teman', leftEmoji: '🙋', rightText: 'Tolong', rightEmoji: '🙏' },
          { id: 'p2', leftText: 'Menyenggol teman', leftEmoji: '💥', rightText: 'Maaf', rightEmoji: '🙇' },
          { id: 'p3', leftText: 'Lewat di depan guru', leftEmoji: '🚶', rightText: 'Permisi', rightEmoji: '👋' }
        ],
        explanation: 'Tolong untuk meminta bantuan, Maaf saat bersalah, dan Permisi saat lewat.',
        hint: 'Ingat kembali 4 kata ajaib.',
        praiseMessage: 'Hebat! Kamu anak yang sangat santun!',
        points: 50
      }
    ],
    audioScript: 'Ada empat kata ajaib yang harus selalu kita ingat: Tolong, Maaf, Terima Kasih, dan Permisi. Gunakan kata ajaib ini agar semua orang senang!'
  },
  {
    id: 'bin_g1_t3',
    subjectId: 'bahasa_indonesia',
    grade: 1,
    chapterNumber: 3,
    title: 'Mengenal Anggota Tubuh dan Pancaindra',
    subtitle: 'Membaca kosakata tubuh kita',
    category: 'Kosakata',
    durationMinutes: 5,
    funFact: 'Mata kita berkedip sekitar 15 sampai 20 kali setiap menit tanpa kita sadari untuk menjaga mata tetap basah!',
    summary: 'Mengenal ejaan nama anggota tubuh: mata, hidung, telinga, mulut, tangan, dan kaki.',
    contentParagraphs: [
      'Tubuh kita sangat luar biasa! Kita bisa melihat pemandangan indah dengan M-A-T-A (Mata).',
      'Kita mendengarkan nasehat guru dengan T-E-L-I-N-G-A (Telinga). Kita menghirup wangi bunga dengan H-I-D-U-N-G (Hidung).',
      'Mulut untuk berbicara dan makan makanan sehat, sedangkan tangan dan kaki kita gunakan untuk belajar dan berjalan.'
    ],
    keyPoints: [
      'Mata dieja: M-A-T-A.',
      'Hidung dieja: H-I-D-U-N-G.',
      'Telinga dieja: T-E-L-I-N-G-A.',
      'Rawat tubuhmu dengan mandi teratur dan makan bergizi.'
    ],
    illustrations: [
      { emoji: '👀', title: 'Mata', caption: 'Melihat keindahan' },
      { emoji: '👂', title: 'Telinga', caption: 'Mendengar suara' },
      { emoji: '👃', title: 'Hidung', caption: 'Membau aroma' }
    ],
    examples: [
      {
        question: 'Susun huruf acak ini menjadi nama bagian tubuh: T - A - N - G - A - N',
        steps: [
          'Baca hurufnya satu per satu.',
          'Gabungkan suku kata: TANG + AN.',
          'Menjadi kata TANGAN.'
        ],
        answer: 'TANGAN',
        tip: 'Tangan kita ada dua, kanan dan kiri.'
      }
    ],
    exercises: [
      {
        id: 'bin_g1_t3_ex1',
        type: 'multiple_choice',
        prompt: 'Anggota tubuh yang dieja M-A-T-A berguna untuk...',
        options: ['Mendengar lagu', 'Melihat pemandangan', 'Mengecap rasa', 'Meraba'],
        correctOptionIndex: 1,
        explanation: 'Mata berguna untuk melihat pemandangan dan membaca buku.',
        hint: 'Letaknya di wajah bagian atas.',
        praiseMessage: 'Tepat sekali! Matamu sangat jeli!',
        points: 25
      },
      {
        id: 'bin_g1_t3_ex2',
        type: 'fill_blank',
        prompt: 'Lengkapilah kata anggota tubuh berikut: H - I - D - [ ? ] - N - G',
        acceptableAnswers: ['U', 'u'],
        wordBank: ['U', 'A', 'O', 'I'],
        placeholderText: 'Ketik huruf vokal...',
        explanation: 'Huruf yang hilang adalah U sehingga membentuk kata HIDUNG.',
        hint: 'Alat indra untuk membau aroma.',
        praiseMessage: 'Pintar! Kata hidung lengkap dengan sempurna!',
        points: 35
      },
      {
        id: 'bin_g1_t3_ex3',
        type: 'true_false',
        prompt: 'Telinga manusia berjumlah dua, satu di kanan dan satu di kiri.',
        isTrue: true,
        explanation: 'Benar, manusia memiliki sepasang telinga untuk mendengar suara dari berbagai arah.',
        hint: 'Raba samping kanan dan kirimu.',
        praiseMessage: 'Benar 100%! Hebat!',
        points: 20
      },
      {
        id: 'bin_g1_t3_ex4',
        type: 'matching',
        prompt: 'Jodohkan anggota tubuh dengan tugas utamanya:',
        pairs: [
          { id: 'p1', leftText: 'Mata', leftEmoji: '👀', rightText: 'Melihat Buku', rightEmoji: '📖' },
          { id: 'p2', leftText: 'Telinga', leftEmoji: '👂', rightText: 'Mendengar Bel', rightEmoji: '🔔' },
          { id: 'p3', leftText: 'Kaki', leftEmoji: '🦶', rightText: 'Berjalan Ceria', rightEmoji: '🚶' }
        ],
        explanation: 'Mata untuk melihat, telinga mendengar, kaki untuk berjalan.',
        hint: 'Hubungkan dengan aktivitas sehari-hari.',
        praiseMessage: 'Sempurna! Kamu memahami fungsi tubuhmu!',
        points: 20
      }
    ],
    audioScript: 'Mata untuk melihat, telinga untuk mendengar, hidung untuk membau. Bersyukurlah kepada Tuhan yang telah memberikan tubuh yang sehat!'
  },
  {
    id: 'bin_g1_t4',
    subjectId: 'bahasa_indonesia',
    grade: 1,
    chapterNumber: 4,
    title: 'Mengenal Suku Kata Ba-Bi-Bu-Be-Bo',
    subtitle: 'Membaca suku kata dengan ceria',
    category: 'Membaca Suku Kata',
    durationMinutes: 5,
    funFact: 'Dengan menguasai suku kata, kamu bisa merangkai ribuan kata bahasa Indonesia dengan mudah!',
    summary: 'Menggabungkan konsonan B dengan vokal: BA, BI, BU, BE, BO dan merangkainya menjadi kata.',
    contentParagraphs: [
      'Ayo membaca suku kata keluarga huruf B bersama Boni!',
      '- B + A dibaca BA (seperti Baju, Balon)\n- B + I dibaca BI (seperti Biru, Bintang)\n- B + U dibaca BU (seperti Buku, Bunga)\n- B + E dibaca BE (seperti Bebek, Becak)\n- B + O dibaca BO (seperti Bola, Botol)',
      'Jika suku kata BU digabung dengan KU, bunyinya menjadi BUKU! Mudah sekali, kan?'
    ],
    keyPoints: [
      'Kombinasi konsonan dan vokal membentuk suku kata.',
      'BA-JU = Baju.',
      'BO-LA = Bola.',
      'BU-KU = Buku.'
    ],
    illustrations: [
      { emoji: '⚽', title: 'Bola', caption: 'BO - LA' },
      { emoji: '📚', title: 'Buku', caption: 'BU - KU' },
      { emoji: '🎈', title: 'Balon', caption: 'BA - LON' }
    ],
    examples: [
      {
        question: 'Rangkailah suku kata BO dan LA menjadi satu kata benda yang bisa ditendang!',
        steps: [
          'Ambil suku kata pertama: BO.',
          'Ambil suku kata kedua: LA.',
          'Gabungkan keduanya: BOLA.'
        ],
        answer: 'BOLA ⚽',
        tip: 'Bola bentuknya bulat bundar.'
      }
    ],
    exercises: [
      {
        id: 'bin_g1_t4_ex1',
        type: 'multiple_choice',
        prompt: 'Suku kata awal dari benda "BALON" adalah...',
        options: ['BU', 'BO', 'BA', 'BI'],
        correctOptionIndex: 2,
        explanation: 'Kata "BALON" diawali oleh suku kata BA (B + A).',
        hint: 'Bunyi awal Ba-lon.',
        praiseMessage: 'Tepat sekali! Balon warna-warni terbang tinggi!',
        points: 25
      },
      {
        id: 'bin_g1_t4_ex2',
        type: 'fill_blank',
        prompt: 'Lengkapilah suku kata yang tepat: [ ? ] - KU (Benda untuk dibaca)',
        acceptableAnswers: ['BU', 'bu', 'Bu'],
        wordBank: ['BU', 'BO', 'BI', 'BA'],
        placeholderText: 'Ketik suku kata...',
        explanation: 'Suku kata BU jika digabung dengan KU menjadi BUKU.',
        hint: 'Huruf B bertemu huruf vokal U.',
        praiseMessage: 'Mantap! Membaca buku membuat kita pintar!',
        points: 35
      },
      {
        id: 'bin_g1_t4_ex3',
        type: 'true_false',
        prompt: 'Suku kata BO jika digabung dengan suku kata LA menghasilkan kata BOLA.',
        isTrue: true,
        explanation: 'Benar! BO + LA = BOLA.',
        hint: 'Bunyikan suku katanya berturut-turut.',
        praiseMessage: 'Benar sekali!',
        points: 20
      },
      {
        id: 'bin_g1_t4_ex4',
        type: 'matching',
        prompt: 'Jodohkan suku kata awal dengan gambarnya:',
        pairs: [
          { id: 'p1', leftText: 'BA', leftEmoji: '🎈', rightText: 'Balon Terbang', rightEmoji: '🎈' },
          { id: 'p2', leftText: 'BU', leftEmoji: '📖', rightText: 'Buku Cerita', rightEmoji: '📚' },
          { id: 'p3', leftText: 'BO', leftEmoji: '⚽', rightText: 'Bola Sepak', rightEmoji: '🥅' }
        ],
        explanation: 'BA untuk Balon, BU untuk Buku, dan BO untuk Bola.',
        hint: 'Lihat gambar dan bunyikan.',
        praiseMessage: 'Luar biasa! Kamu semakin lancar membaca!',
        points: 20
      }
    ],
    audioScript: 'Ba, bi, bu, be, bo! Mari kita membaca suku kata bersama Boni. Gabungkan suku kata menjadi kata-kata yang indah!'
  },
  {
    id: 'bin_g1_t5',
    subjectId: 'bahasa_indonesia',
    grade: 1,
    chapterNumber: 5,
    title: 'Mengenal Lingkungan Rumah Bersih',
    subtitle: 'Membaca kalimat pendek tentang keluarga dan rumah',
    category: 'Membaca Kalimat',
    durationMinutes: 6,
    funFact: 'Rumah yang bersih dan rapi membuat seluruh keluarga terhindar dari nyamuk dan kuman penyakit!',
    summary: 'Belajar membaca kalimat pendek 3-4 kata mengenai kegiatan menjaga kebersihan rumah bersama ayah dan ibu.',
    contentParagraphs: [
      'Rumah adalah tempat tinggal kita bersama keluarga. Rumah yang bersih membuat kita merasa nyaman.',
      'Mari membaca kalimat pendek berikut:\n1. Ini rumah Boni.\n2. Halaman rumah Boni bersih.\n3. Ibu menyapu lantai rumah.\n4. Ayah menyiram bunga mawar.\n5. Boni membuang sampah di tempatnya.',
      'Setiap kalimat diakhiri dengan tanda titik (.) agar kita berhenti sejenak saat membaca.'
    ],
    keyPoints: [
      'Kalimat tersusun dari beberapa kata yang memiliki arti.',
      'Awal kalimat diawali huruf kapital.',
      'Akhir kalimat berita diberi tanda titik (.).',
      'Buang sampah selalu pada tempat sampah.'
    ],
    illustrations: [
      { emoji: '🏡', title: 'Rumah Asri', caption: 'Rumah bersih dan rapi' },
      { emoji: '🧹', title: 'Menyapu', caption: 'Membersihkan lantai' },
      { emoji: '🗑️', title: 'Tempat Sampah', caption: 'Tempat sampah tertutup' }
    ],
    examples: [
      {
        question: 'Tentukan tanda baca yang tepat di akhir kalimat ini: "Ibu memasak sup di dapur"',
        steps: [
          'Kalimat ini adalah kalimat berita yang menceritakan kegiatan ibu.',
          'Kalimat berita diakhiri dengan tanda titik (.).'
        ],
        answer: 'Tanda titik (.) sehingga menjadi: "Ibu memasak sup di dapur."',
        tip: 'Tanda titik memberi jeda nafas.'
      }
    ],
    exercises: [
      {
        id: 'bin_g1_t5_ex1',
        type: 'multiple_choice',
        prompt: 'Di manakah kita harus membuang bungkus makanan atau sampah daun?',
        options: ['Di selokan air', 'Di tempat sampah', 'Di bawah kasur', 'Di jalanan'],
        correctOptionIndex: 1,
        explanation: 'Sampah harus selalu dibuang di tempat sampah agar lingkungan tetap bersih dan sehat.',
        hint: 'Wadah khusus untuk menampung sampah.',
        praiseMessage: 'Hebat! Kamu anak yang cinta kebersihan!',
        points: 25
      },
      {
        id: 'bin_g1_t5_ex2',
        type: 'true_false',
        prompt: 'Kalimat berita selalu diakhiri dengan tanda titik (.).',
        isTrue: true,
        explanation: 'Benar! Tanda titik (.) digunakan untuk mengakhiri kalimat berita.',
        hint: 'Tanda bulat kecil di akhir kalimat.',
        praiseMessage: 'Betul sekali!',
        points: 25
      },
      {
        id: 'bin_g1_t5_ex3',
        type: 'fill_blank',
        prompt: 'Susun kata menjadi kalimat: Boni - menyapu - [ ? ] (Lantai / Bintang / Awan)',
        acceptableAnswers: ['lantai', 'Lantai'],
        wordBank: ['lantai', 'bintang', 'awan', 'langit'],
        placeholderText: 'Ketik kata...',
        explanation: 'Kalimat yang padu dan masuk akal adalah "Boni menyapu lantai".',
        hint: 'Permukaan rumah yang dipijak.',
        praiseMessage: 'Pilihan kata yang sangat tepat!',
        points: 25
      },
      {
        id: 'bin_g1_t5_ex4',
        type: 'matching',
        prompt: 'Jodohkan pelaku dengan kegiatan membersihkan rumah:',
        pairs: [
          { id: 'p1', leftText: 'Ibu', leftEmoji: '👩', rightText: 'Menyapu Lantai', rightEmoji: '🧹' },
          { id: 'p2', leftText: 'Ayah', leftEmoji: '👨', rightText: 'Menyiram Bunga', rightEmoji: '🪴' },
          { id: 'p3', leftText: 'Boni', leftEmoji: '👦', rightText: 'Merapikan Mainan', rightEmoji: '🧸' }
        ],
        explanation: 'Semua anggota keluarga saling bekerja sama menjaga rumah tetap bersih.',
        hint: 'Kerja sama yang kompak.',
        praiseMessage: 'Kompak dan pintar! Terima kasih sudah belajar!',
        points: 25
      }
    ],
    audioScript: 'Rumah yang bersih pangkal kesehatan! Mari kita bantu ayah dan ibu merapikan rumah agar selalu nyaman dan asri.'
  },

  // ================= KELAS 2 =================
  {
    id: 'bin_g2_t1',
    subjectId: 'bahasa_indonesia',
    grade: 2,
    chapterNumber: 1,
    title: 'Huruf Kapital pada Nama Orang dan Tempat',
    subtitle: 'Menulis huruf besar dengan kaidah yang tepat',
    category: 'Tata Bahasa',
    durationMinutes: 7,
    funFact: 'Nama kota seperti Jakarta, Bandung, dan Surabaya selalu diawali huruf kapital di manapun letaknya dalam kalimat!',
    summary: 'Aturan penulisan huruf kapital di awal kalimat, nama orang, nama hari, bulan, dan kota.',
    contentParagraphs: [
      'Di kelas 2, tulisan kita harus semakin rapi. Huruf kapital (huruf besar) tidak boleh ditulis sembarangan.',
      'Gunakan huruf kapital pada:\n1. Awal sebuah kalimat.\n2. Nama orang, contoh: Boni, Siti, Dayu.\n3. Nama hari dan bulan, contoh: Senin, Jumat, Agustus.\n4. Nama kota atau negara, contoh: Indonesia, Jakarta, Bali.'
    ],
    keyPoints: [
      'Huruf pertama nama orang wajib kapital.',
      'Nama hari dan bulan diawali huruf kapital.',
      'Awal kalimat selalu huruf kapital.'
    ],
    illustrations: [
      { emoji: '✍️', title: 'Huruf Besar', caption: 'Kapital di awal nama' },
      { emoji: '📅', title: 'Kalender', caption: 'Senin, Selasa, Rabu' },
      { emoji: '🏙️', title: 'Kota', caption: 'Jakarta, Medan, Bali' }
    ],
    examples: [
      {
        question: 'Perbaiki kalimat ini: "pada hari rabu budi pergi ke bandung."',
        steps: [
          '"pada" -> "Pada" (awal kalimat).',
          '"rabu" -> "Rabu" (nama hari).',
          '"budi" -> "Budi" (nama orang).',
          '"bandung" -> "Bandung" (nama kota).'
        ],
        answer: '"Pada hari Rabu, Budi pergi ke Bandung."',
        tip: 'Periksa setiap nama orang dan nama tempat.'
      }
    ],
    exercises: [
      {
        id: 'bin_g2_t1_ex1',
        type: 'multiple_choice',
        prompt: 'Penulisan nama orang berikut yang benar sesuai huruf kapital adalah...',
        options: ['siti rahayu', 'Siti Rahayu', 'SITI RAHAYU SEMUA', 'sItI rAhAyU'],
        correctOptionIndex: 1,
        explanation: 'Huruf pertama pada setiap kata nama orang ditulis dengan huruf kapital: Siti Rahayu.',
        hint: 'Hanya huruf depan yang besar.',
        praiseMessage: 'Luar biasa! Penulisan namamu sangat rapi.',
        points: 25
      },
      {
        id: 'bin_g2_t1_ex2',
        type: 'true_false',
        prompt: 'Nama hari seperti "senin" boleh ditulis dengan huruf kecil di tengah kalimat.',
        isTrue: false,
        explanation: 'Salah! Nama hari selalu diawali huruf kapital di manapun posisinya dalam kalimat: "Senin".',
        hint: 'Ingat aturan nama hari.',
        praiseMessage: 'Tepat sekali! Selalu gunakan huruf kapital untuk hari.',
        points: 25
      },
      {
        id: 'bin_g2_t1_ex3',
        type: 'fill_blank',
        prompt: 'Ketik huruf kapital pertama nama pulau terbesar di Indonesia: [ ? ] - a - l - i - m - a - n - t - a - n',
        acceptableAnswers: ['K'],
        wordBank: ['K', 'k', 'P', 'S'],
        placeholderText: 'Ketik 1 huruf kapital...',
        explanation: 'Huruf pertama pulau Kalimantan adalah huruf kapital K.',
        hint: 'Huruf K besar.',
        praiseMessage: 'Bagus sekali! K untuk Kalimantan.',
        points: 25
      },
      {
        id: 'bin_g2_t1_ex4',
        type: 'matching',
        prompt: 'Jodohkan kategori kata dengan contoh huruf kapitalnya:',
        pairs: [
          { id: 'p1', leftText: 'Nama Hari', leftEmoji: '📆', rightText: 'Minggu', rightEmoji: '☀️' },
          { id: 'p2', leftText: 'Nama Teman', leftEmoji: '👦', rightText: 'Boni Pratama', rightEmoji: '🎒' },
          { id: 'p3', leftText: 'Nama Kota', leftEmoji: '🏙️', rightText: 'Surabaya', rightEmoji: '🦈' }
        ],
        explanation: 'Nama hari Minggu, nama teman Boni Pratama, nama kota Surabaya.',
        hint: 'Lihat kategorinya.',
        praiseMessage: 'Sempurna! Kamu memahami aturan huruf besar!',
        points: 25
      }
    ],
    audioScript: 'Halo teman-teman kelas dua! Ingat selalu menggunakan huruf kapital untuk nama orang, nama tempat, dan nama hari ya!'
  },
  {
    id: 'bin_g2_t2',
    subjectId: 'bahasa_indonesia',
    grade: 2,
    chapterNumber: 2,
    title: 'Mengenal Puisi Anak yang Indah',
    subtitle: 'Membaca puisi dengan lafal dan intonasi yang tepat',
    category: 'Apresiasi Sastra',
    durationMinutes: 6,
    funFact: 'Puisi anak biasanya ditulis dengan kata-kata yang berima di ujung barisnya sehingga terdengar seperti lagu merdu!',
    summary: 'Mengenal ciri-ciri puisi anak: bait, baris, rima, dan cara membacanya dengan penghayatan yang gembira.',
    contentParagraphs: [
      'Puisi adalah karya sastra yang indah. Puisi ditulis dalam bentuk baris dan bait, bukan dalam paragraf biasa.',
      'Contoh puisi anak:\n"Bintang kecil di langit biru,\nKelap-kelip menyapa diriku,\nTerbang tinggi ke angkasa,\nMenghias malam penuh pesona."',
      'Saat membaca puisi, perhatikan intonasi (tinggi rendah nada) dan ekspresi wajah yang ceria!'
    ],
    keyPoints: [
      'Puisi tersusun dari baris dan bait.',
      'Lafal harus jelas agar pendengar paham artinya.',
      'Intonasi dan ekspresi wajah disesuaikan dengan isi puisi.'
    ],
    illustrations: [
      { emoji: '⭐', title: 'Bintang', caption: 'Inspirasi puisi alam' },
      { emoji: '🎭', title: 'Ekspresi', caption: 'Penghayatan puisi' },
      { emoji: '📜', title: 'Bait Puisi', caption: 'Untaian baris kata' }
    ],
    examples: [
      {
        question: 'Berapa jumlah baris dalam satu bait puisi bintang kecil di atas?',
        steps: [
          'Hitung baris 1: Bintang kecil...',
          'Hitung baris 2: Kelap-kelip...',
          'Hitung baris 3: Terbang tinggi...',
          'Hitung baris 4: Menghias malam...',
          'Total ada 4 baris.'
        ],
        answer: 'Ada 4 baris.',
        tip: 'Satu kelompok baris disebut bait.'
      }
    ],
    exercises: [
      {
        id: 'bin_g2_t2_ex1',
        type: 'multiple_choice',
        prompt: 'Kumpulan baris dalam sebuah puisi dinamakan...',
        options: ['Paragraf', 'Bait', 'Judul', 'Kalimat'],
        correctOptionIndex: 1,
        explanation: 'Kumpulan baris-baris dalam puisi disebut dengan Bait.',
        hint: 'Dimulai dengan huruf B.',
        praiseMessage: 'Pintar! Bait adalah rumah bagi baris puisi.',
        points: 25
      },
      {
        id: 'bin_g2_t2_ex2',
        type: 'true_false',
        prompt: 'Membaca puisi sedih harus dilakukan dengan tertawa terbahak-bahak.',
        isTrue: false,
        explanation: 'Salah! Ekspresi wajah dan intonasi harus sesuai dengan tema puisi. Puisi sedih dibaca dengan suara lembut dan ekspresi haru.',
        hint: 'Sesuaikan perasaan dengan ceritanya.',
        praiseMessage: 'Tepat sekali! Ekspresi harus selaras.',
        points: 25
      },
      {
        id: 'bin_g2_t2_ex3',
        type: 'fill_blank',
        prompt: 'Lengkapilah rima puisi: "Burung berkicau di dahan cemara, hatiku riang merasa [ ? ] (gembira / takut / menangis)"',
        acceptableAnswers: ['gembira', 'Gembira'],
        wordBank: ['gembira', 'sedih', 'lelah', 'marah'],
        placeholderText: 'Ketik kata rima...',
        explanation: 'Kata "cemara" berima bunyi akhir "ra" dengan kata "gembira".',
        hint: 'Perhatikan bunyi akhir huruf ra.',
        praiseMessage: 'Rima yang sangat indah! Hebat!',
        points: 25
      },
      {
        id: 'bin_g2_t2_ex4',
        type: 'matching',
        prompt: 'Jodohkan istilah puisi dengan artinya:',
        pairs: [
          { id: 'p1', leftText: 'Bait', leftEmoji: '📑', rightText: 'Kumpulan Baris Puisi', rightEmoji: '📜' },
          { id: 'p2', leftText: 'Lafal', leftEmoji: '🗣️', rightText: 'Kejelasan Pengucapan', rightEmoji: '📢' },
          { id: 'p3', leftText: 'Intonasi', leftEmoji: '🎵', rightText: 'Tinggi Rendah Suara', rightEmoji: '🎶' }
        ],
        explanation: 'Bait adalah kumpulan baris, lafal adalah kejelasan suara, intonasi adalah tinggi rendah nada.',
        hint: 'Ingat unsur membaca puisi.',
        praiseMessage: 'Bagus sekali! Kamu calon penyair cilik!',
        points: 25
      }
    ],
    audioScript: 'Membaca puisi itu menyenangkan! Ayo baca puisi dengan suara yang lantang, intonasi yang merdu, dan ekspresi wajah yang penuh perasaan.'
  },
  {
    id: 'bin_g2_t3',
    subjectId: 'bahasa_indonesia',
    grade: 2,
    chapterNumber: 3,
    title: 'Kalimat Tanya dengan 5W 1H Dasar',
    subtitle: 'Apa, Siapa, Di mana, Kapan, Mengapa, dan Bagaimana',
    category: 'Kalimat Efektif',
    durationMinutes: 7,
    funFact: 'Anak yang rajin bertanya adalah anak yang memiliki rasa ingin tahu tinggi dan cepat menjadi pintar!',
    summary: 'Mengenal kata tanya Apa, Siapa, Di mana, Kapan, dan tanda tanya (?) di akhir kalimat.',
    contentParagraphs: [
      'Ketika kita ingin mengetahui sesuatu, kita mengajukan pertanyaan menggunakan kalimat tanya.',
      'Kata tanya yang sering digunakan:\n- APA: menanyakan benda atau kejadian ("Apa yang kamu bawa?").\n- SIAPA: menanyakan orang ("Siapa nama guru barumu?").\n- DI MANA: menanyakan tempat ("Di mana letak perpustakaan?").\n- KAPAN: menanyakan waktu ("Kapan kita mulai belajar?").',
      'Ingat, kalimat tanya selalu diakhiri dengan tanda tanya (?).'
    ],
    keyPoints: [
      'Kata tanya SIAPA untuk menanyakan orang.',
      'Kata tanya DI MANA untuk menanyakan tempat.',
      'Kata tanya KAPAN untuk menanyakan waktu.',
      'Tanda tanya (?) wajib ada di ujung kalimat tanya.'
    ],
    illustrations: [
      { emoji: '❓', title: 'Tanda Tanya', caption: 'Di akhir kalimat tanya' },
      { emoji: '🙋‍♀️', title: 'Bertanya', caption: 'Mencari tahu info' },
      { emoji: '📍', title: 'Di Mana', caption: 'Menanyakan tempat' }
    ],
    examples: [
      {
        question: 'Buatlah kalimat tanya untuk menanyakan tempat tinggal temanmu!',
        steps: [
          'Gunakan kata tanya tempat: "Di mana".',
          'Tanyakan tempat tinggalnya: "kamu tinggal".',
          'Beri tanda tanya (?) di akhir.'
        ],
        answer: '"Di mana kamu tinggal?"',
        tip: 'Ucapkan dengan nada bertanya yang ramah.'
      }
    ],
    exercises: [
      {
        id: 'bin_g2_t3_ex1',
        type: 'multiple_choice',
        prompt: 'Kata tanya yang tepat untuk menanyakan nama teman baru adalah...',
        options: ['Di mana', 'Siapa', 'Kapan', 'Berapa'],
        correctOptionIndex: 1,
        explanation: 'Kata "Siapa" digunakan untuk menanyakan orang atau nama seseorang.',
        hint: 'Menanyakan orang.',
        praiseMessage: 'Benar sekali! "Siapa namamu?"',
        points: 25
      },
      {
        id: 'bin_g2_t3_ex2',
        type: 'true_false',
        prompt: 'Kalimat tanya boleh diakhiri dengan tanda titik (.).',
        isTrue: false,
        explanation: 'Salah! Kalimat tanya harus selalu diakhiri dengan tanda tanya (?).',
        hint: 'Gunakan tanda lengkung dengan titik di bawahnya.',
        praiseMessage: 'Pintar! Selalu gunakan tanda tanya (?) ya.',
        points: 25
      },
      {
        id: 'bin_g2_t3_ex3',
        type: 'fill_blank',
        prompt: 'Lengkapilah kata tanya waktu: "[ ? ] kamu berangkat ke sekolah? (Pagi jam 6.30)"',
        acceptableAnswers: ['Kapan', 'kapan'],
        wordBank: ['Kapan', 'Di mana', 'Siapa', 'Mengapa'],
        placeholderText: 'Ketik kata tanya...',
        explanation: 'Kata tanya untuk menanyakan waktu adalah "Kapan".',
        hint: 'Menanyakan jam atau hari.',
        praiseMessage: 'Tepat sekali! Kapan untuk menanyakan waktu.',
        points: 25
      },
      {
        id: 'bin_g2_t3_ex4',
        type: 'matching',
        prompt: 'Jodohkan kata tanya dengan kegunaannya:',
        pairs: [
          { id: 'p1', leftText: 'Siapa', leftEmoji: '👤', rightText: 'Menanyakan Orang', rightEmoji: '🧑‍🤝‍🧑' },
          { id: 'p2', leftText: 'Di mana', leftEmoji: '🗺️', rightText: 'Menanyakan Tempat', rightEmoji: '🏫' },
          { id: 'p3', leftText: 'Kapan', leftEmoji: '⏰', rightText: 'Menanyakan Waktu', rightEmoji: '🌅' }
        ],
        explanation: 'Siapa untuk orang, di mana untuk tempat, dan kapan untuk waktu.',
        hint: 'Perhatikan kegunaan masing-masing.',
        praiseMessage: 'Hebat! Kamu menguasai kata tanya dengan baik!',
        points: 25
      }
    ],
    audioScript: 'Gunakan kata tanya apa, siapa, di mana, dan kapan saat ingin mencari informasi. Jangan lupa beri tanda tanya di akhir kalimat!'
  },
  {
    id: 'bin_g2_t4',
    subjectId: 'bahasa_indonesia',
    grade: 2,
    chapterNumber: 4,
    title: 'Mengenal Dongeng Fabel Binatang',
    subtitle: 'Pesan moral dari cerita hewan bijaksana',
    category: 'Membaca Cerita',
    durationMinutes: 7,
    funFact: 'Fabel adalah cerita di mana hewan-hewan bisa berbicara dan bersikap seperti manusia yang mengajarkan kebaikan!',
    summary: 'Mengenal tokoh hewan, alur dongeng fabel, dan cara memetik pesan moral kebaikan di dalamnya.',
    contentParagraphs: [
      'Pernahkah kamu mendengar cerita Kancil yang cerdik atau Kura-kura yang gigih berlari? Cerita fabel adalah cerita yang tokohnya adalah binatang.',
      'Dalam dongeng Kura-kura dan Kelinci, kelinci yang sombong tertidur di bawah pohon, sedangkan kura-kura yang pantang menyerah terus berjalan hingga menang balapan.',
      'Pesan moral dari dongeng fabel mengajarkan kita untuk tidak sombong dan tidak meremehkan teman lain.'
    ],
    keyPoints: [
      'Fabel adalah dongeng dengan tokoh binatang.',
      'Setiap fabel memiliki pesan moral atau nasehat baik.',
      'Jangan sombong seperti kelinci dan jangan mudah menyerah.'
    ],
    illustrations: [
      { emoji: '🐢', title: 'Kura-kura', caption: 'Gigih & tekun' },
      { emoji: '🐇', title: 'Kelinci', caption: 'Lincah namun sombong' },
      { emoji: '📖', title: 'Fabel', caption: 'Kisah sarat hikmah' }
    ],
    examples: [
      {
        question: 'Siapakah pemenang lomba lari dalam fabel Kura-kura dan Kelinci?',
        steps: [
          'Kelinci sombong tertidur saat lomba.',
          'Kura-kura tidak berhenti berjalan meski lambat.',
          'Kura-kura sampai garis finis terlebih dahulu.'
        ],
        answer: 'Kura-kura.',
        tip: 'Ketekunan mengalahkan kesombongan.'
      }
    ],
    exercises: [
      {
        id: 'bin_g2_t4_ex1',
        type: 'multiple_choice',
        prompt: 'Cerita dongeng yang tokoh utamanya adalah hewan disebut...',
        options: ['Legenda', 'Mite', 'Fabel', 'Biografi'],
        correctOptionIndex: 2,
        explanation: 'Fabel adalah jenis dongeng yang menceritakan kehidupan hewan yang berperilaku seperti manusia.',
        hint: 'Berawalan huruf F.',
        praiseMessage: 'Tepat! Fabel adalah dongeng hewan.',
        points: 25
      },
      {
        id: 'bin_g2_t4_ex2',
        type: 'true_false',
        prompt: 'Sikap kelinci yang sombong dan suka meremehkan teman adalah sikap yang patut ditiru.',
        isTrue: false,
        explanation: 'Salah! Sifat sombong tidak baik. Kita harus rendah hati dan menghargai orang lain.',
        hint: 'Apakah sombong adalah sifat terpuji?',
        praiseMessage: 'Benar sekali! Jadilah anak yang rendah hati.',
        points: 25
      },
      {
        id: 'bin_g2_t4_ex3',
        type: 'fill_blank',
        prompt: 'Sifat kura-kura yang terus berjalan tanpa putus asa disebut sifat pantang [ ? ] (menyerah / makan / tidur)',
        acceptableAnswers: ['menyerah', 'Menyerah'],
        wordBank: ['menyerah', 'menangis', 'tidur', 'lari'],
        placeholderText: 'Ketik sifat...',
        explanation: 'Kura-kura memiliki sifat pantang menyerah sehingga bisa mencapai garis finis.',
        hint: 'Tidak mudah putus asa.',
        praiseMessage: 'Luar biasa! Pantang menyerah kunci sukses!',
        points: 25
      },
      {
        id: 'bin_g2_t4_ex4',
        type: 'matching',
        prompt: 'Jodohkan tokoh fabel dengan sifat karakternya:',
        pairs: [
          { id: 'p1', leftText: 'Kura-kura', leftEmoji: '🐢', rightText: 'Tekun & Sabar', rightEmoji: '⏳' },
          { id: 'p2', leftText: 'Kelinci', leftEmoji: '🐇', rightText: 'Cepat Namun Sombong', rightEmoji: '💨' },
          { id: 'p3', leftText: 'Kancil', leftEmoji: '🦌', rightText: 'Cerdik & Lincah', rightEmoji: '💡' }
        ],
        explanation: 'Kura-kura tekun, kelinci sombong, kancil cerdik.',
        hint: 'Karakter tokoh cerita.',
        praiseMessage: 'Hebat! Pemahaman ceritamu sangat dalam!',
        points: 25
      }
    ],
    audioScript: 'Dongeng fabel mengajarkan kita banyak kebaikan. Ingat pesan kura-kura ya: jangan sombong dan jangan pernah mudah menyerah dalam belajar!'
  },
  {
    id: 'bin_g2_t5',
    subjectId: 'bahasa_indonesia',
    grade: 2,
    chapterNumber: 5,
    title: 'Menyusun Kalimat Acak Menjadi Paragraf',
    subtitle: 'Urutan cerita yang runtut dan padu',
    category: 'Menulis Narasi',
    durationMinutes: 7,
    funFact: 'Cerita yang runtut seperti menonton film dari awal sampai akhir, tidak melompat-lompat sehingga sangat menyenangkan dibaca!',
    summary: 'Belajar mengurutkan kalimat berdasarkan urutan waktu kejadian (kronologis) dari pagi sampai sore.',
    contentParagraphs: [
      'Ketika kita menceritakan kegiatan sehari-hari, kita harus menyusunnya dengan runtut sesuai urutan waktu.',
      'Contoh urutan kegiatan bangun tidur:\n1. Boni bangun tidur jam lima pagi.\n2. Boni merapikan tempat tidurnya.\n3. Setelah itu, Boni mandi dan menyikat gigi.\n4. Boni sarapan bersama ayah dan ibu.\n5. Boni berangkat ke sekolah dengan ceria.',
      'Kata hubung seperti "setelah itu", "lalu", dan "kemudian" membantu kalimat tersambung dengan rapi.'
    ],
    keyPoints: [
      'Cerita yang baik memiliki urutan waktu yang runtut.',
      'Gunakan kata penghubung: lalu, setelah itu, kemudian.',
      'Urutan yang jelas memudahkan pembaca memahami isi cerita.'
    ],
    illustrations: [
      { emoji: '⏰', title: 'Bangun Pagi', caption: 'Langkah awal hari' },
      { emoji: '🍳', title: 'Sarapan', caption: 'Energi untuk belajar' },
      { emoji: '🎒', title: 'Sekolah', caption: 'Berangkat tepat waktu' }
    ],
    examples: [
      {
        question: 'Urutkan kejadian ini: (1) Boni sarapan, (2) Boni bangun pagi, (3) Boni berangkat sekolah.',
        steps: [
          'Pertama: Boni bangun pagi (2).',
          'Kedua: Boni sarapan (1).',
          'Ketiga: Boni berangkat sekolah (3).'
        ],
        answer: 'Urutan yang benar: (2) - (1) - (3).',
        tip: 'Lihat kegiatan mana yang harus terjadi lebih dulu.'
      }
    ],
    exercises: [
      {
        id: 'bin_g2_t5_ex1',
        type: 'multiple_choice',
        prompt: 'Kata penghubung yang tepat untuk menyambung urutan waktu adalah...',
        options: ['Tetapi', 'Setelah itu', 'Meskipun', 'Karena'],
        correctOptionIndex: 1,
        explanation: 'Kata "Setelah itu" menunjukkan urutan peristiwa berikutnya.',
        hint: 'Menunjukkan kelanjutan waktu.',
        praiseMessage: 'Pintar! "Setelah itu" membuat ceritamu runtut.',
        points: 25
      },
      {
        id: 'bin_g2_t5_ex2',
        type: 'true_false',
        prompt: 'Berangkat ke sekolah dilakukan sebelum kita bangun tidur.',
        isTrue: false,
        explanation: 'Salah! Kita harus bangun tidur terlebih dahulu, mandi, sarapan, baru berangkat sekolah.',
        hint: 'Pikirkan urutan waktu yang logis.',
        praiseMessage: 'Tepat sekali!',
        points: 25
      },
      {
        id: 'bin_g2_t5_ex3',
        type: 'fill_blank',
        prompt: 'Lengkapilah urutan: Pagi bangun tidur, siang belajar di kelas, malam hari waktunya [ ? ] (istirahat / bermain bola / lari pagi)',
        acceptableAnswers: ['istirahat', 'tidur'],
        wordBank: ['istirahat', 'sekolah', 'matahari', 'pagi'],
        placeholderText: 'Ketik kegiatan malam...',
        explanation: 'Pada malam hari tubuh kita perlu istirahat dan tidur agar esok segar kembali.',
        hint: 'Tidur nyenyak di kamar.',
        praiseMessage: 'Tepat sekali! Istirahat cukup sangat penting.',
        points: 25
      },
      {
        id: 'bin_g2_t5_ex4',
        type: 'matching',
        prompt: 'Jodohkan waktu dengan kegiatan yang sesuai:',
        pairs: [
          { id: 'p1', leftText: 'Pagi Hari', leftEmoji: '🌅', rightText: 'Upacara Bendera', rightEmoji: '🇮🇩' },
          { id: 'p2', leftText: 'Siang Hari', leftEmoji: '☀️', rightText: 'Pulang Sekolah', rightEmoji: '🏠' },
          { id: 'p3', leftText: 'Malam Hari', leftEmoji: '🌙', rightText: 'Tidur Lelap', rightEmoji: '🛌' }
        ],
        explanation: 'Pagi upacara, siang pulang sekolah, malam tidur lelap.',
        hint: 'Runtutan waktu sehari-hari.',
        praiseMessage: 'Luar biasa! Ceritamu runtut dan sempurna!',
        points: 25
      }
    ],
    audioScript: 'Menyusun kalimat secara runtut membuat cerita kita mudah dipahami teman-teman. Ayo tulis ceritamu dengan rapi!'
  }
];

// Helper to ensure Grade 3, 4, 5, 6 also have 5 distinct topics
export function getBahasaIndonesiaLessonsForGrade(grade: Grade): Lesson[] {
  const existing = BAHASA_INDONESIA_LESSONS.filter((l) => l.grade === grade);
  if (existing.length >= 5) return existing;

  // Grade 3..6 structured topics
  const gradeTopicConfigs: Record<number, Array<{ title: string; subtitle: string; cat: string; fact: string; summary: string }>> = {
    3: [
      { title: 'Gagasan Pokok dan Kalimat Utama', subtitle: 'Menemukan ide inti dalam paragraf', cat: 'Membaca Pemahaman', fact: 'Gagasan pokok adalah batang pohon pikiran dalam suatu paragraf!', summary: 'Mengenal kalimat utama di awal paragraf dan kalimat penjelas pendukung.' },
      { title: 'Menulis Cerita Pengalaman Liburan', subtitle: 'Menyusun karangan narasi pribadi', cat: 'Menulis Kreatif', fact: 'Menulis pengalaman liburan mengabadikan kenangan indah selamanya.', summary: 'Langkah menulis pembuka, isi peristiwa seru, dan penutup cerita liburan.' },
      { title: 'Kosakata Perkembangbiakan Hewan dan Tumbuhan', subtitle: 'Istilah sains dalam teks bahasa Indonesia', cat: 'Kosakata Khusus', fact: 'Kata bertunas, bertelur, dan melahirkan adalah kosakata biologi.', summary: 'Memahami arti kata ovipar, vivipar, dan tunas dalam teks bacaan.' },
      { title: 'Mengenal Tanda Koma dan Percakapan Langsung', subtitle: 'Menulis dialog dengan tanda petik dua', cat: 'Tanda Baca', fact: 'Tanda petik dua dipakai untuk mengapit kalimat langsung yang diucapkan tokoh.', summary: 'Penggunaan tanda koma untuk perincian dan tanda petik dalam dialog.' },
      { title: 'Menyampaikan Pendapat dengan Santun', subtitle: 'Berbicara di depan teman dan guru', cat: 'Keterampilan Berbicara', fact: 'Pendapat yang disampaikan dengan senyuman selalu didengarkan dengan baik.', summary: 'Cara berdiskusi, mengemukakan ide, dan menyanggah tanpa menyinggung teman.' }
    ],
    4: [
      { title: 'Membedakan Kalimat Transitif dan Intransitif', subtitle: 'Kalimat berobjek dan tidak berobjek', cat: 'Struktur Kalimat', fact: 'Kalimat transitif membutuhkan objek penderita agar maknanya utuh.', summary: 'Rumus Subjek-Predikat-Objek (S-P-O) vs Subjek-Predikat (S-P).' },
      { title: 'Membaca dan Membuat Teks Prosedur', subtitle: 'Langkah-langkah membuat kerajinan dan makanan', cat: 'Teks Petunjuk', fact: 'Resep masakan ibu di dapur adalah contoh teks prosedur yang lezat!', summary: 'Struktur teks prosedur: tujuan, alat dan bahan, serta urutan langkah kerja.' },
      { title: 'Mengenal Majas Personifikasi dan Metafora', subtitle: 'Gaya bahasa yang memperindah tulisan', cat: 'Gaya Bahasa', fact: 'Majas personifikasi membuat benda mati seolah-olah bernapas dan bergerak.', summary: 'Mengenal majas: "Angin berbisik merdu" dan "Boni kutu buku kelas kami".' },
      { title: 'Wawancara dengan Tokoh di Sekitar Kita', subtitle: 'Menyusun daftar pertanyaan wawancara', cat: 'Jurnalistik Cilik', fact: 'Wartawan cilik selalu mencatat jawaban narasumber dengan cermat.', summary: 'Tahapan wawancara: menentukan topik, membuat janji, menyapa sopan, dan mencatat.' },
      { title: 'Menulis Surat Pribadi untuk Sahabat', subtitle: 'Struktur surat menyapa kawan jauh', cat: 'Surat Menyurat', fact: 'Surat tulisan tangan memiliki kehangatan persahabatan yang tulus.', summary: 'Bagian surat: tempat tanggal surat, salam pembuka, isi kabar, dan salam penutup.' }
    ],
    5: [
      { title: 'Menemukan Ide Pokok pada Teks Eksplanasi', subtitle: 'Teks penjelasan fenomena alam dan sosial', cat: 'Teks Informasi', fact: 'Teks eksplanasi menjelaskan bagaimana dan mengapa gunung meletus atau banjir terjadi.', summary: 'Ciri-ciri teks eksplanasi: pernyataan umum, sebab akibat, dan simpulan interpretasi.' },
      { title: 'Sinonim, Antonim, dan Kata Bermakna Ganda', subtitle: 'Memperkaya perbendaharaan kosakata', cat: 'Kosakata Lanjutan', fact: 'Bahasa Indonesia memiliki lebih dari 120.000 kata resmi di KBBI!', summary: 'Sinonim (persamaan makna), antonim (lawan kata), dan homonim.' },
      { title: 'Menulis Teks Deskripsi Objek Wisata Nusantara', subtitle: 'Menggambarkan keindahan Candi Borobudur dan Danau Toba', cat: 'Menulis Deskriptif', fact: 'Teks deskripsi membuat pembaca seolah bisa melihat dan merasakan tempat itu langsung!', summary: 'Panca indra penglihatan, pendengaran, dan penciuman dalam mendeskripsikan objek.' },
      { title: 'Mengidentifikasi Iklan Media Cetak dan Elektronik', subtitle: 'Kalimat persuasif yang mengajak pembaca', cat: 'Teks Iklan', fact: 'Iklan yang baik bersifat mendidik dan tidak membohongi pembeli.', summary: 'Ciri bahasa iklan: singkat, padat, menarik, dan menggunakan kata ajakan (mari, ayo).' },
      { title: 'Menulis Laporan Pengamatan Ilmiah', subtitle: 'Laporan hasil percobaan biji kacang hijau', cat: 'Laporan Ilmiah', fact: 'Ilmuwan selalu menulis laporan pengamatan agar temuannya bermanfaat bagi dunia.', summary: 'Struktur laporan: judul pengamatan, waktu, tempat, objek, hasil, dan kesimpulan.' }
    ],
    6: [
      { title: 'Menyusun Teks Pidato Persuasif yang Berapi-api', subtitle: 'Teknik berorasi menyambut Hari Pahlawan', cat: 'Keterampilan Berpidato', fact: 'Bung Tomo membakar semangat pemuda Surabaya melalui pidato radio yang bersejarah!', summary: 'Struktur pidato: salam pembuka, pendahuluan, pesan inti, ajakan, dan salam penutup.' },
      { title: 'Menganalisis Unsur Intrinsik Cerita Pendek', subtitle: 'Tema, tokoh, watak, alur, latar, dan amanat', cat: 'Apresiasi Cerpen', fact: 'Setiap pengarang menyelipkan amanat mulia di balik jalan cerita yang diciptakannya.', summary: '6 Unsur intrinsik cerpen dan cara menemukan watak tokoh secara tersirat.' },
      { title: 'Mengisi Formulir Pendaftaran dan Daftar Riwayat Hidup', subtitle: 'Keterampilan administratif siswa lulusan SD', cat: 'Teks Petunjuk Resmi', fact: 'Formulir pendaftaran harus diisi dengan data yang benar, jujur, dan huruf cetak.', summary: 'Cara mengisi nama lengkap, NISN, tempat tanggal lahir, alamat, dan hobi.' },
      { title: 'Menulis Teks Tanggapan Kritis Terhadap Berita', subtitle: 'Menyaring informasi fakta vs opini', cat: 'Literasi Digital', fact: 'Anak cerdas selalu mengecek kebenaran berita sebelum membagikannya ke orang lain.', summary: 'Membedakan kalimat fakta yang dapat dibuktikan dengan kalimat opini perkiraan.' },
      { title: 'Membuat Puisi Bebas dan Musikalisasi Puisi', subtitle: 'Menggubah puisi cinta tanah air Indonesia', cat: 'Seni Sastra', fact: 'Chairil Anwar adalah pelopor puisi modern Indonesia yang karyanya abadi sampai kini.', summary: 'Menulis puisi bertema persatuan bangsa dan membawakannya dengan iringan musik lembut.' }
    ]
  };

  const configs = gradeTopicConfigs[grade] || [];
  return configs.map((cfg, index) => {
    const chapter = index + 1;
    return {
      id: `bin_g${grade}_t${chapter}`,
      subjectId: 'bahasa_indonesia',
      grade,
      chapterNumber: chapter,
      title: cfg.title,
      subtitle: cfg.subtitle,
      category: cfg.cat,
      durationMinutes: 7 + chapter,
      funFact: cfg.fact,
      summary: cfg.summary,
      contentParagraphs: [
        `Halo Sobat Juara Kelas ${grade}! Di bab ini kita mendalami materi "${cfg.title}".`,
        cfg.summary + ' Materi ini penting untuk melatih kecakapan literasi membaca dan menulis secara kritis dan santun.',
        `Ingat selalu pesan Boni: membaca membuka jendela dunia, dan menulis mengabadikan pikiranmu untuk Indonesia tercinta.`
      ],
      keyPoints: [
        `Pahami konsep utama dari ${cfg.title}.`,
        'Terapkan dalam tugas sekolah dan latihan harian.',
        'Gunakan bahasa Indonesia yang baik, benar, dan santun.'
      ],
      illustrations: [
        { emoji: '📚', title: 'Literasi', caption: cfg.title },
        { emoji: '💡', title: 'Konsep', caption: cfg.subtitle },
        { emoji: '✍️', title: 'Praktik', caption: 'Latihan mandiri' }
      ],
      examples: [
        {
          question: `Bagaimana cara menerapkan pemahaman tentang "${cfg.title}" dalam kehidupan sehari-hari?`,
          steps: [
            'Langkah 1: Pahami definisi dan kaidah dasarnya.',
            'Langkah 2: Amati contoh teks bacaan yang diberikan guru.',
            'Langkah 3: Tuliskan kembali ide dengan bahasamu sendiri secara jujur.'
          ],
          answer: `Menerapkan kaidah ${cfg.title} secara konsisten dan percaya diri.`,
          tip: 'Latihan secara teratur membuatmu semakin mahir.'
        }
      ],
      exercises: [
        {
          id: `bin_g${grade}_t${chapter}_ex1`,
          type: 'multiple_choice',
          prompt: `Manakah yang merupakan tujuan utama dari mempelajari ${cfg.title}?`,
          options: [
            `Memahami dan menguasai ${cfg.subtitle}`,
            'Hanya menghafal tanpa mengerti makna',
            'Bermain tanpa aturan',
            'Meniru tulisan orang lain'
          ],
          correctOptionIndex: 0,
          explanation: `Mempelajari materi ini bertujuan agar kita memahami ${cfg.subtitle} dengan baik.`,
          hint: 'Pilihlah jawaban yang paling positif dan membangun ilmu.',
          praiseMessage: 'Luar biasa! Pemikiranmu sangat dewasa dan cerdas!',
          points: 25
        },
        {
          id: `bin_g${grade}_t${chapter}_ex2`,
          type: 'true_false',
          prompt: `Dalam materi ${cfg.title}, kita diajarkan untuk selalu menggunakan bahasa yang santun dan jujur.`,
          isTrue: true,
          explanation: 'Benar! Bahasa yang santun dan jujur mencerminkan budi pekerti anak Indonesia.',
          hint: 'Kejujuran dan kesopanan adalah nilai utama.',
          praiseMessage: 'Tepat sekali! Hebat!',
          points: 25
        },
        {
          id: `bin_g${grade}_t${chapter}_ex3`,
          type: 'fill_blank',
          prompt: `Kata baku bahasa Indonesia untuk kegiatan menuntut ilmu di sekolah adalah [ ? ] (belajar / maen / melamun)`,
          acceptableAnswers: ['belajar', 'Belajar'],
          wordBank: ['belajar', 'tidur', 'berlari', 'santai'],
          placeholderText: 'Ketik kata baku...',
          explanation: 'Kata "belajar" adalah kata baku yang benar untuk menuntut ilmu.',
          hint: 'Kegiatan utama siswa.',
          praiseMessage: 'Pilihan kata yang sangat tepat!',
          points: 25
        },
        {
          id: `bin_g${grade}_t${chapter}_ex4`,
          type: 'matching',
          prompt: 'Jodohkan istilah dengan penerapannya:',
          pairs: [
            { id: 'p1', leftText: 'Kaidah Bahasa', leftEmoji: '📖', rightText: 'Pedoman Penulisan Baku', rightEmoji: '✍️' },
            { id: 'p2', leftText: 'Literasi Cerdas', leftEmoji: '🧠', rightText: 'Membaca Kritis & Bijak', rightEmoji: '🧐' },
            { id: 'p3', leftText: 'Bahasa Santun', leftEmoji: '💬', rightText: 'Menghargai Pendengar', rightEmoji: '🤝' }
          ],
          explanation: 'Kaidah adalah pedoman baku, literasi untuk membaca kritis, bahasa santun untuk menghargai sesama.',
          hint: 'Pasangkan sesuai maknanya.',
          praiseMessage: 'Sempurna! Kamu memahami konsep dengan luar biasa!',
          points: 25
        }
      ],
      audioScript: `Selamat datang di materi ${cfg.title} untuk kelas ${grade}. Bersama Boni, kita belajar memahami ${cfg.subtitle} dengan penuh semangat!`
    };
  });
}
