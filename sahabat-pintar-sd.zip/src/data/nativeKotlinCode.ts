export interface KotlinSourceFile {
  path: string;
  name: string;
  category: 'build' | 'manifest' | 'activity' | 'database' | 'datastore' | 'theme' | 'ui' | 'ci';
  description: string;
  content: string;
}

export const KOTLIN_PROJECT_FILES: KotlinSourceFile[] = [
  {
    path: 'app/build.gradle.kts',
    name: 'build.gradle.kts',
    category: 'build',
    description: 'Konfigurasi Gradle dengan Jetpack Compose, Material 3, Room, dan DataStore',
    content: `plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.ksp)
}

android {
    namespace = "id.sahabatpintar.sd"
    compileSdk = 35

    defaultConfig {
        applicationId = "id.sahabatpintar.sd"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
}

dependencies {
    // Jetpack Compose & Material 3
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.graphics)
    implementation(libs.androidx.compose.ui.tooling.preview)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.navigation.compose)
    implementation(libs.androidx.compose.material.icons.extended)

    // AndroidX & Lifecycle
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.androidx.activity.compose)

    // Room Local Database
    implementation(libs.androidx.room.runtime)
    implementation(libs.androidx.room.ktx)
    ksp(libs.androidx.room.compiler)

    // Jetpack DataStore Preferences
    implementation(libs.androidx.datastore.preferences)

    // Android Text-To-Speech & Coroutines
    implementation(libs.kotlinx.coroutines.android)
}`
  },
  {
    path: 'app/src/main/AndroidManifest.xml',
    name: 'AndroidManifest.xml',
    category: 'manifest',
    description: 'Manifest Android native dengan konfigurasi layar portrait dan tema Material 3',
    content: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">

    <application
        android:name=".SahabatPintarApplication"
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.SahabatPintarSD">

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:screenOrientation="portrait"
            android:theme="@style/Theme.SahabatPintarSD">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>

</manifest>`
  },
  {
    path: 'app/src/main/java/id/sahabatpintar/sd/MainActivity.kt',
    name: 'MainActivity.kt',
    category: 'activity',
    description: 'Entry point aplikasi Android dengan Jetpack Compose Navigation host',
    content: `package id.sahabatpintar.sd

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import id.sahabatpintar.sd.ui.screens.HomeScreen
import id.sahabatpintar.sd.ui.screens.SubjectScreen
import id.sahabatpintar.sd.ui.screens.QuizScreen
import id.sahabatpintar.sd.ui.theme.SahabatPintarTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SahabatPintarTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    SahabatPintarAppNav()
                }
            }
        }
    }
}

@Composable
fun SahabatPintarAppNav() {
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = "home"
    ) {
        composable("home") {
            HomeScreen(
                onSubjectClick = { subjectId, grade ->
                    navController.navigate("subject/\$subjectId/\$grade")
                },
                onProfileClick = {
                    navController.navigate("profile")
                }
            )
        }
        composable("subject/{subjectId}/{grade}") { backStackEntry ->
            val subjectId = backStackEntry.arguments?.getString("subjectId") ?: "matematika"
            val grade = backStackEntry.arguments?.getString("grade")?.toIntOrNull() ?: 1
            SubjectScreen(
                subjectId = subjectId,
                grade = grade,
                onBack = { navController.popBackStack() },
                onStartQuiz = { quizId ->
                    navController.navigate("quiz/\$quizId")
                }
            )
        }
        composable("quiz/{quizId}") { backStackEntry ->
            val quizId = backStackEntry.arguments?.getString("quizId") ?: ""
            QuizScreen(
                quizId = quizId,
                onFinish = { navController.popBackStack() }
            )
        }
    }
}`
  },
  {
    path: 'app/src/main/java/id/sahabatpintar/sd/data/local/AppDatabase.kt',
    name: 'AppDatabase.kt',
    category: 'database',
    description: 'Room Database & Entity untuk penyimpanan lokal tanpa kuota internet',
    content: `package id.sahabatpintar.sd.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "completed_lessons")
data class CompletedLessonEntity(
    @PrimaryKey val lessonId: String,
    val subjectId: String,
    val grade: Int,
    val completedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "quiz_results")
data class QuizResultEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val quizId: String,
    val subjectId: String,
    val grade: Int,
    val score: Int,
    val totalQuestions: Int,
    val starsEarned: Int,
    val timestamp: Long = System.currentTimeMillis()
)

@Dao
interface LessonDao {
    @Query("SELECT * FROM completed_lessons WHERE grade = :grade")
    fun getCompletedLessonsByGrade(grade: Int): Flow<List<CompletedLessonEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun markLessonCompleted(lesson: CompletedLessonEntity)

    @Insert
    suspend fun insertQuizResult(result: QuizResultEntity)

    @Query("SELECT * FROM quiz_results ORDER BY timestamp DESC LIMIT 30")
    fun getAllQuizResults(): Flow<List<QuizResultEntity>>

    @Query("SELECT SUM(starsEarned) FROM quiz_results")
    fun getTotalQuizStars(): Flow<Int?>
}

@Database(
    entities = [CompletedLessonEntity::class, QuizResultEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun lessonDao(): LessonDao
}`
  },
  {
    path: 'app/src/main/java/id/sahabatpintar/sd/data/datastore/UserPreferencesRepository.kt',
    name: 'UserPreferencesRepository.kt',
    category: 'datastore',
    description: 'Jetpack DataStore Preferences untuk profil siswa dan pengaturan bintang',
    content: `package id.sahabatpintar.sd.data.datastore

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.userDataStore: DataStore<Preferences> by preferencesDataStore(name = "user_prefs")

class UserPreferencesRepository(private val context: Context) {

    private object PreferencesKeys {
        val STUDENT_NAME = stringPreferencesKey("student_name")
        val STUDENT_GRADE = intPreferencesKey("student_grade")
        val AVATAR_ID = stringPreferencesKey("avatar_id")
        val TOTAL_STARS = intPreferencesKey("total_stars")
        val SOUND_ENABLED = booleanPreferencesKey("sound_enabled")
    }

    val studentGrade: Flow<Int> = context.userDataStore.data.map { preferences ->
        preferences[PreferencesKeys.STUDENT_GRADE] ?: 1
    }

    val totalStars: Flow<Int> = context.userDataStore.data.map { preferences ->
        preferences[PreferencesKeys.TOTAL_STARS] ?: 10
    }

    val studentName: Flow<String> = context.userDataStore.data.map { preferences ->
        preferences[PreferencesKeys.STUDENT_NAME] ?: "Teman Pintar"
    }

    suspend fun updateGrade(grade: Int) {
        context.userDataStore.edit { preferences ->
            preferences[PreferencesKeys.STUDENT_GRADE] = grade
        }
    }

    suspend fun addStars(amount: Int) {
        context.userDataStore.edit { preferences ->
            val current = preferences[PreferencesKeys.TOTAL_STARS] ?: 0
            preferences[PreferencesKeys.TOTAL_STARS] = current + amount
        }
    }

    suspend fun updateProfile(name: String, avatarId: String) {
        context.userDataStore.edit { preferences ->
            preferences[PreferencesKeys.STUDENT_NAME] = name
            preferences[PreferencesKeys.AVATAR_ID] = avatarId
        }
    }
}`
  },
  {
    path: 'app/src/main/java/id/sahabatpintar/sd/ui/theme/Theme.kt',
    name: 'Theme.kt',
    category: 'theme',
    description: 'Material 3 Color Scheme dengan nuansa Biru Langit, Kuning, Hijau, dan Putih',
    content: `package id.sahabatpintar.sd.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val SkyBluePrimary = Color(0xFF0284C7)
val SkyBlueContainer = Color(0xFFE0F2FE)
val YellowAccent = Color(0xFFFACC15)
val YellowContainer = Color(0xFFFEF9C3)
val GreenSuccess = Color(0xFF22C55E)
val WhiteBackground = Color(0xFFF8FAFC)
val DarkNavyText = Color(0xFF0F172A)

private val LightColorScheme = lightColorScheme(
    primary = SkyBluePrimary,
    onPrimary = Color.White,
    primaryContainer = SkyBlueContainer,
    onPrimaryContainer = DarkNavyText,
    secondary = YellowAccent,
    onSecondary = Color(0xFF713F12),
    secondaryContainer = YellowContainer,
    tertiary = GreenSuccess,
    background = WhiteBackground,
    surface = Color.White,
    onBackground = DarkNavyText,
    onSurface = DarkNavyText
)

@Composable
fun SahabatPintarTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = LightColorScheme,
        typography = Typography,
        content = content
    )
}`
  },
  {
    path: 'app/src/main/java/id/sahabatpintar/sd/ui/screens/HomeScreen.kt',
    name: 'HomeScreen.kt',
    category: 'ui',
    description: 'Jetpack Compose HomeScreen dengan Logo, Maskot, Kelas 1-6, 7 Mapel, dan Progres Belajar',
    content: `package id.sahabatpintar.sd.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun HomeScreen(
    onSubjectClick: (String, Int) -> Unit,
    onProfileClick: () -> Unit
) {
    var selectedGrade by remember { mutableIntStateOf(1) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF0F9FF))
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        // Top Bar: Mascot greeting & Stars
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "SAHABAT PINTAR SD",
                    fontWeight = FontWeight.Black,
                    fontSize = 20.sp,
                    color = Color(0xFF0369A1)
                )
                Text(
                    text = "Ayo Belajar Ceria Bersama Boni!",
                    fontSize = 13.sp,
                    color = Color(0xFF64748B)
                )
            }

            // Star Counter Badge
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = Color(0xFFFEF9C3),
                shadowElevation = 2.dp
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Star,
                        contentDescription = "Bintang",
                        tint = Color(0xFFEAB308),
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "50 Bintang",
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF854D0E),
                        fontSize = 13.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Pilihan Kelas 1 sampai 6 (Material 3 FilterChips)
        Text(
            text = "Pilih Kelasmu:",
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            color = Color(0xFF1E293B)
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            (1..6).forEach { grade ->
                val isSelected = selectedGrade == grade
                Button(
                    onClick = { selectedGrade = grade },
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isSelected) Color(0xFF0284C7) else Color.White,
                        contentColor = if (isSelected) Color.White else Color(0xFF475569)
                    ),
                    elevation = ButtonDefaults.buttonElevation(defaultElevation = 2.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Text(text = "Kelas \$grade", fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 7 Menu Pelajaran
        Text(
            text = "Mata Pelajaran (Kurikulum Merdeka):",
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            color = Color(0xFF1E293B)
        )

        // Subjects Grid
        val subjects = listOf(
            "Bahasa Indonesia" to "bahasa_indonesia",
            "Matematika" to "matematika",
            "IPAS" to "ipas",
            "Pendidikan Pancasila" to "pancasila",
            "Bahasa Inggris" to "bahasa_inggris",
            "Seni dan Budaya" to "seni_budaya",
            "Pendidikan Agama" to "agama"
        )

        Column(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(top = 8.dp)) {
            subjects.forEach { (name, id) ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSubjectClick(id, selectedGrade) },
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = name,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = Color(0xFF0F172A),
                            modifier = Modifier.weight(1f)
                        )
                        Text(
                            text = "Mulai Belajar →",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = Color(0xFF0284C7)
                        )
                    }
                }
            }
        }
    }
}`
  },
  {
    path: '.github/workflows/build-apk.yml',
    name: 'build-apk.yml',
    category: 'ci',
    description: 'Workflow GitHub Actions Cloud Build: JDK 17, Gradle 8.9, assembleDebug, dan Upload app-debug.apk',
    content: `name: Build Android APK (Sahabat Pintar SD)

on:
  push:
    branches: [ "main", "master" ]
  pull_request:
    branches: [ "main", "master" ]
  workflow_dispatch:

jobs:
  build:
    name: Build & Package Debug APK
    runs-on: ubuntu-latest

    steps:
      - name: Checkout Source Code
        uses: actions/checkout@v4

      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          java-version: '17'
          distribution: 'temurin'
          cache: gradle

      - name: Setup Gradle
        uses: gradle/actions/setup-gradle@v4
        with:
          gradle-version: '8.9'

      - name: Grant Execute Permission to gradlew
        run: chmod +x gradlew

      - name: Build Debug APK with Gradle
        run: ./gradlew assembleDebug --stacktrace

      - name: Verify APK Generated
        run: |
          echo "Memeriksa file APK yang terbentuk..."
          ls -lh app/build/outputs/apk/debug/
          test -f app/build/outputs/apk/debug/app-debug.apk || test -f app/build/outputs/apk/debug/*.apk

      - name: Upload Debug APK as Artifact
        uses: actions/upload-artifact@v4
        with:
          name: SahabatPintarSD-app-debug
          path: app/build/outputs/apk/debug/*.apk
          retention-days: 30`
  },
  {
    path: 'settings.gradle.kts',
    name: 'settings.gradle.kts',
    category: 'build',
    description: 'Konfigurasi repositori Google, Maven Central, dan nama root project SahabatPintarSD',
    content: `pluginManagement {
    repositories {
        google {
            content {
                includeGroupByRegex("com\\\\.android.*")
                includeGroupByRegex("com\\\\.google.*")
                includeGroupByRegex("androidx.*")
            }
        }
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "SahabatPintarSD"
include(":app")`
  }
];
