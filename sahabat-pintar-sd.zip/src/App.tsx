import React, { useState, useEffect } from 'react';
import { UserProfile, Grade, Subject, Lesson, SubjectId, QuizResultRecord, AvatarId, Quiz } from './types';
import { storageService } from './services/storage';
import { SUBJECTS } from './data/subjects';
import { findLessonById, getQuizForLesson, getQuizzesForGrade } from './data/learningContent';
import { playSound, speechService } from './services/soundEffects';

// Navigation & Layout Components
import { AndroidStatusBar } from './components/common/AndroidStatusBar';
import { AppHeader } from './components/common/AppHeader';
import { AndroidBottomNav, ScreenId } from './components/common/AndroidBottomNav';

// Screen Components
import { HomeScreen } from './components/screens/HomeScreen';
import { SubjectsScreen } from './components/screens/SubjectsScreen';
import { QuizListScreen } from './components/screens/QuizListScreen';
import { GamesHubScreen } from './components/screens/GamesHubScreen';
import { ProfileScreen } from './components/screens/ProfileScreen';

// Modals & Native Code
import { LessonModal } from './components/screens/LessonModal';
import { QuizModal } from './components/screens/QuizModal';
import { NativeCodeViewer } from './components/android/NativeCodeViewer';

export default function App() {
  const [profile, setProfile] = useState<UserProfile>(() => storageService.getProfile());
  const [currentTab, setCurrentTab] = useState<'app' | 'native_code'>('app');
  const [currentScreen, setCurrentScreen] = useState<ScreenId>('home');
  const [selectedSubjectId, setSelectedSubjectId] = useState<SubjectId>('matematika');

  // Modals state
  const [activeLesson, setActiveLesson] = useState<Lesson | null>(null);
  const [activeLessonSubject, setActiveLessonSubject] = useState<Subject | null>(null);
  const [activeQuizId, setActiveQuizId] = useState<string | null>(null);

  // Phone Emulator Frame toggle (true gives authentic smartphone emulator frame on desktop)
  const [isPhoneFrame, setIsPhoneFrame] = useState(false);

  // Detect mobile device on mount to default to fullscreen mobile for phone users
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const isMobile = window.innerWidth <= 768;
      // If mobile, keep isPhoneFrame false so it occupies full phone screen cleanly
      setIsPhoneFrame(!isMobile);
    }
  }, []);

  // Handlers for profile updates
  const handleGradeChange = (grade: Grade) => {
    const updated = storageService.updateGrade(grade);
    setProfile(updated);
  };

  const handleUpdateName = (name: string, schoolName?: string) => {
    const updated = storageService.updateName(name, schoolName);
    setProfile(updated);
  };

  const handleUpdateAvatar = (avatarId: AvatarId) => {
    const updated = storageService.updateAvatar(avatarId);
    setProfile(updated);
  };

  const handleAddStars = (amount: number) => {
    playSound.star();
    const updated = storageService.addStars(amount);
    setProfile(updated);
  };

  const handleResetProgress = () => {
    const fresh = storageService.resetProgress();
    setProfile(fresh);
  };

  const handleToggleSound = () => {
    const current = profile.soundEnabled;
    const updated = { ...profile, soundEnabled: !current };
    storageService.saveProfile(updated);
    setProfile(updated);
    if (current) {
      speechService.stop();
    } else {
      playSound.click();
    }
  };

  // Lesson & Quiz Handlers
  const handleSelectSubject = (subjectId: SubjectId) => {
    setSelectedSubjectId(subjectId);
    setCurrentScreen('subjects');
  };

  const handleOpenLesson = (lesson: Lesson, subject: Subject) => {
    setActiveLesson(lesson);
    setActiveLessonSubject(subject);
  };

  const handleCompleteLesson = (lessonId: string) => {
    const updatedWithLesson = storageService.completeLesson(lessonId, selectedSubjectId);
    const updated = storageService.addStars(5);
    setProfile(updated);
  };

  const handleStartQuizFromId = (quizId: string) => {
    setActiveLesson(null);
    setActiveQuizId(quizId);
  };

  const handleFinishQuiz = (record: QuizResultRecord) => {
    const updated = storageService.recordQuiz(record);
    setProfile(updated);
  };

  const resolveCurrentQuiz = (id: string | null): Quiz | null => {
    if (!id) return null;
    const cleanId = id.startsWith('quiz_') ? id.replace('quiz_', '') : id;
    const lesson = findLessonById(cleanId);
    if (lesson) return getQuizForLesson(lesson);
    const gradeQuizzes = getQuizzesForGrade(profile.grade);
    return gradeQuizzes.find((q) => q.id === id || q.lessonId === id) || null;
  };

  const currentQuiz = resolveCurrentQuiz(activeQuizId);
  const currentQuizSubject = currentQuiz
    ? SUBJECTS.find((s) => s.id === currentQuiz.subjectId)
    : undefined;

  return (
    <div className="min-h-screen bg-slate-900 flex flex-col items-center justify-center font-['Nunito',sans-serif]">
      {/* Container wrapper: switches between native phone emulator frame and full window */}
      <div
        className={`w-full transition-all duration-300 flex flex-col bg-slate-100 ${
          isPhoneFrame
            ? 'max-w-[460px] h-[92vh] max-h-[920px] rounded-[42px] border-[10px] border-slate-800 shadow-[0_25px_60px_-15px_rgba(0,0,0,0.7)] overflow-hidden my-4 ring-1 ring-white/20'
            : 'max-w-4xl min-h-screen shadow-lg'
        }`}
      >
        {/* Simulated Android Camera Notch (in phone frame mode) */}
        {isPhoneFrame && (
          <div className="bg-slate-900 h-6 w-full flex items-center justify-center relative shrink-0">
            <div className="w-20 h-4 bg-slate-800 rounded-full flex items-center justify-center gap-2">
              <div className="w-2 h-2 rounded-full bg-slate-950" />
              <div className="w-1.5 h-1.5 rounded-full bg-sky-950" />
            </div>
          </div>
        )}

        {/* Android Status Bar */}
        <AndroidStatusBar
          isPhoneFrame={isPhoneFrame}
          onToggleFrame={() => setIsPhoneFrame((f) => !f)}
          soundEnabled={profile.soundEnabled}
          onToggleSound={handleToggleSound}
        />

        {/* Application Header */}
        <AppHeader
          profile={profile}
          currentTab={currentTab}
          onTabChange={setCurrentTab}
          onOpenProfile={() => setCurrentScreen('profile')}
          onGradeChange={handleGradeChange}
        />

        {/* Main Content Area */}
        <main className="flex-1 overflow-y-auto pb-4">
          {currentTab === 'native_code' ? (
            <NativeCodeViewer />
          ) : (
            <>
              {currentScreen === 'home' && (
                <HomeScreen
                  profile={profile}
                  onGradeChange={handleGradeChange}
                  onSelectSubject={handleSelectSubject}
                  onResumeLesson={handleOpenLesson}
                  onOpenGames={() => setCurrentScreen('games')}
                  onOpenQuizzes={() => setCurrentScreen('quiz_list')}
                />
              )}

              {currentScreen === 'subjects' && (
                <SubjectsScreen
                  profile={profile}
                  initialSubjectId={selectedSubjectId}
                  onSelectLesson={handleOpenLesson}
                  onStartQuiz={handleStartQuizFromId}
                />
              )}

              {currentScreen === 'quiz_list' && (
                <QuizListScreen
                  profile={profile}
                  onStartQuiz={handleStartQuizFromId}
                />
              )}

              {currentScreen === 'games' && (
                <GamesHubScreen
                  profile={profile}
                  onAddStars={handleAddStars}
                />
              )}

              {currentScreen === 'profile' && (
                <ProfileScreen
                  profile={profile}
                  onUpdateName={handleUpdateName}
                  onUpdateAvatar={handleUpdateAvatar}
                  onUpdateGrade={handleGradeChange}
                  onResetProgress={handleResetProgress}
                />
              )}
            </>
          )}
        </main>

        {/* Material 3 Android Bottom Navigation (Visible when on app tab) */}
        {currentTab === 'app' && (
          <AndroidBottomNav
            currentScreen={currentScreen}
            onScreenChange={(screen) => setCurrentScreen(screen)}
          />
        )}
      </div>

      {/* Lesson Reader Modal */}
      {activeLesson && activeLessonSubject && (
        <LessonModal
          lesson={activeLesson}
          subject={activeLessonSubject}
          profile={profile}
          onClose={() => {
            setActiveLesson(null);
            setActiveLessonSubject(null);
          }}
          onComplete={handleCompleteLesson}
          onStartQuiz={handleStartQuizFromId}
        />
      )}

      {/* Quiz Modal */}
      {currentQuiz && (
        <QuizModal
          quiz={currentQuiz}
          subject={currentQuizSubject}
          onClose={() => setActiveQuizId(null)}
          onFinishQuiz={handleFinishQuiz}
        />
      )}
    </div>
  );
}
