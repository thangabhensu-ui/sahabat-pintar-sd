import React from 'react';
import { Home, BookOpen, HelpCircle, Gamepad2, Award } from 'lucide-react';
import { playSound } from '../../services/soundEffects';

export type ScreenId = 'home' | 'subjects' | 'quiz_list' | 'games' | 'profile';

interface AndroidBottomNavProps {
  currentScreen: ScreenId;
  onScreenChange: (screen: ScreenId) => void;
}

export const AndroidBottomNav: React.FC<AndroidBottomNavProps> = ({
  currentScreen,
  onScreenChange
}) => {
  const navItems = [
    {
      id: 'home' as ScreenId,
      label: 'Beranda',
      icon: Home
    },
    {
      id: 'subjects' as ScreenId,
      label: 'Pelajaran',
      icon: BookOpen
    },
    {
      id: 'quiz_list' as ScreenId,
      label: 'Kuis',
      icon: HelpCircle
    },
    {
      id: 'games' as ScreenId,
      label: 'Game Seru',
      icon: Gamepad2
    },
    {
      id: 'profile' as ScreenId,
      label: 'Prestasi',
      icon: Award
    }
  ];

  return (
    <nav className="bg-white/95 backdrop-blur-md border-t-2 border-sky-100 shadow-lg px-2 pt-2 pb-3 shrink-0 sticky bottom-0 z-20">
      <div className="flex items-center justify-around max-w-lg mx-auto">
        {navItems.map((item) => {
          const isActive = currentScreen === item.id;
          const Icon = item.icon;

          return (
            <button
              key={item.id}
              onClick={() => {
                playSound.click();
                onScreenChange(item.id);
              }}
              className={`flex flex-col items-center justify-center py-1 px-3 rounded-2xl transition-all cursor-pointer relative ${
                isActive ? 'scale-105' : 'opacity-65 hover:opacity-100'
              }`}
            >
              {/* Active pill indicator (Material 3 style) */}
              <div
                className={`flex items-center justify-center w-12 h-8 rounded-full transition-all ${
                  isActive
                    ? 'bg-sky-500 text-white shadow-xs'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                <Icon className={`w-5 h-5 ${isActive ? 'stroke-[2.5]' : 'stroke-2'}`} />
              </div>
              <span
                className={`text-[11px] mt-1 font-heading ${
                  isActive
                    ? 'font-black text-sky-800'
                    : 'font-bold text-slate-500'
                }`}
              >
                {item.label}
              </span>
            </button>
          );
        })}
      </div>

      {/* Android Gesture Navigation Home Bar Pill */}
      <div className="w-32 h-1 bg-slate-300 rounded-full mx-auto mt-2" />
    </nav>
  );
};
