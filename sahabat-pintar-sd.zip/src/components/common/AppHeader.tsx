import React from 'react';
import { UserProfile, Grade } from '../../types';
import { Star, Code, BookOpen, GraduationCap } from 'lucide-react';
import { playSound } from '../../services/soundEffects';

interface AppHeaderProps {
  profile: UserProfile;
  currentTab: 'app' | 'native_code';
  onTabChange: (tab: 'app' | 'native_code') => void;
  onOpenProfile: () => void;
  onGradeChange: (grade: Grade) => void;
}

export const AppHeader: React.FC<AppHeaderProps> = ({
  profile,
  currentTab,
  onTabChange,
  onOpenProfile,
  onGradeChange
}) => {
  return (
    <header className="bg-gradient-to-r from-sky-600 via-sky-500 to-blue-600 text-white px-4 py-3 shadow-md sticky top-0 z-30">
      <div className="flex items-center justify-between gap-2">
        {/* Logo and App Title */}
        <div className="flex items-center gap-2.5">
          <div className="w-10 h-10 rounded-2xl bg-white p-1 shadow-md flex items-center justify-center shrink-0 border-2 border-amber-300">
            {/* Logo Icon with Red-White Indonesia Ribbon & Book */}
            <div className="relative flex flex-col items-center justify-center w-full h-full">
              <span className="text-xl">🎒</span>
              <div className="absolute -bottom-1 -right-1 w-3 h-3 rounded-full bg-red-600 border border-white" />
            </div>
          </div>

          <div>
            <div className="flex items-center gap-1.5">
              <h1 className="font-heading font-black text-base md:text-lg tracking-wide text-white drop-shadow-xs leading-none">
                SAHABAT PINTAR SD
              </h1>
              <span className="bg-red-500 text-[10px] font-black px-1.5 py-0.5 rounded-full text-white tracking-widest shadow-xs">
                GRATIS
              </span>
            </div>
            <p className="text-[11px] text-sky-100 font-semibold leading-tight">
              Aplikasi Belajar Anak Indonesia
            </p>
          </div>
        </div>

        {/* Right side: Stars & Profile Chip */}
        <div className="flex items-center gap-2">
          {/* Star Counter */}
          <div
            onClick={() => {
              playSound.star();
              onOpenProfile();
            }}
            role="button"
            tabIndex={0}
            title="Bintang Prestasimu"
            className="flex items-center gap-1.5 bg-amber-400 hover:bg-amber-300 text-amber-950 font-black px-3 py-1.5 rounded-2xl shadow-sm border border-amber-500/50 cursor-pointer transition-transform active:scale-95"
          >
            <Star className="w-4 h-4 text-amber-900 fill-amber-900 animate-wiggle" />
            <span className="text-sm font-black">{profile.stars}</span>
          </div>

          {/* Student Profile Chip */}
          <button
            onClick={() => {
              playSound.click();
              onOpenProfile();
            }}
            className="flex items-center gap-1.5 bg-white/20 hover:bg-white/30 backdrop-blur-xs px-2.5 py-1.5 rounded-2xl border border-white/30 cursor-pointer transition-all active:scale-95 text-left"
          >
            <div className="w-7 h-7 rounded-full bg-sky-200 border-2 border-white flex items-center justify-center overflow-hidden shrink-0">
              <span className="text-sm">
                {profile.avatarId === 'boni'
                  ? '👦'
                  : profile.avatarId === 'sasa'
                  ? '👧'
                  : profile.avatarId === 'edo'
                  ? '🧑'
                  : profile.avatarId === 'siti'
                  ? '🧕'
                  : profile.avatarId === 'dayu'
                  ? '👧'
                  : '👦'}
              </span>
            </div>
            <div className="hidden sm:block text-xs">
              <div className="font-black text-white leading-tight truncate max-w-[80px]">
                {profile.name}
              </div>
              <div className="text-[10px] text-sky-100 font-bold">
                Kls {profile.grade}
              </div>
            </div>
          </button>
        </div>
      </div>

      {/* Mode switcher banner (Belajar Ceria vs Kode Kotlin Native) */}
      <div className="mt-2.5 flex items-center justify-between gap-2 border-t border-sky-400/30 pt-2 text-xs">
        <div className="flex bg-sky-700/60 p-0.5 rounded-xl border border-sky-400/40">
          <button
            onClick={() => {
              playSound.click();
              onTabChange('app');
            }}
            className={`px-3 py-1 rounded-lg font-black transition-all flex items-center gap-1.5 cursor-pointer ${
              currentTab === 'app'
                ? 'bg-white text-sky-900 shadow-xs'
                : 'text-sky-100 hover:text-white'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>Aplikasi Belajar</span>
          </button>

          <button
            onClick={() => {
              playSound.click();
              onTabChange('native_code');
            }}
            className={`px-3 py-1 rounded-lg font-black transition-all flex items-center gap-1.5 cursor-pointer ${
              currentTab === 'native_code'
                ? 'bg-amber-400 text-amber-950 shadow-xs'
                : 'text-sky-100 hover:text-white'
            }`}
          >
            <Code className="w-3.5 h-3.5" />
            <span>Kode Android Native</span>
            <span className="bg-red-500 text-white text-[9px] px-1 py-0.2 rounded font-black">
              Kotlin
            </span>
          </button>
        </div>

        {/* Quick Grade Badge indicator */}
        <div className="flex items-center gap-1 text-[11px] font-bold text-sky-100">
          <GraduationCap className="w-3.5 h-3.5 text-amber-300" />
          <span>Kelas {profile.grade} SD</span>
        </div>
      </div>
    </header>
  );
};
