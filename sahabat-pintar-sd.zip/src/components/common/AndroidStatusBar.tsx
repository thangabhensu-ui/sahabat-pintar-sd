import React, { useState, useEffect } from 'react';
import { Wifi, BatteryMedium, Volume2, VolumeX, Smartphone, Monitor } from 'lucide-react';

interface AndroidStatusBarProps {
  isPhoneFrame: boolean;
  onToggleFrame: () => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
}

export const AndroidStatusBar: React.FC<AndroidStatusBarProps> = ({
  isPhoneFrame,
  onToggleFrame,
  soundEnabled,
  onToggleSound
}) => {
  const [timeStr, setTimeStr] = useState('08:00');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const hours = String(now.getHours()).padStart(2, '0');
      const mins = String(now.getMinutes()).padStart(2, '0');
      setTimeStr(`${hours}:${mins}`);
    };
    updateTime();
    const timer = setInterval(updateTime, 30000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="bg-sky-900 text-white px-4 py-1.5 flex items-center justify-between text-xs select-none border-b border-sky-800/40">
      {/* Time & Android Notification Mock */}
      <div className="flex items-center gap-2">
        <span className="font-bold tracking-tight font-mono">{timeStr}</span>
        <span className="text-[10px] bg-red-600 font-black px-1.5 py-0.2 rounded-xs uppercase tracking-wider">
          SD
        </span>
      </div>

      {/* Frame Switcher and Sound Toggle */}
      <div className="flex items-center gap-2.5">
        <button
          onClick={onToggleSound}
          title={soundEnabled ? 'Matikan Suara' : 'Nyalakan Suara'}
          className="text-white/80 hover:text-white p-0.5 rounded cursor-pointer transition-colors"
        >
          {soundEnabled ? (
            <Volume2 className="w-3.5 h-3.5 text-amber-300" />
          ) : (
            <VolumeX className="w-3.5 h-3.5 text-white/50" />
          )}
        </button>

        <button
          onClick={onToggleFrame}
          title={isPhoneFrame ? 'Mode Layar Penuh' : 'Mode Bingkai HP Android'}
          className="hidden md:flex items-center gap-1 text-[11px] bg-sky-800/80 hover:bg-sky-700 px-2 py-0.5 rounded-full text-sky-100 transition-colors cursor-pointer"
        >
          {isPhoneFrame ? (
            <>
              <Monitor className="w-3 h-3" />
              <span>Layar Penuh</span>
            </>
          ) : (
            <>
              <Smartphone className="w-3 h-3" />
              <span>Bingkai HP</span>
            </>
          )}
        </button>

        {/* Real-looking Android System Status Icons */}
        <div className="flex items-center gap-1.5 text-white/90">
          <span className="text-[10px] font-bold tracking-tighter">5G</span>
          <Wifi className="w-3.5 h-3.5" />
          <div className="flex items-center gap-0.5">
            <span className="text-[10px] font-bold">98%</span>
            <BatteryMedium className="w-3.5 h-3.5 text-emerald-400" />
          </div>
        </div>
      </div>
    </div>
  );
};
