import React, { useState } from 'react';
import { playSound, speechService } from '../../services/soundEffects';

interface MascotProps {
  type?: 'boni' | 'sasa' | 'garuda';
  mood?: 'happy' | 'talking' | 'celebrating' | 'thinking';
  size?: 'sm' | 'md' | 'lg' | 'hero';
  showBubble?: boolean;
  bubbleText?: string;
  onBubbleClick?: () => void;
  className?: string;
}

export const Mascot: React.FC<MascotProps> = ({
  type = 'boni',
  mood = 'happy',
  size = 'md',
  showBubble = true,
  bubbleText,
  onBubbleClick,
  className = ''
}) => {
  const [isWaving, setIsWaving] = useState(false);
  const [internalSpeech, setInternalSpeech] = useState<string | null>(null);

  const voiceQuotes = [
    'Semangat belajar ya Teman Pintar!',
    'Hebat! Kamu rajin sekali hari ini!',
    'Aku Boni, siap menemanimu belajar!',
    'Ayo kumpulkan banyak bintang emas!'
  ];

  const handleMascotClick = () => {
    setIsWaving(true);
    playSound.click();
    const randomQuote = voiceQuotes[Math.floor(Math.random() * voiceQuotes.length)];
    setInternalSpeech(randomQuote);
    speechService.speak(randomQuote);
    setTimeout(() => setIsWaving(false), 1200);
  };

  const sizeClasses = {
    sm: 'w-16 h-16',
    md: 'w-28 h-28',
    lg: 'w-36 h-36',
    hero: 'w-48 h-48 md:w-56 md:h-56'
  }[size];

  const currentSpeech = internalSpeech || bubbleText || 'Halo! Yuk belajar bersama Boni hari ini!';

  return (
    <div className={`relative flex items-center justify-center ${className}`}>
      {/* Speech bubble */}
      {showBubble && (
        <div
          onClick={() => {
            if (onBubbleClick) onBubbleClick();
            else handleMascotClick();
          }}
          role="button"
          tabIndex={0}
          className="absolute -top-12 md:-top-14 bg-white/95 backdrop-blur-sm border-2 border-sky-300 text-sky-950 font-bold px-3.5 py-1.5 rounded-2xl shadow-md cursor-pointer hover:scale-105 transition-all text-xs md:text-sm flex items-center gap-1.5 z-10 whitespace-nowrap animate-bounce"
          style={{ animationDuration: '3s' }}
        >
          <span className="text-amber-500">✨</span>
          <span>{currentSpeech}</span>
          {/* Bubble tail */}
          <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-0 h-0 border-l-[6px] border-l-transparent border-r-[6px] border-r-transparent border-t-[8px] border-t-sky-300" />
        </div>
      )}

      {/* Mascot Graphic container with interactive click */}
      <div
        onClick={handleMascotClick}
        role="button"
        tabIndex={0}
        title="Klik Boni untuk menyapa!"
        className={`cursor-pointer transition-transform hover:scale-110 active:scale-95 ${sizeClasses} ${isWaving ? 'animate-wiggle' : 'animate-float'}`}
      >
        {type === 'boni' && (
          <svg viewBox="0 0 160 160" className="w-full h-full drop-shadow-md">
            {/* Background Glow */}
            <circle cx="80" cy="80" r="74" fill="#E0F2FE" />
            <circle cx="80" cy="80" r="66" fill="#BAE6FD" opacity="0.6" />

            {/* Body: Indonesian elementary uniform (White shirt + Red tie / badge) */}
            <path d="M 45 140 Q 80 120 115 140 L 122 160 L 38 160 Z" fill="#FFFFFF" stroke="#0369A1" strokeWidth="2.5" />
            {/* Red school tie */}
            <path d="M 75 130 L 85 130 L 88 155 L 80 160 L 72 155 Z" fill="#DC2626" />
            {/* Collar */}
            <path d="M 58 126 L 80 138 L 102 126 L 90 122 L 80 126 L 70 122 Z" fill="#F1F5F9" stroke="#94A3B8" strokeWidth="1.5" />

            {/* Neck */}
            <rect x="70" y="112" width="20" height="16" rx="6" fill="#FDBA74" />

            {/* Ears */}
            <ellipse cx="43" cy="88" rx="8" ry="10" fill="#FDBA74" />
            <ellipse cx="44" cy="88" rx="4" ry="6" fill="#FCA5A5" />
            <ellipse cx="117" cy="88" rx="8" ry="10" fill="#FDBA74" />
            <ellipse cx="116" cy="88" rx="4" ry="6" fill="#FCA5A5" />

            {/* Face */}
            <circle cx="80" cy="84" r="38" fill="#FED7AA" stroke="#EA580C" strokeWidth="1.5" />

            {/* Hair */}
            <path
              d="M 44 80 Q 42 50 80 46 Q 118 50 116 80 Q 112 66 100 62 Q 80 66 60 62 Q 48 68 44 80 Z"
              fill="#1E293B"
            />
            {/* Peci Hitam (Indonesian National Cap) */}
            <path
              d="M 46 54 C 46 42 114 42 114 54 C 114 58 46 58 46 54 Z"
              fill="#0F172A"
              stroke="#334155"
              strokeWidth="1.5"
            />
            {/* Gold pin on peci */}
            <circle cx="56" cy="52" r="3" fill="#FACC15" />

            {/* Rosy Cheeks */}
            <ellipse cx="58" cy="94" rx="7" ry="4" fill="#F87171" opacity="0.6" />
            <ellipse cx="102" cy="94" rx="7" ry="4" fill="#F87171" opacity="0.6" />

            {/* Big Expressive Eyes */}
            {mood === 'happy' || mood === 'talking' ? (
              <>
                {/* Left eye */}
                <circle cx="65" cy="84" r="6" fill="#0F172A" />
                <circle cx="67" cy="82" r="2.2" fill="#FFFFFF" />
                {/* Right eye */}
                <circle cx="95" cy="84" r="6" fill="#0F172A" />
                <circle cx="97" cy="82" r="2.2" fill="#FFFFFF" />
                {/* Eyebrows */}
                <path d="M 58 74 Q 65 71 71 74" stroke="#0F172A" strokeWidth="2.5" strokeLinecap="round" fill="none" />
                <path d="M 89 74 Q 95 71 102 74" stroke="#0F172A" strokeWidth="2.5" strokeLinecap="round" fill="none" />
              </>
            ) : (
              <>
                {/* Cheerful curved eye */}
                <path d="M 59 84 Q 65 78 71 84" stroke="#0F172A" strokeWidth="3" strokeLinecap="round" fill="none" />
                <path d="M 89 84 Q 95 78 101 84" stroke="#0F172A" strokeWidth="3" strokeLinecap="round" fill="none" />
              </>
            )}

            {/* Cute Nose */}
            <circle cx="80" cy="89" r="2" fill="#EA580C" opacity="0.6" />

            {/* Cheerful Smiling Mouth */}
            <path
              d="M 70 94 Q 80 108 90 94"
              stroke="#B91C1C"
              strokeWidth="2.5"
              fill="#EF4444"
              strokeLinecap="round"
            />
            {/* Tooth */}
            <path d="M 77 96 L 83 96 Q 80 99 77 96 Z" fill="#FFFFFF" />

            {/* Waving Hand with Pencil */}
            <g className={isWaving ? 'animate-bounce' : ''}>
              <ellipse cx="126" cy="116" rx="9" ry="8" fill="#FDBA74" stroke="#EA580C" strokeWidth="1" />
              {/* Pencil */}
              <rect x="122" y="94" width="7" height="24" rx="2" fill="#FACC15" stroke="#CA8A04" strokeWidth="1" transform="rotate(18 126 106)" />
              <polygon points="132,92 138,88 135,97" fill="#F43F5E" />
            </g>
          </svg>
        )}

        {type === 'sasa' && (
          <svg viewBox="0 0 160 160" className="w-full h-full drop-shadow-md">
            {/* Background Glow */}
            <circle cx="80" cy="80" r="74" fill="#FDF2F8" />
            <circle cx="80" cy="80" r="66" fill="#FBCFE8" opacity="0.6" />

            {/* Body: Uniform with pink cardigan */}
            <path d="M 45 140 Q 80 120 115 140 L 122 160 L 38 160 Z" fill="#FCE7F3" stroke="#DB2777" strokeWidth="2" />
            <path d="M 68 130 L 92 130 L 88 160 L 72 160 Z" fill="#FFFFFF" />

            {/* Ears */}
            <ellipse cx="43" cy="88" rx="8" ry="10" fill="#FED7AA" />
            <ellipse cx="117" cy="88" rx="8" ry="10" fill="#FED7AA" />

            {/* Face */}
            <circle cx="80" cy="84" r="38" fill="#FED7AA" stroke="#FB7185" strokeWidth="1.5" />

            {/* Hair with Ponytails */}
            <path
              d="M 40 84 C 36 46 124 46 120 84 C 114 62 98 56 80 58 C 62 56 46 62 40 84 Z"
              fill="#331A08"
            />
            {/* Yellow Hair Ribbon / Bando */}
            <path d="M 48 64 Q 80 44 112 64" stroke="#FACC15" strokeWidth="7" fill="none" strokeLinecap="round" />
            <circle cx="106" cy="60" r="6" fill="#EF4444" />
            <circle cx="106" cy="60" r="2.5" fill="#FACC15" />

            {/* Rosy Cheeks */}
            <ellipse cx="58" cy="94" rx="7" ry="4" fill="#FB7185" opacity="0.7" />
            <ellipse cx="102" cy="94" rx="7" ry="4" fill="#FB7185" opacity="0.7" />

            {/* Eyes */}
            <circle cx="65" cy="84" r="6" fill="#0F172A" />
            <circle cx="67" cy="82" r="2.4" fill="#FFFFFF" />
            <path d="M 60 76 Q 66 73 72 76" stroke="#0F172A" strokeWidth="2.5" strokeLinecap="round" fill="none" />

            <circle cx="95" cy="84" r="6" fill="#0F172A" />
            <circle cx="97" cy="82" r="2.4" fill="#FFFFFF" />
            <path d="M 88 76 Q 94 73 100 76" stroke="#0F172A" strokeWidth="2.5" strokeLinecap="round" fill="none" />

            {/* Cute Smile */}
            <path
              d="M 72 94 Q 80 106 88 94"
              stroke="#BE123C"
              strokeWidth="2.5"
              fill="#F43F5E"
              strokeLinecap="round"
            />
          </svg>
        )}

        {type === 'garuda' && (
          <svg viewBox="0 0 160 160" className="w-full h-full drop-shadow-md">
            <circle cx="80" cy="80" r="74" fill="#FEF9C3" />
            {/* Golden wings */}
            <path d="M 28 85 C 20 65 48 50 64 74 Z" fill="#F59E0B" />
            <path d="M 132 85 C 140 65 112 50 96 74 Z" fill="#F59E0B" />
            {/* Body */}
            <ellipse cx="80" cy="88" rx="36" ry="40" fill="#FBBF24" stroke="#D97706" strokeWidth="2" />
            {/* Shield on chest with Merah Putih ribbon */}
            <path d="M 68 84 Q 80 78 92 84 L 90 104 Q 80 112 70 104 Z" fill="#DC2626" />
            <path d="M 70 94 Q 80 94 90 94 L 90 104 Q 80 112 70 104 Z" fill="#FFFFFF" />
            {/* Head */}
            <circle cx="80" cy="58" r="28" fill="#FBBF24" stroke="#D97706" strokeWidth="2" />
            {/* Beak */}
            <polygon points="72,58 88,58 80,72" fill="#EA580C" />
            {/* Eyes */}
            <circle cx="70" cy="52" r="5" fill="#0F172A" />
            <circle cx="71" cy="50" r="1.8" fill="#FFFFFF" />
            <circle cx="90" cy="52" r="5" fill="#0F172A" />
            <circle cx="91" cy="50" r="1.8" fill="#FFFFFF" />
          </svg>
        )}
      </div>
    </div>
  );
};
