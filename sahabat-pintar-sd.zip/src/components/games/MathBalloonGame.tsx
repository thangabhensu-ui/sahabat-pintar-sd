import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import { playSound } from '../../services/soundEffects';
import { Grade } from '../../types';
import { Trophy, RefreshCw, Volume2, Star, ArrowLeft } from 'lucide-react';

interface MathBalloonGameProps {
  grade: Grade;
  onFinish: (starsEarned: number) => void;
  onBack: () => void;
}

interface Question {
  text: string;
  answer: number;
  options: number[];
}

export const MathBalloonGame: React.FC<MathBalloonGameProps> = ({
  grade,
  onFinish,
  onBack
}) => {
  const [currentRound, setCurrentRound] = useState(1);
  const [score, setScore] = useState(0);
  const [question, setQuestion] = useState<Question | null>(null);
  const [feedback, setFeedback] = useState<{ isCorrect: boolean; message: string } | null>(null);
  const [isGameOver, setIsGameOver] = useState(false);
  const [poppedIndex, setPoppedIndex] = useState<number | null>(null);

  const totalRounds = 5;

  const generateQuestion = (round: number): Question => {
    let a = 0;
    let b = 0;
    let isAddition = true;

    if (grade === 1) {
      a = Math.floor(Math.random() * 8) + 2;
      b = Math.floor(Math.random() * 8) + 2;
      isAddition = Math.random() > 0.3;
      if (!isAddition && a < b) [a, b] = [b, a];
    } else if (grade === 2) {
      isAddition = Math.random() > 0.4;
      a = Math.floor(Math.random() * 15) + 5;
      b = Math.floor(Math.random() * 12) + 2;
      if (!isAddition && a < b) [a, b] = [b, a];
    } else {
      // Multiplication or addition
      const op = Math.random();
      if (op > 0.5) {
        a = Math.floor(Math.random() * 7) + 2;
        b = Math.floor(Math.random() * 6) + 2;
        return {
          text: `${a} × ${b} = ?`,
          answer: a * b,
          options: shuffle([a * b, a * b + 2, Math.max(1, a * b - 3), a * b + 4])
        };
      } else {
        a = Math.floor(Math.random() * 25) + 10;
        b = Math.floor(Math.random() * 20) + 5;
      }
    }

    const answer = isAddition ? a + b : a - b;
    const wrong1 = answer + 2;
    const wrong2 = Math.max(1, answer - 2);
    const wrong3 = answer + (Math.random() > 0.5 ? 4 : -4);

    return {
      text: `${a} ${isAddition ? '+' : '-'} ${b} = ?`,
      answer,
      options: shuffle([answer, wrong1, wrong2, wrong3])
    };
  };

  const shuffle = (arr: number[]) => {
    return [...new Set(arr)].sort(() => Math.random() - 0.5).slice(0, 4);
  };

  useEffect(() => {
    setQuestion(generateQuestion(currentRound));
    setFeedback(null);
    setPoppedIndex(null);
  }, [currentRound, grade]);

  const handleBalloonClick = (val: number, idx: number) => {
    if (feedback !== null || !question) return;

    setPoppedIndex(idx);

    if (val === question.answer) {
      playSound.success();
      setScore((prev) => prev + 1);
      setFeedback({ isCorrect: true, message: '🎉 Hore, Benar Sekali!' });
      confetti({
        particleCount: 35,
        spread: 60,
        origin: { y: 0.7 }
      });
    } else {
      playSound.wrong();
      setFeedback({
        isCorrect: false,
        message: `Oops, jawabannya adalah ${question.answer}! Jangan menyerah ya!`
      });
    }

    setTimeout(() => {
      if (currentRound < totalRounds) {
        setCurrentRound((prev) => prev + 1);
      } else {
        setIsGameOver(true);
        playSound.fanfare();
        const starsGained = Math.max(2, (score + (val === question.answer ? 1 : 0)) * 2);
        onFinish(starsGained);
      }
    }, 1500);
  };

  const balloonColors = [
    'from-rose-400 to-rose-600 border-rose-300',
    'from-sky-400 to-sky-600 border-sky-300',
    'from-emerald-400 to-emerald-600 border-emerald-300',
    'from-amber-400 to-amber-600 border-amber-300'
  ];

  if (isGameOver) {
    return (
      <div className="p-6 text-center bg-white rounded-3xl border-4 border-amber-300 shadow-xl max-w-md mx-auto animate-float">
        <div className="w-20 h-20 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-4 border-4 border-amber-300">
          <Trophy className="w-10 h-10 text-amber-500 animate-bounce" />
        </div>
        <h3 className="text-2xl font-black text-slate-800 font-heading">Luar Biasa, Jagoan!</h3>
        <p className="text-slate-600 mt-2">
          Kamu berhasil menjawab benar <span className="font-bold text-sky-600">{score}</span> dari{' '}
          <span className="font-bold">{totalRounds}</span> balon angka!
        </p>
        <div className="my-5 py-3 px-4 bg-amber-50 rounded-2xl border-2 border-amber-200 inline-flex items-center gap-2">
          <Star className="w-6 h-6 text-amber-500 fill-amber-400" />
          <span className="font-black text-lg text-amber-800">+{score * 2} Bintang Emas!</span>
        </div>
        <div className="flex gap-3 justify-center">
          <button
            onClick={() => {
              setCurrentRound(1);
              setScore(0);
              setIsGameOver(false);
            }}
            className="btn-tactile-yellow px-5 py-3 rounded-2xl font-black flex items-center gap-2 text-sm"
          >
            <RefreshCw className="w-4 h-4" />
            Main Lagi
          </button>
          <button
            onClick={onBack}
            className="btn-tactile-blue text-white px-5 py-3 rounded-2xl font-black text-sm"
          >
            Menu Utama
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gradient-to-b from-sky-100 via-sky-50 to-blue-100 p-4 md:p-6 rounded-3xl border-4 border-sky-300 shadow-lg relative overflow-hidden">
      {/* Top Header */}
      <div className="flex items-center justify-between mb-4">
        <button
          onClick={onBack}
          className="p-2 bg-white text-slate-700 rounded-xl border-2 border-slate-200 font-bold hover:bg-slate-50 flex items-center gap-1 text-xs"
        >
          <ArrowLeft className="w-4 h-4" />
          Kembali
        </button>

        <div className="flex items-center gap-2 bg-white px-3 py-1.5 rounded-full border-2 border-sky-200 shadow-xs">
          <span className="text-xs font-bold text-slate-600">Babak:</span>
          <span className="font-black text-sky-600 text-sm">
            {currentRound} / {totalRounds}
          </span>
        </div>

        <div className="flex items-center gap-1 bg-amber-100 px-3 py-1.5 rounded-full border-2 border-amber-300">
          <Star className="w-4 h-4 text-amber-500 fill-amber-400" />
          <span className="font-black text-xs text-amber-800">{score * 2}</span>
        </div>
      </div>

      {/* Question Board */}
      <div className="bg-white/90 backdrop-blur-sm p-4 rounded-2xl border-2 border-sky-200 text-center shadow-sm mb-6">
        <span className="inline-block bg-sky-100 text-sky-800 text-xs font-black px-3 py-1 rounded-full mb-2">
          🎈 Pecahkan Balon Jawaban yang Benar!
        </span>
        <div className="text-3xl md:text-4xl font-black text-sky-900 tracking-wide font-heading">
          {question?.text}
        </div>
      </div>

      {/* Balloons Grid */}
      <div className="grid grid-cols-2 gap-4 max-w-sm mx-auto mb-4">
        {question?.options.map((opt, idx) => {
          const isPopped = poppedIndex === idx;
          const bgGradient = balloonColors[idx % balloonColors.length];

          return (
            <div key={idx} className="flex flex-col items-center">
              <button
                disabled={feedback !== null}
                onClick={() => handleBalloonClick(opt, idx)}
                className={`relative w-28 h-32 md:w-32 md:h-36 rounded-full bg-gradient-to-b ${bgGradient} text-white font-black text-2xl md:text-3xl shadow-lg border-2 flex items-center justify-center transform transition-all cursor-pointer active:scale-95 hover:scale-105 ${
                  isPopped ? 'scale-0 opacity-0 duration-300' : 'animate-float'
                }`}
                style={{
                  borderRadius: '50% 50% 50% 50% / 40% 40% 60% 60%',
                  animationDelay: `${idx * 0.4}s`
                }}
              >
                {/* Balloon highlight glare */}
                <div className="absolute top-3 left-4 w-4 h-7 bg-white/40 rounded-full transform -rotate-30 pointer-events-none" />
                <span className="drop-shadow-md">{opt}</span>
                {/* Balloon knot */}
                <div className="absolute -bottom-2 w-3 h-2 bg-inherit border-t-0 rounded-b-sm" />
              </button>
              {/* String */}
              <div className="w-0.5 h-6 bg-slate-400/60" />
            </div>
          );
        })}
      </div>

      {/* Instant Feedback Toast */}
      {feedback && (
        <div
          className={`p-3 rounded-2xl text-center font-black text-sm md:text-base border-2 shadow-md animate-bounce ${
            feedback.isCorrect
              ? 'bg-emerald-100 border-emerald-400 text-emerald-900'
              : 'bg-rose-100 border-rose-400 text-rose-900'
          }`}
        >
          {feedback.message}
        </div>
      )}
    </div>
  );
};
