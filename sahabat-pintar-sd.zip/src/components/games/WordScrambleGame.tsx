import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import { playSound } from '../../services/soundEffects';
import { Trophy, RefreshCw, ArrowLeft, Star, Sparkles } from 'lucide-react';

interface WordPuzzle {
  word: string;
  clue: string;
  category: string;
}

const PUZZLES: WordPuzzle[] = [
  { word: 'GARUDA', clue: 'Lambang negara Indonesia yang gagah', category: 'Pancasila' },
  { word: 'BINTANG', clue: 'Simbol sila pertama Pancasila di dada Garuda', category: 'Pancasila' },
  { word: 'PELANGI', clue: 'Lengkungan indah warna-warni di langit setelah hujan', category: 'Alam / IPAS' },
  { word: 'SEKOLAH', clue: 'Tempat kita menuntut ilmu bersama teman dan guru', category: 'Kegiatan' },
  { word: 'MERAH', clue: 'Warna bendera Indonesia bagian atas', category: 'Warna' },
  { word: 'PUTIH', clue: 'Warna kesucian bendera Indonesia bagian bawah', category: 'Warna' },
  { word: 'JUJUR', clue: 'Sifat terpuji selalu berkata benar', category: 'Budi Pekerti' }
];

interface WordScrambleGameProps {
  onFinish: (starsEarned: number) => void;
  onBack: () => void;
}

export const WordScrambleGame: React.FC<WordScrambleGameProps> = ({ onFinish, onBack }) => {
  const [puzzleIndex, setPuzzleIndex] = useState(0);
  const [selectedLetters, setSelectedLetters] = useState<{ char: string; originalIdx: number }[]>([]);
  const [availableLetters, setAvailableLetters] = useState<{ char: string; id: number }[]>([]);
  const [score, setScore] = useState(0);
  const [isGameOver, setIsGameOver] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);

  const currentPuzzle = PUZZLES[puzzleIndex % PUZZLES.length];

  useEffect(() => {
    const letters = currentPuzzle.word.split('').map((char, id) => ({ char, id }));
    // Shuffle letters ensuring it is not the exact solution initially
    const shuffled = [...letters].sort(() => Math.random() - 0.5);
    setAvailableLetters(shuffled);
    setSelectedLetters([]);
    setFeedback(null);
  }, [puzzleIndex]);

  const handlePickLetter = (item: { char: string; id: number }) => {
    playSound.click();
    setSelectedLetters((prev) => [...prev, { char: item.char, originalIdx: item.id }]);
    setAvailableLetters((prev) => prev.filter((l) => l.id !== item.id));
  };

  const handleRemoveLetter = (indexInSelected: number) => {
    playSound.click();
    const item = selectedLetters[indexInSelected];
    setSelectedLetters((prev) => prev.filter((_, idx) => idx !== indexInSelected));
    setAvailableLetters((prev) => [...prev, { char: item.char, id: item.originalIdx }]);
  };

  const handleCheckAnswer = () => {
    const constructedWord = selectedLetters.map((l) => l.char).join('');
    if (constructedWord === currentPuzzle.word) {
      playSound.success();
      setFeedback('🎉 Hebat! Kamu pintar menyusun kata!');
      confetti({ particleCount: 30, spread: 50 });
      setScore((s) => s + 1);

      setTimeout(() => {
        if (puzzleIndex < 4) {
          setPuzzleIndex((idx) => idx + 1);
        } else {
          playSound.fanfare();
          setIsGameOver(true);
          onFinish((score + 1) * 3);
        }
      }, 1400);
    } else {
      playSound.wrong();
      setFeedback('Ayo coba lagi, urutan hurufnya belum pas!');
      setTimeout(() => setFeedback(null), 1800);
    }
  };

  if (isGameOver) {
    return (
      <div className="p-6 text-center bg-white rounded-3xl border-4 border-emerald-300 shadow-xl max-w-md mx-auto">
        <div className="w-20 h-20 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4 border-4 border-emerald-300">
          <Trophy className="w-10 h-10 text-emerald-600 animate-bounce" />
        </div>
        <h3 className="text-2xl font-black text-slate-800 font-heading">Penyusun Kata Juara!</h3>
        <p className="text-slate-600 mt-2">
          Kamu berhasil menyelesaikan 5 teka-teki kata bahasa Indonesia dengan luar biasa!
        </p>
        <div className="my-5 py-3 px-4 bg-emerald-50 rounded-2xl border-2 border-emerald-200 inline-flex items-center gap-2">
          <Star className="w-6 h-6 text-amber-500 fill-amber-400" />
          <span className="font-black text-lg text-emerald-800">+{score * 3} Bintang Emas!</span>
        </div>
        <div className="flex gap-3 justify-center">
          <button
            onClick={() => {
              setPuzzleIndex(0);
              setScore(0);
              setIsGameOver(false);
            }}
            className="btn-tactile-green text-white px-5 py-3 rounded-2xl font-black flex items-center gap-2 text-sm"
          >
            <RefreshCw className="w-4 h-4" />
            Main Lagi
          </button>
          <button
            onClick={onBack}
            className="btn-tactile-blue text-white px-5 py-3 rounded-2xl font-black text-sm"
          >
            Menu Utama
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gradient-to-b from-emerald-100 via-teal-50 to-green-100 p-4 md:p-6 rounded-3xl border-4 border-emerald-300 shadow-lg">
      <div className="flex items-center justify-between mb-4">
        <button
          onClick={onBack}
          className="p-2 bg-white text-slate-700 rounded-xl border-2 border-slate-200 font-bold hover:bg-slate-50 flex items-center gap-1 text-xs"
        >
          <ArrowLeft className="w-4 h-4" />
          Kembali
        </button>

        <span className="bg-emerald-200 text-emerald-900 text-xs font-black px-3 py-1 rounded-full">
          Kata {puzzleIndex + 1} / 5
        </span>

        <div className="flex items-center gap-1 bg-amber-100 px-3 py-1.5 rounded-full border-2 border-amber-300">
          <Star className="w-4 h-4 text-amber-500 fill-amber-400" />
          <span className="font-black text-xs text-amber-800">{score * 3}</span>
        </div>
      </div>

      {/* Clue card */}
      <div className="bg-white p-4 rounded-2xl border-2 border-emerald-200 text-center shadow-xs mb-6">
        <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full uppercase">
          Kategori: {currentPuzzle.category}
        </span>
        <p className="text-base md:text-lg font-bold text-slate-700 mt-2">
          "{currentPuzzle.clue}"
        </p>
      </div>

      {/* Answer Slots */}
      <div className="flex justify-center flex-wrap gap-2 mb-6 min-h-[60px]">
        {currentPuzzle.word.split('').map((_, idx) => {
          const filled = selectedLetters[idx];
          return (
            <button
              key={idx}
              onClick={() => filled && handleRemoveLetter(idx)}
              className={`w-12 h-14 md:w-14 md:h-16 rounded-2xl border-3 flex items-center justify-center text-2xl font-black transition-all ${
                filled
                  ? 'bg-amber-400 border-amber-500 text-slate-900 shadow-md cursor-pointer hover:scale-105 active:scale-95'
                  : 'bg-white/80 border-dashed border-emerald-300 text-emerald-200 cursor-default'
              }`}
            >
              {filled?.char || ''}
            </button>
          );
        })}
      </div>

      {/* Available Letters Pool */}
      <div className="bg-white/70 backdrop-blur-sm p-4 rounded-2xl border-2 border-emerald-200 mb-6">
        <div className="text-xs font-bold text-slate-500 text-center mb-3">
          Sentuh huruf di bawah untuk menyusun:
        </div>
        <div className="flex justify-center flex-wrap gap-2.5">
          {availableLetters.map((item) => (
            <button
              key={item.id}
              onClick={() => handlePickLetter(item)}
              className="w-11 h-13 md:w-12 md:h-14 rounded-2xl bg-white border-2 border-emerald-400 text-emerald-800 font-black text-xl shadow-sm hover:scale-110 active:scale-95 transition-transform"
            >
              {item.char}
            </button>
          ))}
        </div>
      </div>

      {feedback && (
        <div
          className={`p-3 rounded-2xl text-center font-black text-sm mb-4 border-2 ${
            feedback.includes('Hebat')
              ? 'bg-emerald-100 border-emerald-400 text-emerald-900'
              : 'bg-rose-100 border-rose-400 text-rose-900'
          }`}
        >
          {feedback}
        </div>
      )}

      {/* Actions */}
      <div className="flex justify-center gap-3">
        <button
          onClick={handleCheckAnswer}
          disabled={selectedLetters.length !== currentPuzzle.word.length}
          className={`px-6 py-3 rounded-2xl font-black text-white text-base shadow-md flex items-center gap-2 ${
            selectedLetters.length === currentPuzzle.word.length
              ? 'btn-tactile-green cursor-pointer'
              : 'bg-slate-300 cursor-not-allowed opacity-60'
          }`}
        >
          <Sparkles className="w-5 h-5" />
          Periksa Jawaban
        </button>
      </div>
    </div>
  );
};
