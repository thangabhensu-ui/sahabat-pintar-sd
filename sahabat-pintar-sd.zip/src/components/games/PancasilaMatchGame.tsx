import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import { playSound } from '../../services/soundEffects';
import { Trophy, ArrowLeft, Star, CheckCircle2 } from 'lucide-react';

interface PancasilaItem {
  sila: number;
  simbol: string;
  bunyi: string;
  iconVisual: string;
  warna: string;
  contoh: string;
}

const PANCASILA_DATA: PancasilaItem[] = [
  {
    sila: 1,
    simbol: 'Bintang Emas',
    bunyi: 'Ketuhanan Yang Maha Esa',
    iconVisual: '⭐',
    warna: 'bg-amber-100 text-amber-900 border-amber-300',
    contoh: 'Berdoa sebelum belajar dan menghormati teman yang sedang beribadah.'
  },
  {
    sila: 2,
    simbol: 'Rantai Emas',
    bunyi: 'Kemanusiaan yang Adil dan Beradab',
    iconVisual: '🔗',
    warna: 'bg-rose-100 text-rose-900 border-rose-300',
    contoh: 'Menolong teman yang terjatuh di halaman dan tidak membeda-bedakan sahabat.'
  },
  {
    sila: 3,
    simbol: 'Pohon Beringin',
    bunyi: 'Persatuan Indonesia',
    iconVisual: '🌳',
    warna: 'bg-emerald-100 text-emerald-900 border-emerald-300',
    contoh: 'Bekerja bakti membersihkan kelas bersama dan bangga cinta tanah air.'
  },
  {
    sila: 4,
    simbol: 'Kepala Banteng',
    bunyi: 'Kerakyatan yang Dipimpin oleh Hikmat Kebijaksanaan dalam Permusyawaratan/Perwakilan',
    iconVisual: '🐂',
    warna: 'bg-red-100 text-red-900 border-red-300',
    contoh: 'Bermusyawarah memilih ketua kelas dan menghargai pendapat orang lain.'
  },
  {
    sila: 5,
    simbol: 'Padi dan Kapas',
    bunyi: 'Keadilan Sosial bagi Seluruh Rakyat Indonesia',
    iconVisual: '🌾',
    warna: 'bg-yellow-100 text-yellow-900 border-yellow-300',
    contoh: 'Bersikap adil kepada semua teman dan suka menabung hidup hemat.'
  }
];

interface PancasilaMatchGameProps {
  onFinish: (stars: number) => void;
  onBack: () => void;
}

export const PancasilaMatchGame: React.FC<PancasilaMatchGameProps> = ({ onFinish, onBack }) => {
  const [matchedIds, setMatchedIds] = useState<number[]>([]);
  const [selectedSymbolSila, setSelectedSymbolSila] = useState<number | null>(null);
  const [selectedBunyiSila, setSelectedBunyiSila] = useState<number | null>(null);
  const [isCompleted, setIsCompleted] = useState(false);

  const handleSelectSymbol = (silaNum: number) => {
    if (matchedIds.includes(silaNum)) return;
    playSound.click();
    setSelectedSymbolSila(silaNum);

    if (selectedBunyiSila !== null) {
      checkMatch(silaNum, selectedBunyiSila);
    }
  };

  const handleSelectBunyi = (silaNum: number) => {
    if (matchedIds.includes(silaNum)) return;
    playSound.click();
    setSelectedBunyiSila(silaNum);

    if (selectedSymbolSila !== null) {
      checkMatch(selectedSymbolSila, silaNum);
    }
  };

  const checkMatch = (sym: number, bun: number) => {
    if (sym === bun) {
      playSound.success();
      const updated = [...matchedIds, sym];
      setMatchedIds(updated);
      setSelectedSymbolSila(null);
      setSelectedBunyiSila(null);

      if (updated.length === 5) {
        playSound.fanfare();
        confetti({ particleCount: 50, spread: 70 });
        setIsCompleted(true);
        onFinish(15);
      }
    } else {
      playSound.wrong();
      setTimeout(() => {
        setSelectedSymbolSila(null);
        setSelectedBunyiSila(null);
      }, 700);
    }
  };

  if (isCompleted) {
    return (
      <div className="p-6 text-center bg-white rounded-3xl border-4 border-amber-300 shadow-xl max-w-md mx-auto">
        <div className="w-20 h-20 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-4 border-4 border-amber-300">
          <Trophy className="w-10 h-10 text-amber-500 animate-bounce" />
        </div>
        <h3 className="text-2xl font-black text-slate-800 font-heading">Hebat, Sahabat Garuda!</h3>
        <p className="text-slate-600 mt-2">
          Kamu telah berhasil memasangkan 5 simbol sila Pancasila dengan sempurna!
        </p>
        <div className="my-5 py-3 px-4 bg-amber-50 rounded-2xl border-2 border-amber-200 inline-flex items-center gap-2">
          <Star className="w-6 h-6 text-amber-500 fill-amber-400" />
          <span className="font-black text-lg text-amber-800">+15 Bintang Garuda!</span>
        </div>
        <div className="flex gap-3 justify-center">
          <button
            onClick={() => {
              setMatchedIds([]);
              setIsCompleted(false);
            }}
            className="btn-tactile-yellow px-5 py-3 rounded-2xl font-black text-sm"
          >
            Main Lagi
          </button>
          <button
            onClick={onBack}
            className="btn-tactile-blue text-white px-5 py-3 rounded-2xl font-black text-sm"
          >
            Menu Utama
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gradient-to-b from-red-50 via-amber-50 to-orange-50 p-4 md:p-6 rounded-3xl border-4 border-red-300 shadow-lg">
      <div className="flex items-center justify-between mb-4">
        <button
          onClick={onBack}
          className="p-2 bg-white text-slate-700 rounded-xl border-2 border-slate-200 font-bold hover:bg-slate-50 flex items-center gap-1 text-xs"
        >
          <ArrowLeft className="w-4 h-4" />
          Kembali
        </button>

        <span className="bg-red-100 text-red-900 text-xs font-black px-3 py-1 rounded-full border border-red-200">
          Cocokkan Simbol & Sila: {matchedIds.length} / 5
        </span>
      </div>

      <p className="text-center text-xs md:text-sm font-bold text-slate-700 mb-4 bg-white/80 p-2.5 rounded-xl border border-red-200">
        👆 Sentuh 1 Simbol di kiri, lalu sentuh Bunyi Sila yang cocok di kanan!
      </p>

      <div className="grid grid-cols-2 gap-3 mb-4">
        {/* Left Column: Symbols */}
        <div className="space-y-2.5">
          <div className="text-xs font-black text-slate-600 text-center uppercase tracking-wide">
            Simbol Sila
          </div>
          {PANCASILA_DATA.map((item) => {
            const isMatched = matchedIds.includes(item.sila);
            const isSelected = selectedSymbolSila === item.sila;

            return (
              <button
                key={item.sila}
                disabled={isMatched}
                onClick={() => handleSelectSymbol(item.sila)}
                className={`w-full p-3 rounded-2xl border-2 text-left flex items-center gap-2.5 transition-all ${
                  isMatched
                    ? 'bg-emerald-50 border-emerald-300 opacity-60 cursor-default'
                    : isSelected
                    ? 'bg-amber-300 border-amber-500 scale-102 shadow-md'
                    : 'bg-white border-slate-200 hover:border-amber-400 active:scale-98'
                }`}
              >
                <span className="text-2xl">{item.iconVisual}</span>
                <div className="overflow-hidden">
                  <div className="font-black text-xs md:text-sm text-slate-800 truncate">
                    {item.simbol}
                  </div>
                  <div className="text-[10px] text-slate-500 font-bold">
                    {isMatched ? 'Tercocokkan ✓' : 'Pilih Simbol'}
                  </div>
                </div>
              </button>
            );
          })}
        </div>

        {/* Right Column: Sila Names (Shuffled or distinct order) */}
        <div className="space-y-2.5">
          <div className="text-xs font-black text-slate-600 text-center uppercase tracking-wide">
            Bunyi Sila
          </div>
          {[PANCASILA_DATA[2], PANCASILA_DATA[0], PANCASILA_DATA[4], PANCASILA_DATA[1], PANCASILA_DATA[3]].map((item) => {
            const isMatched = matchedIds.includes(item.sila);
            const isSelected = selectedBunyiSila === item.sila;

            return (
              <button
                key={item.sila}
                disabled={isMatched}
                onClick={() => handleSelectBunyi(item.sila)}
                className={`w-full p-2.5 rounded-2xl border-2 text-left flex items-start gap-2 transition-all ${
                  isMatched
                    ? 'bg-emerald-50 border-emerald-300 opacity-60 cursor-default'
                    : isSelected
                    ? 'bg-amber-300 border-amber-500 scale-102 shadow-md'
                    : 'bg-white border-slate-200 hover:border-amber-400 active:scale-98'
                }`}
              >
                <div className="w-5 h-5 rounded-full bg-red-100 text-red-800 font-black text-[10px] flex items-center justify-center shrink-0 mt-0.5">
                  {item.sila}
                </div>
                <div className="overflow-hidden">
                  <div className="font-bold text-[11px] md:text-xs text-slate-800 leading-snug line-clamp-2">
                    {item.bunyi}
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
