import React, { useState, useEffect } from 'react';
import { Lesson, UserProfile, Subject } from '../../types';
import { speechService, playSound } from '../../services/soundEffects';
import {
  X,
  Volume2,
  VolumeX,
  Pause,
  Play,
  RotateCcw,
  CheckCircle2,
  Sparkles,
  HelpCircle,
  Lightbulb,
  Clock,
  ArrowRight,
  BookOpen,
  FileQuestion,
  Image as ImageIcon
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { Mascot } from '../mascot/Mascot';

interface LessonModalProps {
  lesson: Lesson;
  subject: Subject;
  profile: UserProfile;
  onClose: () => void;
  onComplete: (lessonId: string) => void;
  onStartQuiz: (lessonId: string) => void;
}

export const LessonModal: React.FC<LessonModalProps> = ({
  lesson,
  subject,
  profile,
  onClose,
  onComplete,
  onStartQuiz
}) => {
  const [audioState, setAudioState] = useState<'stopped' | 'playing' | 'paused'>('stopped');
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(0.95);
  const [activeTab, setActiveTab] = useState<'content' | 'examples'>('content');
  const isCompleted = profile.completedLessons.includes(lesson.id);

  useEffect(() => {
    return () => {
      speechService.stop();
    };
  }, []);

  const fullTextToRead = `${lesson.title}. ${lesson.summary}. ${lesson.contentParagraphs.join(' ')}`;

  const handlePlayAudio = () => {
    playSound.click();
    if (audioState === 'paused') {
      speechService.resume();
      setAudioState('playing');
    } else {
      setAudioState('playing');
      speechService.speak(fullTextToRead, {
        rate: playbackSpeed,
        onEnd: () => setAudioState('stopped'),
        onError: () => setAudioState('stopped')
      });
    }
  };

  const handlePauseAudio = () => {
    playSound.click();
    speechService.pause();
    setAudioState('paused');
  };

  const handleReplayAudio = () => {
    playSound.click();
    setAudioState('playing');
    speechService.speak(fullTextToRead, {
      rate: playbackSpeed,
      onEnd: () => setAudioState('stopped'),
      onError: () => setAudioState('stopped')
    });
  };

  const handleChangeSpeed = (newSpeed: number) => {
    playSound.click();
    setPlaybackSpeed(newSpeed);
    if (audioState === 'playing') {
      speechService.speak(fullTextToRead, {
        rate: newSpeed,
        onEnd: () => setAudioState('stopped'),
        onError: () => setAudioState('stopped')
      });
    }
  };

  const handleMarkComplete = () => {
    playSound.success();
    confetti({ particleCount: 40, spread: 60 });
    onComplete(lesson.id);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-3 md:p-6 overflow-y-auto">
      <div className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl border-4 border-sky-300 overflow-hidden my-auto max-h-[92vh] flex flex-col">
        {/* Header with subject color banner */}
        <div
          className="p-4 md:p-5 text-white flex items-center justify-between shrink-0 shadow-xs"
          style={{ backgroundColor: subject.color }}
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/20 backdrop-blur-xs flex items-center justify-center font-black text-lg border border-white/30">
              {lesson.chapterNumber}
            </div>
            <div>
              <div className="text-xs font-bold uppercase tracking-wider text-white/90">
                {subject.name} • Kelas {lesson.grade} SD
              </div>
              <h2 className="font-heading font-black text-lg md:text-xl text-white leading-tight">
                {lesson.title}
              </h2>
            </div>
          </div>

          <button
            onClick={() => {
              speechService.stop();
              onClose();
            }}
            className="w-9 h-9 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Audio Control Bar with Putar, Jeda, and Ulangi */}
        <div className="bg-sky-50 px-4 py-2.5 border-b-2 border-sky-100 flex flex-wrap items-center justify-between gap-2 shrink-0">
          <div className="flex items-center gap-1.5">
            <span className="text-[11px] font-black text-slate-600 mr-1 flex items-center gap-1">
              <Volume2 className="w-3.5 h-3.5 text-sky-600" />
              <span>Audio:</span>
            </span>

            {/* Putar / Play */}
            {audioState !== 'playing' ? (
              <button
                onClick={handlePlayAudio}
                className="bg-sky-600 hover:bg-sky-700 text-white font-black px-3 py-1.5 rounded-xl text-xs flex items-center gap-1 shadow-xs cursor-pointer"
              >
                <Play className="w-3.5 h-3.5 fill-white" />
                <span>{audioState === 'paused' ? 'Lanjutkan' : 'Putar'}</span>
              </button>
            ) : (
              /* Jeda / Pause */
              <button
                onClick={handlePauseAudio}
                className="bg-amber-500 hover:bg-amber-600 text-white font-black px-3 py-1.5 rounded-xl text-xs flex items-center gap-1 shadow-xs cursor-pointer animate-pulse"
              >
                <Pause className="w-3.5 h-3.5" />
                <span>Jeda</span>
              </button>
            )}

            {/* Ulangi / Replay */}
            <button
              onClick={handleReplayAudio}
              title="Ulangi dari awal"
              className="bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 font-bold px-2.5 py-1.5 rounded-xl text-xs flex items-center gap-1 cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5 text-slate-600" />
              <span>Ulangi</span>
            </button>

            {/* Speed pills */}
            <div className="hidden sm:flex items-center gap-1 bg-white p-0.5 rounded-xl border border-sky-200 text-[11px] ml-1">
              {[0.8, 0.95, 1.15].map((spd) => (
                <button
                  key={spd}
                  onClick={() => handleChangeSpeed(spd)}
                  className={`px-2 py-0.5 rounded-lg font-bold cursor-pointer transition-all ${
                    playbackSpeed === spd
                      ? 'bg-sky-500 text-white'
                      : 'text-slate-600 hover:text-sky-800'
                  }`}
                >
                  {spd === 0.8 ? '0.8x' : spd === 0.95 ? '1x' : '1.2x'}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-1.5 text-xs text-slate-500 font-bold">
            <Clock className="w-3.5 h-3.5 text-sky-600" />
            <span>~{lesson.durationMinutes} menit</span>
          </div>
        </div>

        {/* Content Tabs */}
        <div className="flex border-b border-slate-200 bg-slate-50 px-4 pt-2 shrink-0 gap-2">
          <button
            onClick={() => setActiveTab('content')}
            className={`px-4 py-2 font-black text-xs md:text-sm rounded-t-xl transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'content'
                ? 'bg-white text-sky-700 border-t-2 border-x border-slate-200 -mb-[1px] shadow-xs'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>Materi & Ilustrasi</span>
          </button>

          <button
            onClick={() => setActiveTab('examples')}
            className={`px-4 py-2 font-black text-xs md:text-sm rounded-t-xl transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'examples'
                ? 'bg-white text-sky-700 border-t-2 border-x border-slate-200 -mb-[1px] shadow-xs'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <Lightbulb className="w-4 h-4 text-amber-500" />
            <span>Contoh Soal ({lesson.examples?.length || 1})</span>
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="p-4 md:p-6 overflow-y-auto space-y-5 flex-1">
          {activeTab === 'content' && (
            <>
              {/* Mascot Fun Fact Banner */}
              <div className="bg-amber-50 rounded-2xl p-4 border-2 border-amber-300 flex items-start gap-3 shadow-xs">
                <Mascot type="boni" size="sm" showBubble={false} className="shrink-0 -mt-1" />
                <div>
                  <div className="text-xs font-black text-amber-800 flex items-center gap-1 uppercase tracking-wide">
                    <Sparkles className="w-4 h-4 text-amber-500" />
                    Tahukah Kamu?
                  </div>
                  <p className="text-sm text-slate-700 font-bold mt-0.5">
                    {lesson.funFact}
                  </p>
                </div>
              </div>

              {/* Educational Illustrations (Cards with emoji & explanation) */}
              {lesson.illustrations && lesson.illustrations.length > 0 && (
                <div>
                  <div className="text-xs font-black text-slate-500 uppercase tracking-wide mb-2 flex items-center gap-1">
                    <ImageIcon className="w-3.5 h-3.5 text-sky-600" />
                    <span>Ilustrasi Edukatif:</span>
                  </div>
                  <div className="grid grid-cols-3 gap-2.5">
                    {lesson.illustrations.map((ill, idx) => (
                      <div
                        key={idx}
                        className="bg-sky-50/70 border border-sky-200 rounded-2xl p-3 text-center flex flex-col items-center justify-center hover:scale-102 transition-transform"
                      >
                        <span className="text-3xl mb-1">{ill.emoji}</span>
                        <span className="font-black text-xs text-slate-800">{ill.title}</span>
                        <span className="text-[10px] text-slate-500 font-bold mt-0.5 line-clamp-1">
                          {ill.caption}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Lesson Paragraphs */}
              <div className="space-y-3 text-slate-700 leading-relaxed text-sm md:text-base">
                {lesson.contentParagraphs.map((p, idx) => (
                  <p key={idx} className="whitespace-pre-line font-medium bg-slate-50 p-3.5 rounded-2xl border border-slate-200">
                    {p}
                  </p>
                ))}
              </div>

              {/* Key Points */}
              <div className="bg-emerald-50 rounded-2xl p-4 border-2 border-emerald-300">
                <h4 className="font-heading font-black text-emerald-900 text-sm md:text-base mb-2 flex items-center gap-1.5">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                  Poin Penting Pelajaran:
                </h4>
                <ul className="space-y-1.5">
                  {lesson.keyPoints.map((pt, i) => (
                    <li key={i} className="text-xs md:text-sm text-emerald-950 font-bold flex items-start gap-2">
                      <span className="text-emerald-500 font-black">•</span>
                      <span>{pt}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </>
          )}

          {activeTab === 'examples' && (
            <div className="space-y-4">
              <div className="bg-blue-50 rounded-2xl p-4 border-2 border-blue-200">
                <div className="flex items-center gap-2 mb-2">
                  <Lightbulb className="w-5 h-5 text-amber-500 fill-amber-400" />
                  <h4 className="font-heading font-black text-blue-950 text-base">
                    Contoh Soal & Cara Mudah Memahaminya:
                  </h4>
                </div>
                <p className="text-xs text-slate-600 font-semibold mb-3">
                  Pelajari langkah penyelesaian di bawah sebelum kamu mencoba kuis latihan ya!
                </p>

                {lesson.examples && lesson.examples.length > 0 ? (
                  lesson.examples.map((ex, idx) => (
                    <div key={idx} className="bg-white rounded-2xl p-4 border border-blue-200 space-y-3 shadow-xs">
                      <div className="font-black text-sm md:text-base text-slate-900 flex items-start gap-2">
                        <span className="bg-sky-500 text-white text-xs px-2 py-0.5 rounded-md">
                          Soal
                        </span>
                        <span>{ex.question}</span>
                      </div>

                      <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 space-y-1.5 pl-3">
                        <span className="text-[11px] font-black text-slate-500 uppercase">
                          Langkah Penyelesaian:
                        </span>
                        {ex.steps.map((st, sIdx) => (
                          <div key={sIdx} className="text-xs text-slate-700 font-semibold flex items-start gap-2">
                            <span className="text-sky-600 font-bold">{sIdx + 1}.</span>
                            <span>{st}</span>
                          </div>
                        ))}
                      </div>

                      <div className="bg-emerald-100 text-emerald-900 font-black text-xs md:text-sm p-2.5 rounded-xl border border-emerald-300 flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                        <span>Jawaban: {ex.answer}</span>
                      </div>

                      {ex.tip && (
                        <div className="text-xs text-amber-900 font-bold bg-amber-50 p-2.5 rounded-xl border border-amber-200">
                          💡 Tips Boni: {ex.tip}
                        </div>
                      )}
                    </div>
                  ))
                ) : (
                  <div className="text-xs text-slate-500 text-center py-4">
                    Contoh soal sedang disiapkan oleh Boni.
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="p-4 bg-slate-50 border-t-2 border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
          <div className="w-full sm:w-auto">
            {!isCompleted ? (
              <button
                onClick={handleMarkComplete}
                className="w-full sm:w-auto btn-tactile-green text-white font-black px-5 py-2.5 rounded-2xl text-xs md:text-sm flex items-center justify-center gap-2 shadow-xs cursor-pointer"
              >
                <CheckCircle2 className="w-4 h-4" />
                Tandai Selesai (+5 Bintang)
              </button>
            ) : (
              <div className="flex items-center gap-1.5 text-xs font-black text-emerald-700 bg-emerald-100 px-3 py-1.5 rounded-xl border border-emerald-300">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                Materi Selesai Dibaca!
              </div>
            )}
          </div>

          <button
            onClick={() => {
              speechService.stop();
              onStartQuiz(lesson.id);
            }}
            className="w-full sm:w-auto btn-tactile-yellow font-black px-6 py-2.5 rounded-2xl text-xs md:text-sm flex items-center justify-center gap-2 shadow-xs cursor-pointer"
          >
            <HelpCircle className="w-4 h-4 text-amber-900" />
            <span>Mulai Latihan & Kuis ({lesson.exercises?.length || 4} Soal)</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
