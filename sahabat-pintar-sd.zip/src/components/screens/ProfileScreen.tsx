import React, { useState } from 'react';
import { UserProfile, AvatarId, Grade } from '../../types';
import { AVATARS, BADGES } from '../../data/subjects';
import { playSound } from '../../services/soundEffects';
import {
  Trophy,
  Star,
  User,
  GraduationCap,
  Sparkles,
  RotateCcw,
  Check,
  Edit2,
  Calendar,
  Award,
  ShieldCheck
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface ProfileScreenProps {
  profile: UserProfile;
  onUpdateName: (name: string, schoolName?: string) => void;
  onUpdateAvatar: (avatarId: AvatarId) => void;
  onUpdateGrade: (grade: Grade) => void;
  onResetProgress: () => void;
}

export const ProfileScreen: React.FC<ProfileScreenProps> = ({
  profile,
  onUpdateName,
  onUpdateAvatar,
  onUpdateGrade,
  onResetProgress
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [nameInput, setNameInput] = useState(profile.name);
  const [schoolInput, setSchoolInput] = useState(profile.schoolName);
  const [showConfirmReset, setShowConfirmReset] = useState(false);

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    playSound.success();
    onUpdateName(nameInput, schoolInput);
    setIsEditing(false);
  };

  const getAvatarEmoji = (id: AvatarId) => {
    switch (id) {
      case 'boni':
        return '👦';
      case 'sasa':
        return '👧';
      case 'edo':
        return '🧑';
      case 'siti':
        return '🧕';
      case 'dayu':
        return '👧';
      case 'budi':
        return '👦';
      default:
        return '👦';
    }
  };

  return (
    <div className="p-4 md:p-6 max-w-4xl mx-auto space-y-6">
      {/* Student ID Card (Kartu Pelajar Pintar) */}
      <div className="bg-gradient-to-br from-sky-600 via-sky-500 to-blue-700 rounded-3xl p-5 md:p-6 text-white shadow-xl relative overflow-hidden border-4 border-sky-300">
        {/* Decorative background circles */}
        <div className="absolute -right-10 -bottom-10 w-40 h-40 bg-white/10 rounded-full pointer-events-none" />
        <div className="absolute -left-10 -top-10 w-32 h-32 bg-amber-400/20 rounded-full pointer-events-none" />

        <div className="flex flex-col sm:flex-row items-center sm:items-start gap-5 relative z-10">
          {/* Avatar Graphic with badge */}
          <div className="relative">
            <div className="w-24 h-24 rounded-3xl bg-white border-4 border-amber-300 flex items-center justify-center text-5xl shadow-lg">
              {getAvatarEmoji(profile.avatarId)}
            </div>
            <div className="absolute -bottom-2 -right-2 bg-amber-400 text-amber-950 text-[10px] font-black px-2 py-0.5 rounded-full border border-amber-500 shadow-xs">
              Kls {profile.grade} SD
            </div>
          </div>

          {/* Student Info */}
          <div className="flex-1 text-center sm:text-left">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <span className="bg-white/20 text-white text-[10px] font-black px-2.5 py-0.5 rounded-full inline-block uppercase tracking-wider">
                  Kartu Siswa Sahabat Pintar
                </span>
                <h2 className="font-heading font-black text-2xl text-white mt-0.5">
                  {profile.name}
                </h2>
                <p className="text-xs text-sky-100 font-semibold flex items-center justify-center sm:justify-start gap-1.5 mt-0.5">
                  <GraduationCap className="w-4 h-4 text-amber-300" />
                  {profile.schoolName}
                </p>
              </div>

              <button
                onClick={() => {
                  playSound.click();
                  setIsEditing((e) => !e);
                }}
                className="bg-white text-sky-800 hover:bg-sky-50 text-xs font-black px-3.5 py-1.5 rounded-xl shadow-xs self-center sm:self-start flex items-center gap-1.5 cursor-pointer"
              >
                <Edit2 className="w-3.5 h-3.5" />
                <span>{isEditing ? 'Batal' : 'Ubah Nama'}</span>
              </button>
            </div>

            {/* Quick Stats in Card */}
            <div className="grid grid-cols-3 gap-2 mt-4 pt-3 border-t border-white/20 text-center">
              <div className="bg-white/10 backdrop-blur-xs p-2 rounded-xl">
                <div className="text-[10px] text-sky-200 font-bold uppercase">Bintang</div>
                <div className="font-black text-base text-amber-300 flex items-center justify-center gap-1">
                  <Star className="w-4 h-4 fill-amber-300" />
                  {profile.stars}
                </div>
              </div>

              <div className="bg-white/10 backdrop-blur-xs p-2 rounded-xl">
                <div className="text-[10px] text-sky-200 font-bold uppercase">Materi Selesai</div>
                <div className="font-black text-base text-white">
                  {profile.completedLessons.length} Bab
                </div>
              </div>

              <div className="bg-white/10 backdrop-blur-xs p-2 rounded-xl">
                <div className="text-[10px] text-sky-200 font-bold uppercase">Lencana</div>
                <div className="font-black text-base text-emerald-300">
                  {profile.unlockedBadges.length} Piala
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Edit Form */}
        {isEditing && (
          <form
            onSubmit={handleSaveProfile}
            className="mt-4 pt-4 border-t border-white/20 bg-white/10 backdrop-blur-md p-4 rounded-2xl space-y-3"
          >
            <div>
              <label className="text-xs font-bold text-sky-100 block mb-1">
                Nama Panggilan Siswa:
              </label>
              <input
                type="text"
                value={nameInput}
                onChange={(e) => setNameInput(e.target.value)}
                maxLength={24}
                className="w-full bg-white text-slate-800 font-bold px-3 py-2 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-amber-300"
                placeholder="Misal: Budi Santoso"
                required
              />
            </div>

            <div>
              <label className="text-xs font-bold text-sky-100 block mb-1">
                Nama Sekolah:
              </label>
              <input
                type="text"
                value={schoolInput}
                onChange={(e) => setSchoolInput(e.target.value)}
                maxLength={40}
                className="w-full bg-white text-slate-800 font-bold px-3 py-2 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-amber-300"
                placeholder="Misal: SD Negeri 01 Merdeka"
              />
            </div>

            <button
              type="submit"
              className="btn-tactile-yellow font-black px-4 py-2 rounded-xl text-xs flex items-center gap-1.5 cursor-pointer shadow-xs"
            >
              <Check className="w-4 h-4 text-amber-950" />
              <span>Simpan Profil</span>
            </button>
          </form>
        )}
      </div>

      {/* Avatar Picker */}
      <div className="bg-white rounded-3xl p-5 border-2 border-slate-200 shadow-xs">
        <h3 className="font-heading font-black text-base text-slate-800 mb-1 flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-amber-500" />
          Pilih Karakter Maskot Favoritmu:
        </h3>
        <p className="text-xs text-slate-500 font-semibold mb-4">
          Pilih sahabat yang akan menemanimu di setiap materi pelajaran.
        </p>

        <div className="grid grid-cols-3 sm:grid-cols-6 gap-3">
          {AVATARS.map((av) => {
            const isSelected = profile.avatarId === av.id;

            return (
              <button
                key={av.id}
                onClick={() => {
                  playSound.click();
                  onUpdateAvatar(av.id);
                }}
                className={`flex flex-col items-center p-3 rounded-2xl border-2 transition-all cursor-pointer ${
                  isSelected
                    ? 'border-sky-500 bg-sky-50 ring-2 ring-sky-300 scale-105'
                    : 'border-slate-200 bg-white hover:border-sky-300'
                }`}
              >
                <div className="text-3xl mb-1">{getAvatarEmoji(av.id)}</div>
                <span className="font-black text-xs text-slate-800">{av.name}</span>
                <span className="text-[10px] text-slate-500 font-bold text-center line-clamp-1">
                  {av.title}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Badges Cabinet (Lencana & Piala) */}
      <div className="bg-white rounded-3xl p-5 border-2 border-slate-200 shadow-xs">
        <h3 className="font-heading font-black text-base text-slate-800 mb-1 flex items-center gap-2">
          <Trophy className="w-5 h-5 text-amber-500" />
          Lemari Lencana & Prestasi:
        </h3>
        <p className="text-xs text-slate-500 font-semibold mb-4">
          Kumpulkan semua lencana dengan rajin membaca materi dan meraih nilai kuis 100!
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
          {BADGES.map((badge) => {
            const isUnlocked = profile.unlockedBadges.includes(badge.id);

            return (
              <div
                key={badge.id}
                className={`p-3.5 rounded-2xl border-2 flex items-start gap-3 transition-all ${
                  isUnlocked
                    ? 'bg-amber-50/60 border-amber-300 shadow-xs'
                    : 'bg-slate-50 border-slate-200 opacity-50'
                }`}
              >
                <div
                  className={`w-10 h-10 rounded-xl flex items-center justify-center font-black text-lg shrink-0 ${
                    isUnlocked ? 'bg-amber-400 text-amber-950 shadow-xs' : 'bg-slate-200 text-slate-400'
                  }`}
                >
                  <Award className="w-5 h-5" />
                </div>

                <div>
                  <div className="flex items-center gap-1.5">
                    <h4 className="font-heading font-black text-xs md:text-sm text-slate-800">
                      {badge.title}
                    </h4>
                    {isUnlocked && (
                      <span className="text-[10px] font-black text-emerald-700 bg-emerald-100 px-1.5 py-0.2 rounded">
                        ✓ Terbuka
                      </span>
                    )}
                  </div>
                  <p className="text-[11px] text-slate-500 font-semibold mt-0.5 leading-snug">
                    {badge.description}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Quiz History */}
      <div className="bg-white rounded-3xl p-5 border-2 border-slate-200 shadow-xs">
        <h3 className="font-heading font-black text-base text-slate-800 mb-3 flex items-center gap-2">
          <Calendar className="w-4 h-4 text-sky-600" />
          Riwayat Kuis Terakhir:
        </h3>

        {profile.quizHistory.length === 0 ? (
          <div className="text-center py-6 text-xs text-slate-400 font-bold">
            Belum ada riwayat kuis. Ayo mulai kuis pertamamu di tab Kuis!
          </div>
        ) : (
          <div className="space-y-2">
            {profile.quizHistory.slice(0, 5).map((q, idx) => (
              <div
                key={idx}
                className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between gap-3 text-xs"
              >
                <div>
                  <div className="font-black text-slate-800">{q.quizTitle}</div>
                  <div className="text-[10px] text-slate-400 font-semibold">
                    {q.date} • Kelas {q.grade} SD
                  </div>
                </div>

                <div className="flex items-center gap-3 shrink-0">
                  <span className="font-black text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-lg border border-emerald-200">
                    Nilai: {q.percentage}% ({q.score}/{q.totalQuestions})
                  </span>
                  <span className="font-black text-amber-700 flex items-center gap-1">
                    <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-500" />
                    +{q.starsEarned}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Danger Zone: Reset Data */}
      <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 flex items-center justify-between">
        <div>
          <div className="text-xs font-bold text-slate-700">Mulai Ulang Progres Belajar</div>
          <div className="text-[10px] text-slate-500">
            Mengatur ulang bintang dan status materi jika ingin mengulang dari awal.
          </div>
        </div>

        {!showConfirmReset ? (
          <button
            onClick={() => setShowConfirmReset(true)}
            className="text-xs font-bold text-rose-600 hover:text-rose-700 p-2 rounded-xl border border-rose-200 bg-white hover:bg-rose-50 cursor-pointer"
          >
            Reset
          </button>
        ) : (
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                playSound.click();
                onResetProgress();
                setShowConfirmReset(false);
              }}
              className="text-xs font-black bg-rose-600 text-white px-3 py-1.5 rounded-xl cursor-pointer"
            >
              Ya, Reset
            </button>
            <button
              onClick={() => setShowConfirmReset(false)}
              className="text-xs font-bold bg-slate-200 text-slate-700 px-3 py-1.5 rounded-xl cursor-pointer"
            >
              Batal
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
