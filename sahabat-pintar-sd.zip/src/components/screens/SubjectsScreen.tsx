import React, { useState } from 'react';
import { Subject, Lesson, UserProfile, Grade, SubjectId } from '../../types';
import { SUBJECTS } from '../../data/subjects';
import { getLessonsForSubjectAndGrade, getQuizForLesson } from '../../data/learningContent';
import { playSound } from '../../services/soundEffects';
import {
  BookOpen,
  CheckCircle2,
  Clock,
  Sparkles,
  ArrowRight,
  HelpCircle,
  Calculator,
  Compass,
  ShieldCheck,
  Globe,
  Palette,
  HeartHandshake,
  Search
} from 'lucide-react';

interface SubjectsScreenProps {
  profile: UserProfile;
  initialSubjectId?: SubjectId;
  onSelectLesson: (lesson: Lesson, subject: Subject) => void;
  onStartQuiz: (quizId: string) => void;
}

export const SubjectsScreen: React.FC<SubjectsScreenProps> = ({
  profile,
  initialSubjectId,
  onSelectLesson,
  onStartQuiz
}) => {
  const [selectedSubjectId, setSelectedSubjectId] = useState<SubjectId>(
    initialSubjectId || 'matematika'
  );
  const [searchQuery, setSearchQuery] = useState('');

  const currentSubject =
    SUBJECTS.find((s) => s.id === selectedSubjectId) || SUBJECTS[0];

  // Map icon names to Lucide icon components
  const renderSubjectIcon = (iconName: string, className = 'w-6 h-6') => {
    switch (iconName) {
      case 'BookOpen':
        return <BookOpen className={className} />;
      case 'Calculator':
        return <Calculator className={className} />;
      case 'Compass':
        return <Compass className={className} />;
      case 'ShieldCheck':
        return <ShieldCheck className={className} />;
      case 'Globe':
        return <Globe className={className} />;
      case 'Palette':
        return <Palette className={className} />;
      case 'HeartHandshake':
        return <HeartHandshake className={className} />;
      default:
        return <BookOpen className={className} />;
    }
  };

  // Find lessons for this subject dynamically tailored to the student's selected grade
  const availableLessons = getLessonsForSubjectAndGrade(selectedSubjectId, profile.grade);

  const filteredLessons = availableLessons.filter((l) =>
    l.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    l.subtitle.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="p-4 md:p-6 max-w-4xl mx-auto space-y-6">
      {/* 7 Subjects Horizontal Chip Bar */}
      <div>
        <div className="text-xs font-black text-slate-500 uppercase tracking-wide mb-2">
          Pilih Mata Pelajaran:
        </div>
        <div className="flex gap-2.5 overflow-x-auto pb-2 scrollbar-none">
          {SUBJECTS.map((sub) => {
            const isSelected = sub.id === selectedSubjectId;

            return (
              <button
                key={sub.id}
                onClick={() => {
                  playSound.click();
                  setSelectedSubjectId(sub.id);
                }}
                className={`flex items-center gap-2 px-3.5 py-2.5 rounded-2xl border-2 shrink-0 transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-sky-600 border-sky-700 text-white shadow-md scale-102'
                    : 'bg-white border-slate-200 text-slate-700 hover:border-sky-300'
                }`}
              >
                <div
                  className={`w-7 h-7 rounded-xl flex items-center justify-center shrink-0 ${
                    isSelected ? 'bg-white/20 text-white' : 'text-slate-600'
                  }`}
                  style={{ color: !isSelected ? sub.color : undefined }}
                >
                  {renderSubjectIcon(sub.iconName, 'w-4 h-4')}
                </div>
                <span className="text-xs font-black whitespace-nowrap">
                  {sub.shortName}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Active Subject Banner */}
      <div
        className="rounded-3xl p-5 text-white shadow-md relative overflow-hidden"
        style={{ backgroundColor: currentSubject.color }}
      >
        <div className="flex items-start justify-between gap-4">
          <div>
            <span className="bg-white/20 text-white text-[10px] font-black px-2.5 py-0.5 rounded-full inline-block uppercase tracking-wider mb-1">
              {currentSubject.badgeTag} • Kelas {profile.grade} SD
            </span>
            <h2 className="font-heading font-black text-xl md:text-2xl text-white">
              {currentSubject.name}
            </h2>
            <p className="text-xs md:text-sm text-white/90 mt-1 max-w-lg leading-relaxed font-medium">
              {currentSubject.description}
            </p>
          </div>

          <div className="w-14 h-14 rounded-2xl bg-white/20 backdrop-blur-xs flex items-center justify-center shrink-0 border border-white/30 text-white">
            {renderSubjectIcon(currentSubject.iconName, 'w-7 h-7')}
          </div>
        </div>
      </div>

      {/* Lesson List Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <h3 className="font-heading font-black text-base text-slate-800 flex items-center gap-2">
          <span>Daftar Bab & Materi Belajar</span>
          <span className="text-xs font-bold text-sky-700 bg-sky-100 px-2 py-0.5 rounded-full">
            {filteredLessons.length} Bab
          </span>
        </h3>

        {/* Search */}
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Cari bab atau materi..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9 pr-4 py-1.5 text-xs rounded-xl border border-slate-200 bg-white focus:outline-none focus:border-sky-400 w-full sm:w-56"
          />
        </div>
      </div>

      {/* Lessons Cards */}
      <div className="space-y-3.5">
        {filteredLessons.map((lesson) => {
          const isDone = profile.completedLessons.includes(lesson.id);
          const relatedQuiz = getQuizForLesson(lesson);

          return (
            <div
              key={lesson.id}
              className={`bg-white rounded-2xl p-4 md:p-5 border-2 transition-all shadow-xs hover:shadow-md ${
                isDone ? 'border-emerald-300 bg-emerald-50/20' : 'border-slate-200 hover:border-sky-300'
              }`}
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-start gap-3.5">
                  <div
                    className={`w-12 h-12 rounded-2xl flex items-center justify-center font-black text-lg shrink-0 border ${
                      isDone
                        ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                        : 'bg-sky-50 text-sky-800 border-sky-200'
                    }`}
                  >
                    {isDone ? (
                      <CheckCircle2 className="w-6 h-6 text-emerald-600" />
                    ) : (
                      lesson.chapterNumber
                    )}
                  </div>

                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-black text-slate-500 uppercase tracking-wide">
                        Bab {lesson.chapterNumber} • {lesson.category}
                      </span>
                      {isDone && (
                        <span className="text-[10px] font-black text-emerald-700 bg-emerald-100 px-2 py-0.2 rounded-full">
                          Selesai Dibaca ✓
                        </span>
                      )}
                    </div>

                    <h4 className="font-heading font-black text-base text-slate-800 mt-0.5 leading-snug">
                      {lesson.title}
                    </h4>
                    <p className="text-xs text-slate-500 font-semibold mt-0.5 line-clamp-2">
                      {lesson.subtitle}
                    </p>

                    <div className="flex items-center gap-3 mt-2 text-[11px] text-slate-400 font-bold">
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3 text-sky-500" />
                        {lesson.durationMinutes} Menit
                      </span>
                      <span className="flex items-center gap-1">
                        <Sparkles className="w-3 h-3 text-amber-500" />
                        Audio Narasi Boni
                      </span>
                    </div>
                  </div>
                </div>

                {/* Action buttons */}
                <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
                  <button
                    onClick={() => {
                      playSound.click();
                      onSelectLesson(lesson, currentSubject);
                    }}
                    className="btn-tactile-blue text-white font-black px-4 py-2 rounded-xl text-xs flex items-center gap-1.5 cursor-pointer"
                  >
                    <BookOpen className="w-3.5 h-3.5" />
                    <span>Baca Materi</span>
                  </button>

                  {relatedQuiz && (
                    <button
                      onClick={() => {
                        playSound.click();
                        onStartQuiz(relatedQuiz.id);
                      }}
                      className="btn-tactile-yellow font-black px-3.5 py-2 rounded-xl text-xs flex items-center gap-1.5 cursor-pointer"
                    >
                      <HelpCircle className="w-3.5 h-3.5 text-amber-950" />
                      <span>Kuis</span>
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}

        {filteredLessons.length === 0 && (
          <div className="text-center p-8 bg-white rounded-3xl border-2 border-slate-200">
            <p className="text-sm font-bold text-slate-500">
              Tidak ada materi yang cocok dengan pencarianmu.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
