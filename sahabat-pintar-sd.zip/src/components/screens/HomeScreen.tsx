import React from 'react';
import { UserProfile, Grade, Subject, Lesson, SubjectId } from '../../types';
import { SUBJECTS } from '../../data/subjects';
import { getAllLessonsForGrade, getLessonsForSubjectAndGrade, findLessonById } from '../../data/learningContent';
import { playSound } from '../../services/soundEffects';
import {
  Star,
  BookOpen,
  Calculator,
  Compass,
  ShieldCheck,
  Globe,
  Palette,
  HeartHandshake,
  ArrowRight,
  Sparkles,
  Gamepad2,
  Trophy,
  PlayCircle,
  HelpCircle,
  Clock
} from 'lucide-react';
import { Mascot } from '../mascot/Mascot';

interface HomeScreenProps {
  profile: UserProfile;
  onGradeChange: (grade: Grade) => void;
  onSelectSubject: (subjectId: SubjectId) => void;
  onResumeLesson: (lesson: Lesson, subject: Subject) => void;
  onOpenGames: () => void;
  onOpenQuizzes: () => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  profile,
  onGradeChange,
  onSelectSubject,
  onResumeLesson,
  onOpenGames,
  onOpenQuizzes
}) => {
  // Find the last or recommended lesson for this student in their active grade
  const currentGradeLessons = getAllLessonsForGrade(profile.grade);
  const lastLesson =
    (profile.lastLessonId ? findLessonById(profile.lastLessonId) : null) ||
    currentGradeLessons[0];

  const lastLessonSubject =
    SUBJECTS.find((s) => s.id === lastLesson.subjectId) || SUBJECTS[0];

  // Helper for Subject Icons
  const renderSubjectIcon = (iconName: string, className = 'w-6 h-6') => {
    switch (iconName) {
      case 'BookOpen':
        return <BookOpen className={className} />;
      case 'Calculator':
        return <Calculator className={className} />;
      case 'Compass':
        return <Compass className={className} />;
      case 'ShieldCheck':
        return <ShieldCheck className={className} />;
      case 'Globe':
        return <Globe className={className} />;
      case 'Palette':
        return <Palette className={className} />;
      case 'HeartHandshake':
        return <HeartHandshake className={className} />;
      default:
        return <BookOpen className={className} />;
    }
  };

  // Grade Phase details for Kurikulum Merdeka
  const getPhaseDescription = (grade: Grade) => {
    if (grade <= 2) return 'Fase A (Pondasi Membaca & Berhitung)';
    if (grade <= 4) return 'Fase B (Pemahaman Sains & Logika)';
    return 'Fase C (Penalaran Kritis & Karakter)';
  };

  return (
    <div className="p-4 md:p-6 max-w-4xl mx-auto space-y-6">
      {/* Hero Card: Mascot Welcome & Speech */}
      <div className="bg-gradient-to-r from-sky-500 via-sky-400 to-blue-500 rounded-3xl p-5 md:p-6 text-white shadow-xl relative overflow-hidden border-4 border-sky-300">
        <div className="flex flex-col sm:flex-row items-center sm:items-start justify-between gap-4 relative z-10">
          <div className="text-center sm:text-left max-w-md">
            <div className="inline-flex items-center gap-1.5 bg-white/20 backdrop-blur-xs text-white text-[11px] font-black px-3 py-1 rounded-full uppercase tracking-wider mb-2">
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
              <span>Kurikulum Merdeka SD Indonesia</span>
            </div>

            <h2 className="font-heading font-black text-2xl md:text-3xl text-white leading-tight">
              Halo, {profile.name}! 👋
            </h2>

            <p className="text-xs md:text-sm text-sky-100 font-semibold mt-1 leading-relaxed">
              Selamat datang di <span className="font-black text-white">Sahabat Pintar SD</span>! Boni siap menemanimu belajar materi seru, main game edukasi, dan mengumpulkan bintang emas!
            </p>

            {/* Quick Resume Button */}
            <div className="mt-4 flex flex-wrap gap-2.5 justify-center sm:justify-start">
              <button
                onClick={() => {
                  playSound.click();
                  onResumeLesson(lastLesson, lastLessonSubject);
                }}
                className="btn-tactile-yellow font-black px-5 py-3 rounded-2xl text-xs md:text-sm flex items-center gap-2 cursor-pointer shadow-md"
              >
                <PlayCircle className="w-4 h-4 text-amber-950" />
                <span>Lanjutkan Belajar: {lastLessonSubject.shortName}</span>
                <ArrowRight className="w-4 h-4 text-amber-950" />
              </button>
            </div>
          </div>

          {/* Interactive Mascot with Speech */}
          <div className="shrink-0 -mb-2 sm:mb-0">
            <Mascot
              type="boni"
              size="lg"
              showBubble={true}
              bubbleText="Yuk belajar bersama Boni!"
            />
          </div>
        </div>
      </div>

      {/* Pilihan Kelas 1 sampai 6 (Big Tactile Touch Buttons) */}
      <div className="bg-white rounded-3xl p-5 border-2 border-slate-200 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 mb-3">
          <div>
            <h3 className="font-heading font-black text-base text-slate-800 flex items-center gap-2">
              <span>Pilihan Kelas Sekolah Dasar:</span>
            </h3>
            <p className="text-xs text-slate-500 font-semibold">
              Materi disesuaikan otomatis dengan tingkat kelas yang kamu pilih ({getPhaseDescription(profile.grade)})
            </p>
          </div>

          <span className="text-[11px] font-black text-sky-700 bg-sky-50 px-2.5 py-1 rounded-full self-start sm:self-auto">
            Aktif: Kelas {profile.grade} SD
          </span>
        </div>

        <div className="grid grid-cols-3 sm:grid-cols-6 gap-2.5">
          {([1, 2, 3, 4, 5, 6] as Grade[]).map((g) => {
            const isSelected = profile.grade === g;

            return (
              <button
                key={g}
                onClick={() => {
                  playSound.click();
                  onGradeChange(g);
                }}
                className={`py-3 px-2 rounded-2xl border-2 transition-all cursor-pointer flex flex-col items-center justify-center relative ${
                  isSelected
                    ? 'btn-tactile-blue text-white font-black shadow-md scale-105'
                    : 'bg-slate-50 border-slate-200 text-slate-700 hover:border-sky-300 font-bold'
                }`}
              >
                <span className="text-xl mb-0.5">
                  {g === 1 ? '🥇' : g === 2 ? '🥈' : g === 3 ? '🥉' : g === 4 ? '🏅' : g === 5 ? '🎯' : '🎓'}
                </span>
                <span className="text-sm font-heading font-black">Kelas {g}</span>
                <span className={`text-[9px] uppercase font-bold ${isSelected ? 'text-sky-200' : 'text-slate-400'}`}>
                  {g <= 2 ? 'Fase A' : g <= 4 ? 'Fase B' : 'Fase C'}
                </span>

                {isSelected && (
                  <div className="absolute -top-1.5 -right-1.5 w-4 h-4 bg-amber-400 rounded-full border-2 border-white flex items-center justify-center text-[9px] text-amber-950 font-black">
                    ✓
                  </div>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* 7 Mata Pelajaran Grid */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <div>
            <h3 className="font-heading font-black text-lg text-slate-800">
              Menu 7 Mata Pelajaran Lengkap
            </h3>
            <p className="text-xs text-slate-500 font-semibold">
              Sentuh pelajaran untuk membaca materi, contoh soal, dan audio narasi
            </p>
          </div>

          <span className="text-xs font-black text-slate-500 bg-slate-100 px-2.5 py-1 rounded-full">
            7 Pelajaran
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {SUBJECTS.map((sub) => {
            // Count progress for this subject dynamically tailored to student's grade
            const subjectLessons = getLessonsForSubjectAndGrade(sub.id, profile.grade);
            const completedCount = subjectLessons.filter((l) =>
              profile.completedLessons.includes(l.id)
            ).length;
            const progressPercent = subjectLessons.length > 0
              ? Math.round((completedCount / subjectLessons.length) * 100)
              : 0;

            return (
              <div
                key={sub.id}
                onClick={() => {
                  playSound.click();
                  onSelectSubject(sub.id);
                }}
                role="button"
                tabIndex={0}
                className="bg-white rounded-3xl p-4 md:p-5 border-2 border-slate-200 hover:border-sky-400 hover:shadow-lg transition-all cursor-pointer flex flex-col justify-between group active:scale-98"
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-3">
                    <div
                      className="w-12 h-12 rounded-2xl flex items-center justify-center text-white shadow-xs group-hover:scale-110 transition-transform"
                      style={{ backgroundColor: sub.color }}
                    >
                      {renderSubjectIcon(sub.iconName, 'w-6 h-6')}
                    </div>

                    <span
                      className="text-[10px] font-black px-2.5 py-0.5 rounded-full"
                      style={{
                        backgroundColor: sub.bgLight,
                        color: sub.color,
                        border: `1px solid ${sub.borderLight}`
                      }}
                    >
                      {sub.badgeTag}
                    </span>
                  </div>

                  <h4 className="font-heading font-black text-base md:text-lg text-slate-800 group-hover:text-sky-600 transition-colors">
                    {sub.name}
                  </h4>
                  <p className="text-xs text-slate-500 font-semibold mt-1 line-clamp-2 leading-relaxed">
                    {sub.description}
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-100">
                  {/* Progress bar */}
                  <div className="flex items-center justify-between text-[11px] font-bold text-slate-500 mb-1">
                    <span>Progres Belajar</span>
                    <span className="font-black text-sky-700">{progressPercent}%</span>
                  </div>
                  <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all duration-500"
                      style={{
                        width: `${Math.max(5, progressPercent)}%`,
                        backgroundColor: sub.color
                      }}
                    />
                  </div>

                  <div className="flex items-center justify-between mt-3 text-xs">
                    <span className="font-bold text-slate-400 text-[11px]">
                      {sub.topicCount} Topik Belajar
                    </span>
                    <span className="font-black text-sky-600 group-hover:translate-x-1 transition-transform inline-flex items-center gap-1">
                      Buka Bab →
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Feature Highlights: Game Seru & Kuis Interaktif */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {/* Game Edukasi Banner */}
        <div
          onClick={() => {
            playSound.click();
            onOpenGames();
          }}
          role="button"
          tabIndex={0}
          className="bg-gradient-to-br from-emerald-500 to-teal-600 text-white rounded-3xl p-5 shadow-md hover:shadow-lg transition-all cursor-pointer flex items-center justify-between gap-4 group"
        >
          <div>
            <span className="bg-white/20 text-white text-[10px] font-black px-2.5 py-0.5 rounded-full inline-block uppercase tracking-wider mb-1">
              Main Sambil Belajar
            </span>
            <h4 className="font-heading font-black text-lg md:text-xl text-white">
              Permainan Edukasi
            </h4>
            <p className="text-xs text-emerald-100 mt-1 font-semibold">
              Balon Matematika, Susun Kata Ceria, dan Teka-Teki Garuda.
            </p>
            <div className="mt-3 inline-flex items-center gap-1.5 text-xs font-black bg-white text-emerald-800 px-3 py-1.5 rounded-xl shadow-xs">
              <Gamepad2 className="w-3.5 h-3.5" />
              <span>Mulai Bermain</span>
            </div>
          </div>

          <div className="text-5xl group-hover:scale-125 transition-transform shrink-0">
            🎮
          </div>
        </div>

        {/* Kuis Interaktif Banner */}
        <div
          onClick={() => {
            playSound.click();
            onOpenQuizzes();
          }}
          role="button"
          tabIndex={0}
          className="bg-gradient-to-br from-amber-500 to-orange-600 text-white rounded-3xl p-5 shadow-md hover:shadow-lg transition-all cursor-pointer flex items-center justify-between gap-4 group"
        >
          <div>
            <span className="bg-white/20 text-white text-[10px] font-black px-2.5 py-0.5 rounded-full inline-block uppercase tracking-wider mb-1">
              Uji Kemampuan
            </span>
            <h4 className="font-heading font-black text-lg md:text-xl text-white">
              Tantangan Kuis
            </h4>
            <p className="text-xs text-amber-100 mt-1 font-semibold">
              Jawab kuis pilihan ganda untuk meraih skor 100 dan lencana piala!
            </p>
            <div className="mt-3 inline-flex items-center gap-1.5 text-xs font-black bg-white text-amber-900 px-3 py-1.5 rounded-xl shadow-xs">
              <HelpCircle className="w-3.5 h-3.5" />
              <span>Ikuti Kuis</span>
            </div>
          </div>

          <div className="text-5xl group-hover:scale-125 transition-transform shrink-0">
            🏆
          </div>
        </div>
      </div>
    </div>
  );
};
