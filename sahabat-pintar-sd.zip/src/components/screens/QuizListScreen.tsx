import React from 'react';
import { UserProfile, Grade } from '../../types';
import { getQuizzesForGrade } from '../../data/learningContent';
import { SUBJECTS } from '../../data/subjects';
import { playSound } from '../../services/soundEffects';
import { HelpCircle, Star, Trophy, ArrowRight, CheckCircle2 } from 'lucide-react';
import { Mascot } from '../mascot/Mascot';

interface QuizListScreenProps {
  profile: UserProfile;
  onStartQuiz: (quizId: string) => void;
}

export const QuizListScreen: React.FC<QuizListScreenProps> = ({
  profile,
  onStartQuiz
}) => {
  const currentGradeQuizzes = getQuizzesForGrade(profile.grade);

  return (
    <div className="p-4 md:p-6 max-w-4xl mx-auto space-y-6">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-amber-500 via-orange-500 to-red-500 rounded-3xl p-5 text-white shadow-md flex items-center justify-between">
        <div className="max-w-[70%]">
          <span className="bg-white/20 text-white text-[10px] font-black px-2.5 py-0.5 rounded-full inline-block uppercase tracking-wider mb-1">
            Uji Pengetahuanmu
          </span>
          <h2 className="font-heading font-black text-xl md:text-2xl text-white">
            Kuis & Tantangan Bintang
          </h2>
          <p className="text-xs text-amber-100 font-semibold mt-1">
            Jawab kuis pilihan ganda, benar salah, dan menjodohkan untuk meraih bintang emas!
          </p>
        </div>

        <div className="shrink-0 -mr-2">
          <Mascot type="boni" size="md" mood="celebrating" showBubble={false} />
        </div>
      </div>

      {/* Quizzes List tailored to active grade */}
      <div className="space-y-3.5">
        <div className="flex items-center justify-between">
          <div className="text-xs font-black text-slate-500 uppercase tracking-wide">
            Kuis Pembelajaran Aktif:
          </div>
          <span className="text-xs font-black text-sky-700 bg-sky-50 px-2.5 py-1 rounded-full border border-sky-200">
            Kelas {profile.grade} SD ({currentGradeQuizzes.length} Kuis)
          </span>
        </div>

        {currentGradeQuizzes.map((quiz) => {
          const subject = SUBJECTS.find((s) => s.id === quiz.subjectId);
          const historyEntry = profile.quizHistory.find((h) => h.quizId === quiz.id);

          return (
            <div
              key={quiz.id}
              className="bg-white rounded-2xl p-4 md:p-5 border-2 border-slate-200 shadow-xs hover:border-amber-400 hover:shadow-md transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4"
            >
              <div className="flex items-start gap-3.5">
                <div
                  className="w-12 h-12 rounded-2xl flex items-center justify-center text-white shrink-0 font-black text-xl shadow-xs"
                  style={{ backgroundColor: subject?.color || '#0284c7' }}
                >
                  <HelpCircle className="w-6 h-6" />
                </div>

                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-black uppercase tracking-wider text-slate-500 bg-slate-100 px-2 py-0.5 rounded-md">
                      {subject?.name || 'Mata Pelajaran'}
                    </span>
                    <span className="text-[10px] font-black text-amber-800 bg-amber-100 px-2 py-0.5 rounded-md flex items-center gap-1">
                      <Star className="w-3 h-3 text-amber-500 fill-amber-500" />
                      +{quiz.rewardStars} Bintang
                    </span>
                  </div>

                  <h3 className="font-heading font-black text-base text-slate-800 mt-1">
                    {quiz.title}
                  </h3>
                  <p className="text-xs text-slate-500 font-semibold mt-0.5">
                    {quiz.description}
                  </p>

                  {historyEntry && (
                    <div className="flex items-center gap-1.5 mt-2 text-[11px] font-black text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-md inline-flex border border-emerald-200">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                      <span>Nilai Terbaik: {historyEntry.percentage}% ({historyEntry.score}/{historyEntry.totalQuestions})</span>
                    </div>
                  )}
                </div>
              </div>

              <button
                onClick={() => {
                  playSound.click();
                  onStartQuiz(quiz.id);
                }}
                className="btn-tactile-yellow font-black px-5 py-2.5 rounded-2xl text-xs md:text-sm flex items-center justify-center gap-1.5 shrink-0 self-end sm:self-center cursor-pointer shadow-xs"
              >
                <span>{historyEntry ? 'Ulangi Kuis' : 'Mulai Kuis'}</span>
                <ArrowRight className="w-4 h-4 text-amber-900" />
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
};
