import React, { useState, useEffect } from 'react';
import { Quiz, QuizResultRecord, Subject, ExerciseQuestion, MatchingPair } from '../../types';
import { playSound, speechService } from '../../services/soundEffects';
import confetti from 'canvas-confetti';
import {
  X,
  Star,
  CheckCircle2,
  XCircle,
  HelpCircle,
  Trophy,
  ArrowRight,
  RefreshCw,
  Lightbulb,
  Volume2,
  Sparkles,
  Check
} from 'lucide-react';
import { Mascot } from '../mascot/Mascot';

interface QuizModalProps {
  quiz: Quiz;
  subject?: Subject;
  onClose: () => void;
  onFinishQuiz: (record: QuizResultRecord) => void;
}

export const QuizModal: React.FC<QuizModalProps> = ({
  quiz,
  subject,
  onClose,
  onFinishQuiz
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAnswerSubmitted, setIsAnswerSubmitted] = useState(false);
  const [correctCount, setCorrectCount] = useState(0);
  const [showHint, setShowHint] = useState(false);
  const [isCompleted, setIsCompleted] = useState(false);

  // Question Answer states
  const [selectedOption, setSelectedOption] = useState<number | null>(null); // For multiple_choice
  const [selectedTrueFalse, setSelectedTrueFalse] = useState<boolean | null>(null); // For true_false
  const [fillBlankInput, setFillBlankInput] = useState<string>(''); // For fill_blank

  // Matching state
  const [matchedPairs, setMatchedPairs] = useState<{ leftId: string; rightId: string }[]>([]);
  const [selectedLeftId, setSelectedLeftId] = useState<string | null>(null);

  const totalQuestions = quiz.questions.length;
  const currentQ: ExerciseQuestion = quiz.questions[currentIndex] || {
    id: 'fallback',
    type: 'multiple_choice',
    prompt: 'Apakah kamu siap belajar?',
    options: ['Siap!', 'Sangat Siap!', 'Tentu Saja!', 'Semangat!'],
    correctOptionIndex: 0,
    explanation: 'Semangat belajar membawa keberhasilan!',
    hint: 'Pilih jawaban yang penuh semangat.',
    points: 25
  };

  useEffect(() => {
    return () => {
      speechService.stop();
    };
  }, []);

  // Reset inputs when switching question
  const resetQuestionState = () => {
    setSelectedOption(null);
    setSelectedTrueFalse(null);
    setFillBlankInput('');
    setMatchedPairs([]);
    setSelectedLeftId(null);
    setIsAnswerSubmitted(false);
    setShowHint(false);
  };

  // Speak question aloud using Indonesian TTS
  const handleReadQuestion = () => {
    playSound.click();
    let textToSpeak = currentQ.prompt;
    if (currentQ.type === 'multiple_choice' && currentQ.options) {
      textToSpeak += `. Pilihan: A, ${currentQ.options[0]}. B, ${currentQ.options[1]}. C, ${currentQ.options[2]}. D, ${currentQ.options[3]}.`;
    } else if (currentQ.type === 'true_false') {
      textToSpeak += `. Tentukan apakah pernyataan ini Benar atau Salah.`;
    }
    speechService.speak(textToSpeak, { rate: 0.95 });
  };

  // Handle Matching click
  const handleSelectLeft = (pairId: string) => {
    playSound.click();
    setSelectedLeftId(pairId);
  };

  const handleSelectRight = (pairId: string) => {
    if (!selectedLeftId) return;
    playSound.click();
    // Pair them
    setMatchedPairs((prev) => [
      ...prev.filter((p) => p.leftId !== selectedLeftId && p.rightId !== pairId),
      { leftId: selectedLeftId, rightId: pairId }
    ]);
    setSelectedLeftId(null);
  };

  // Verify answer correctness
  const isAnswerCorrect = (): boolean => {
    if (currentQ.type === 'multiple_choice') {
      const correctIdx = currentQ.correctOptionIndex ?? (currentQ as unknown as { correctAnswerIndex: number }).correctAnswerIndex ?? 0;
      return selectedOption === correctIdx;
    }

    if (currentQ.type === 'true_false') {
      return selectedTrueFalse === (currentQ.isTrue ?? true);
    }

    if (currentQ.type === 'fill_blank') {
      const cleaned = fillBlankInput.trim().toLowerCase();
      const acceptable = (currentQ.acceptableAnswers || []).map((a) => a.toLowerCase());
      return acceptable.includes(cleaned);
    }

    if (currentQ.type === 'matching') {
      const targetPairs = currentQ.pairs || [];
      if (matchedPairs.length !== targetPairs.length) return false;
      return matchedPairs.every((m) => m.leftId === m.rightId);
    }

    return false;
  };

  const isInputGiven = (): boolean => {
    if (currentQ.type === 'multiple_choice') return selectedOption !== null;
    if (currentQ.type === 'true_false') return selectedTrueFalse !== null;
    if (currentQ.type === 'fill_blank') return fillBlankInput.trim().length > 0;
    if (currentQ.type === 'matching') return matchedPairs.length === (currentQ.pairs?.length || 0);
    return false;
  };

  const handleSubmitAnswer = () => {
    if (!isInputGiven()) return;
    speechService.stop();
    setIsAnswerSubmitted(true);

    const correct = isAnswerCorrect();
    if (correct) {
      playSound.success();
      setCorrectCount((prev) => prev + 1);
    } else {
      playSound.wrong();
    }
  };

  const handleNextQuestion = () => {
    playSound.click();
    speechService.stop();
    if (currentIndex < totalQuestions - 1) {
      setCurrentIndex((prev) => prev + 1);
      resetQuestionState();
    } else {
      finishQuiz();
    }
  };

  const finishQuiz = () => {
    const finalCorrect = correctCount;
    const percentage = Math.round((finalCorrect / totalQuestions) * 100);
    const starsEarned = Math.round((percentage / 100) * quiz.rewardStars) + 3;

    playSound.fanfare();
    if (percentage >= 70) {
      confetti({ particleCount: 60, spread: 80, origin: { y: 0.6 } });
    }

    const record: QuizResultRecord = {
      quizId: quiz.id,
      quizTitle: quiz.title,
      subjectId: quiz.subjectId,
      grade: quiz.grade,
      score: finalCorrect,
      totalQuestions,
      percentage,
      starsEarned,
      date: new Date().toLocaleDateString('id-ID', {
        day: 'numeric',
        month: 'short',
        year: 'numeric'
      })
    };

    setIsCompleted(true);
    onFinishQuiz(record);
  };

  if (isCompleted) {
    const percentage = Math.round((correctCount / totalQuestions) * 100);
    const starsEarned = Math.round((percentage / 100) * quiz.rewardStars) + 3;

    return (
      <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4">
        <div className="bg-white w-full max-w-md rounded-3xl p-6 text-center shadow-2xl border-4 border-amber-300 animate-float">
          <div className="w-20 h-20 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-3 border-4 border-amber-300">
            <Trophy className="w-10 h-10 text-amber-500 animate-bounce" />
          </div>

          <h2 className="font-heading font-black text-2xl text-slate-800">
            {percentage >= 80 ? 'Hebat Sekali, Juara Pintar!' : 'Bagus, Kamu Terus Berkembang!'}
          </h2>

          <p className="text-sm text-slate-600 mt-1 font-semibold">
            Kamu menjawab benar <span className="font-black text-sky-600">{correctCount}</span> dari{' '}
            <span className="font-bold">{totalQuestions}</span> soal ({percentage}%)!
          </p>

          <div className="my-5 p-3.5 bg-amber-50 rounded-2xl border-2 border-amber-200 inline-flex items-center gap-2 shadow-xs">
            <Star className="w-6 h-6 text-amber-500 fill-amber-400" />
            <span className="font-black text-lg text-amber-900">
              +{starsEarned} Bintang Emas Masuk Prestasimu!
            </span>
          </div>

          <div className="flex gap-3 justify-center">
            <button
              onClick={() => {
                setCurrentIndex(0);
                resetQuestionState();
                setCorrectCount(0);
                setIsCompleted(false);
              }}
              className="btn-tactile-yellow px-5 py-2.5 rounded-2xl font-black text-sm flex items-center gap-1.5 cursor-pointer"
            >
              <RefreshCw className="w-4 h-4" />
              Ulangi Latihan
            </button>

            <button
              onClick={onClose}
              className="btn-tactile-blue text-white px-5 py-2.5 rounded-2xl font-black text-sm cursor-pointer"
            >
              Selesai & Simpan
            </button>
          </div>
        </div>
      </div>
    );
  }

  const questionTypeBadge = {
    multiple_choice: 'Pilihan Ganda',
    true_false: 'Benar atau Salah',
    fill_blank: 'Mengisi Jawaban',
    matching: 'Menjodohkan Pasangan'
  }[currentQ.type];

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-3 md:p-6 overflow-y-auto">
      <div className="bg-white w-full max-w-xl rounded-3xl shadow-2xl border-4 border-sky-300 overflow-hidden my-auto flex flex-col">
        {/* Header */}
        <div className="bg-gradient-to-r from-sky-600 to-blue-600 p-4 text-white flex items-center justify-between">
          <div>
            <div className="text-[11px] font-bold text-sky-200 uppercase tracking-wider flex items-center gap-1.5">
              <span>{questionTypeBadge}</span>
              <span>•</span>
              <span>Kelas {quiz.grade} SD</span>
            </div>
            <div className="flex items-center gap-2 mt-0.5">
              <span className="font-heading font-black text-base text-white">
                Soal {currentIndex + 1} dari {totalQuestions}
              </span>
              <span className="bg-amber-400 text-amber-950 text-[10px] font-black px-2 py-0.5 rounded-full flex items-center gap-1">
                <Star className="w-3 h-3 fill-amber-950" />
                +{currentQ.points} Poin
              </span>
            </div>
          </div>

          <button
            onClick={() => {
              speechService.stop();
              onClose();
            }}
            className="w-8 h-8 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center text-white cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Progress bar */}
        <div className="w-full bg-sky-100 h-2">
          <div
            className="bg-amber-400 h-full transition-all duration-300"
            style={{ width: `${((currentIndex + 1) / totalQuestions) * 100}%` }}
          />
        </div>

        {/* Question & Interactive Body */}
        <div className="p-4 md:p-6 space-y-4 overflow-y-auto max-h-[70vh]">
          {/* Question Text Card with Indonesian Speech Audio button */}
          <div className="bg-sky-50 rounded-2xl p-4 border-2 border-sky-200 text-slate-800 font-bold text-base leading-snug flex items-start justify-between gap-3 shadow-xs">
            <div className="flex-1">
              <span>{currentQ.prompt}</span>
            </div>

            {/* Read Aloud Button */}
            <button
              onClick={handleReadQuestion}
              title="Dengarkan soal dibacakan"
              className="bg-white hover:bg-sky-100 text-sky-700 p-2 rounded-xl border border-sky-300 shrink-0 cursor-pointer shadow-xs transition-colors"
            >
              <Volume2 className="w-4 h-4" />
            </button>
          </div>

          {/* Hint Toggle */}
          {!isAnswerSubmitted && (
            <div className="flex justify-end">
              <button
                onClick={() => {
                  playSound.click();
                  setShowHint((h) => !h);
                }}
                className="text-xs font-bold text-amber-700 hover:text-amber-800 flex items-center gap-1 bg-amber-50 hover:bg-amber-100 px-3 py-1 rounded-full border border-amber-300 cursor-pointer"
              >
                <Lightbulb className="w-3.5 h-3.5 text-amber-500 fill-amber-400" />
                <span>{showHint ? 'Tutup Petunjuk' : 'Minta Petunjuk Boni'}</span>
              </button>
            </div>
          )}

          {showHint && !isAnswerSubmitted && (
            <div className="bg-amber-50 rounded-xl p-3 border border-amber-300 text-xs text-amber-900 font-bold flex items-start gap-2">
              <span className="text-base">💡</span>
              <span>{currentQ.hint}</span>
            </div>
          )}

          {/* 1. MULTIPLE CHOICE MODE */}
          {currentQ.type === 'multiple_choice' && currentQ.options && (
            <div className="space-y-2.5">
              {currentQ.options.map((opt, idx) => {
                const isSelected = selectedOption === idx;
                const correctIdx = currentQ.correctOptionIndex ?? (currentQ as unknown as { correctAnswerIndex: number }).correctAnswerIndex ?? 0;
                const isCorrect = idx === correctIdx;

                let btnStyle = 'bg-white border-slate-200 text-slate-700 hover:border-sky-400';
                if (isSelected && !isAnswerSubmitted) {
                  btnStyle = 'bg-sky-50 border-sky-500 text-sky-900 shadow-sm ring-2 ring-sky-300';
                }
                if (isAnswerSubmitted) {
                  if (isCorrect) {
                    btnStyle = 'bg-emerald-100 border-emerald-500 text-emerald-950 font-black shadow-sm';
                  } else if (isSelected && !isCorrect) {
                    btnStyle = 'bg-rose-100 border-rose-500 text-rose-950 font-bold';
                  } else {
                    btnStyle = 'bg-slate-50 border-slate-200 text-slate-400 opacity-60';
                  }
                }

                const letters = ['A', 'B', 'C', 'D'];

                return (
                  <button
                    key={idx}
                    disabled={isAnswerSubmitted}
                    onClick={() => {
                      if (!isAnswerSubmitted) {
                        playSound.click();
                        setSelectedOption(idx);
                      }
                    }}
                    className={`w-full p-3.5 rounded-2xl border-2 text-left flex items-center gap-3 transition-all cursor-pointer ${btnStyle}`}
                  >
                    <div
                      className={`w-8 h-8 rounded-xl flex items-center justify-center font-black text-xs shrink-0 ${
                        isSelected ? 'bg-sky-600 text-white' : 'bg-slate-100 text-slate-700'
                      }`}
                    >
                      {letters[idx]}
                    </div>
                    <span className="text-sm md:text-base font-bold flex-1">{opt}</span>
                    {isAnswerSubmitted && isCorrect && (
                      <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                    )}
                    {isAnswerSubmitted && isSelected && !isCorrect && (
                      <XCircle className="w-5 h-5 text-rose-600 shrink-0" />
                    )}
                  </button>
                );
              })}
            </div>
          )}

          {/* 2. TRUE OR FALSE MODE */}
          {currentQ.type === 'true_false' && (
            <div className="grid grid-cols-2 gap-3">
              {[true, false].map((val) => {
                const isSelected = selectedTrueFalse === val;
                const isCorrect = val === (currentQ.isTrue ?? true);

                let btnStyle = val
                  ? 'border-emerald-300 bg-emerald-50/50 hover:bg-emerald-100 text-emerald-900'
                  : 'border-rose-300 bg-rose-50/50 hover:bg-rose-100 text-rose-900';

                if (isSelected && !isAnswerSubmitted) {
                  btnStyle = val
                    ? 'border-emerald-500 bg-emerald-100 ring-2 ring-emerald-400 text-emerald-950 scale-102 font-black'
                    : 'border-rose-500 bg-rose-100 ring-2 ring-rose-400 text-rose-950 scale-102 font-black';
                }

                if (isAnswerSubmitted) {
                  if (isCorrect) {
                    btnStyle = 'border-emerald-500 bg-emerald-200 text-emerald-950 font-black shadow-md';
                  } else if (isSelected && !isCorrect) {
                    btnStyle = 'border-rose-500 bg-rose-200 text-rose-950 font-bold opacity-80';
                  } else {
                    btnStyle = 'opacity-40 bg-slate-100 border-slate-200';
                  }
                }

                return (
                  <button
                    key={String(val)}
                    disabled={isAnswerSubmitted}
                    onClick={() => {
                      if (!isAnswerSubmitted) {
                        playSound.click();
                        setSelectedTrueFalse(val);
                      }
                    }}
                    className={`p-5 rounded-3xl border-3 flex flex-col items-center justify-center transition-all cursor-pointer ${btnStyle}`}
                  >
                    <span className="text-3xl mb-1">{val ? '✅' : '❌'}</span>
                    <span className="font-heading font-black text-lg">
                      {val ? 'BENAR' : 'SALAH'}
                    </span>
                  </button>
                );
              })}
            </div>
          )}

          {/* 3. FILL IN THE BLANK MODE */}
          {currentQ.type === 'fill_blank' && (
            <div className="space-y-3">
              <div>
                <label className="text-xs font-bold text-slate-600 block mb-1">
                  Ketik jawabanmu di bawah atau sentuh salah satu pilihan kata:
                </label>
                <input
                  type="text"
                  disabled={isAnswerSubmitted}
                  value={fillBlankInput}
                  onChange={(e) => setFillBlankInput(e.target.value)}
                  placeholder={currentQ.placeholderText || 'Ketik jawaban...'}
                  className={`w-full p-3.5 rounded-2xl border-2 text-base font-bold transition-all focus:outline-none ${
                    isAnswerSubmitted
                      ? isAnswerCorrect()
                        ? 'border-emerald-500 bg-emerald-50 text-emerald-900 font-black'
                        : 'border-rose-500 bg-rose-50 text-rose-900'
                      : 'border-sky-300 focus:border-sky-500 bg-white'
                  }`}
                />
              </div>

              {/* Touch Word Bank for easy answering on mobile phones */}
              {!isAnswerSubmitted && currentQ.wordBank && currentQ.wordBank.length > 0 && (
                <div className="bg-slate-50 p-3 rounded-2xl border border-slate-200">
                  <div className="text-[11px] font-bold text-slate-500 mb-2">
                    Sentuh kata pilihan:
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {currentQ.wordBank.map((word, wIdx) => (
                      <button
                        key={wIdx}
                        onClick={() => {
                          playSound.click();
                          setFillBlankInput(word);
                        }}
                        className="bg-white hover:bg-sky-50 border border-slate-300 hover:border-sky-400 font-bold px-3 py-1.5 rounded-xl text-xs text-slate-800 shadow-xs active:scale-95 transition-all cursor-pointer"
                      >
                        {word}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* 4. MATCHING PAIRS MODE */}
          {currentQ.type === 'matching' && currentQ.pairs && (
            <div className="space-y-3">
              <div className="text-xs font-bold text-slate-600 text-center bg-sky-50 p-2 rounded-xl">
                Sentuh item di kolom kiri, lalu sentuh pasangannya di kolom kanan!
              </div>

              <div className="grid grid-cols-2 gap-3">
                {/* Left Column */}
                <div className="space-y-2">
                  {currentQ.pairs.map((p) => {
                    const isSelected = selectedLeftId === p.id;
                    const isMatched = matchedPairs.some((m) => m.leftId === p.id);

                    return (
                      <button
                        key={p.id}
                        disabled={isAnswerSubmitted}
                        onClick={() => handleSelectLeft(p.id)}
                        className={`w-full p-2.5 rounded-xl border-2 text-left text-xs font-bold transition-all flex items-center gap-2 ${
                          isSelected
                            ? 'bg-amber-300 border-amber-500 shadow-sm scale-102 font-black'
                            : isMatched
                            ? 'bg-emerald-50 border-emerald-400 text-emerald-900'
                            : 'bg-white border-slate-200 hover:border-sky-300'
                        }`}
                      >
                        {p.leftEmoji && <span className="text-lg">{p.leftEmoji}</span>}
                        <span className="truncate">{p.leftText}</span>
                        {isMatched && <Check className="w-3.5 h-3.5 text-emerald-600 ml-auto" />}
                      </button>
                    );
                  })}
                </div>

                {/* Right Column */}
                <div className="space-y-2">
                  {currentQ.pairs.map((p) => {
                    const isMatched = matchedPairs.some((m) => m.rightId === p.id);

                    return (
                      <button
                        key={p.id}
                        disabled={isAnswerSubmitted}
                        onClick={() => handleSelectRight(p.id)}
                        className={`w-full p-2.5 rounded-xl border-2 text-left text-xs font-bold transition-all flex items-center gap-2 ${
                          isMatched
                            ? 'bg-emerald-50 border-emerald-400 text-emerald-900'
                            : selectedLeftId
                            ? 'bg-white border-dashed border-sky-400 hover:bg-sky-50'
                            : 'bg-white border-slate-200'
                        }`}
                      >
                        {p.rightEmoji && <span className="text-lg">{p.rightEmoji}</span>}
                        <span className="truncate">{p.rightText}</span>
                        {isMatched && <Check className="w-3.5 h-3.5 text-emerald-600 ml-auto" />}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* Educational Feedback after submission */}
          {isAnswerSubmitted && (
            <div
              className={`p-4 rounded-2xl border-2 animate-bounce ${
                isAnswerCorrect()
                  ? 'bg-emerald-50 border-emerald-300 text-emerald-900'
                  : 'bg-rose-50 border-rose-300 text-rose-900'
              }`}
              style={{ animationDuration: '0.8s', animationIterationCount: 1 }}
            >
              <div className="font-black text-sm flex items-center gap-1.5">
                {isAnswerCorrect() ? (
                  <>
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span>{currentQ.praiseMessage || 'Hebat Sekali! Jawabanmu Tepat!'}</span>
                  </>
                ) : (
                  <>
                    <XCircle className="w-4 h-4 text-rose-600" />
                    <span>Belum Tepat Teman, Yuk Pelajari Penjelasannya:</span>
                  </>
                )}
              </div>
              <p className="text-xs mt-1 font-semibold leading-relaxed">
                {currentQ.explanation}
              </p>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="p-4 bg-slate-50 border-t-2 border-slate-200 flex items-center justify-between gap-3">
          <div className="text-xs font-bold text-slate-500">
            Benar: <span className="text-sky-600 font-black">{correctCount}</span> dari{' '}
            <span className="font-bold">{currentIndex + (isAnswerSubmitted ? 1 : 0)}</span>
          </div>

          {!isAnswerSubmitted ? (
            <button
              disabled={!isInputGiven()}
              onClick={handleSubmitAnswer}
              className={`px-6 py-2.5 rounded-2xl font-black text-sm flex items-center gap-2 ${
                isInputGiven()
                  ? 'btn-tactile-blue text-white cursor-pointer'
                  : 'bg-slate-300 text-slate-500 cursor-not-allowed opacity-60'
              }`}
            >
              Periksa Jawaban
            </button>
          ) : (
            <button
              onClick={handleNextQuestion}
              className="btn-tactile-green text-white px-6 py-2.5 rounded-2xl font-black text-sm flex items-center gap-2 cursor-pointer shadow-xs"
            >
              <span>{currentIndex < totalQuestions - 1 ? 'Soal Berikutnya' : 'Lihat Hasil Akhir'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
