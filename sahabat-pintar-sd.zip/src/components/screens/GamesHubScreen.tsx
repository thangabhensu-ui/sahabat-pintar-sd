import React, { useState } from 'react';
import { UserProfile, Grade } from '../../types';
import { MathBalloonGame } from '../games/MathBalloonGame';
import { WordScrambleGame } from '../games/WordScrambleGame';
import { PancasilaMatchGame } from '../games/PancasilaMatchGame';
import { playSound } from '../../services/soundEffects';
import { Gamepad2, Sparkles, Star, Trophy, ArrowRight, Heart } from 'lucide-react';
import { Mascot } from '../mascot/Mascot';

interface GamesHubScreenProps {
  profile: UserProfile;
  onAddStars: (stars: number) => void;
}

type ActiveGame = 'none' | 'math' | 'word' | 'pancasila';

export const GamesHubScreen: React.FC<GamesHubScreenProps> = ({
  profile,
  onAddStars
}) => {
  const [activeGame, setActiveGame] = useState<ActiveGame>('none');

  const handleFinishGame = (stars: number) => {
    onAddStars(stars);
  };

  if (activeGame === 'math') {
    return (
      <div className="p-4 max-w-lg mx-auto">
        <MathBalloonGame
          grade={profile.grade}
          onFinish={handleFinishGame}
          onBack={() => setActiveGame('none')}
        />
      </div>
    );
  }

  if (activeGame === 'word') {
    return (
      <div className="p-4 max-w-lg mx-auto">
        <WordScrambleGame
          onFinish={handleFinishGame}
          onBack={() => setActiveGame('none')}
        />
      </div>
    );
  }

  if (activeGame === 'pancasila') {
    return (
      <div className="p-4 max-w-lg mx-auto">
        <PancasilaMatchGame
          onFinish={handleFinishGame}
          onBack={() => setActiveGame('none')}
        />
      </div>
    );
  }

  const gameCards = [
    {
      id: 'math' as ActiveGame,
      title: 'Teka-Teki Balon Angka',
      category: 'Matematika Seru',
      description: 'Pecahkan balon jawaban yang benar sesuai soal hitung cepat Boni!',
      iconEmoji: '🎈',
      color: 'from-sky-400 to-blue-600',
      borderColor: 'border-sky-300',
      starsReward: 'Hingga 10 Bintang',
      badge: 'Favorit'
    },
    {
      id: 'word' as ActiveGame,
      title: 'Susun Kata Ceria',
      category: 'Bahasa Indonesia',
      description: 'Tebak dan susun huruf-huruf acak menjadi kata nusantara yang tepat!',
      iconEmoji: '🧩',
      color: 'from-emerald-400 to-teal-600',
      borderColor: 'border-emerald-300',
      starsReward: 'Hingga 15 Bintang',
      badge: 'Asah Otak'
    },
    {
      id: 'pancasila' as ActiveGame,
      title: 'Petualangan Garuda Pancasila',
      category: 'Pendidikan Pancasila',
      description: 'Jodohkan kelima simbol sila perisai Garuda dengan butir nilai luhurnya!',
      iconEmoji: '🦅',
      color: 'from-amber-400 to-orange-600',
      borderColor: 'border-amber-300',
      starsReward: '15 Bintang Bonus',
      badge: 'Karakter'
    }
  ];

  return (
    <div className="p-4 md:p-6 max-w-2xl mx-auto space-y-6">
      {/* Header Banner with Mascot */}
      <div className="bg-gradient-to-r from-purple-500 via-indigo-500 to-sky-500 rounded-3xl p-5 text-white shadow-md relative overflow-hidden flex items-center justify-between">
        <div className="z-10 max-w-[65%]">
          <span className="bg-white/20 text-white text-[10px] font-black px-2.5 py-0.5 rounded-full inline-flex items-center gap-1 uppercase tracking-wider mb-1">
            <Sparkles className="w-3 h-3 text-amber-300" />
            Bermain Sambil Belajar
          </span>
          <h2 className="font-heading font-black text-xl md:text-2xl leading-tight">
            Arena Permainan Edukasi
          </h2>
          <p className="text-xs text-purple-100 mt-1 font-semibold leading-relaxed">
            Kumpulkan puluhan bintang emas dengan memenangkan mini game interaktif tanpa iklan!
          </p>
        </div>

        <div className="shrink-0 -mr-2">
          <Mascot type="sasa" size="md" showBubble={false} />
        </div>
      </div>

      {/* Game Selection Cards */}
      <div className="space-y-4">
        {gameCards.map((game) => (
          <div
            key={game.id}
            className="bg-white rounded-3xl p-5 border-2 border-slate-200 shadow-xs hover:shadow-md hover:border-sky-300 transition-all flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
          >
            <div className="flex items-center gap-4">
              <div
                className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${game.color} text-white flex items-center justify-center text-3xl shadow-md shrink-0`}
              >
                {game.iconEmoji}
              </div>

              <div>
                <div className="flex items-center gap-2">
                  <span className="text-[11px] font-black text-sky-700 bg-sky-50 px-2.5 py-0.5 rounded-md uppercase">
                    {game.category}
                  </span>
                  <span className="text-[10px] font-black bg-amber-100 text-amber-800 px-2 py-0.5 rounded-md flex items-center gap-1">
                    <Star className="w-3 h-3 text-amber-500 fill-amber-500" />
                    {game.starsReward}
                  </span>
                </div>

                <h3 className="font-heading font-black text-base md:text-lg text-slate-800 mt-1">
                  {game.title}
                </h3>
                <p className="text-xs text-slate-500 font-semibold line-clamp-2 mt-0.5">
                  {game.description}
                </p>
              </div>
            </div>

            <button
              onClick={() => {
                playSound.click();
                setActiveGame(game.id);
              }}
              className="w-full sm:w-auto btn-tactile-yellow font-black px-5 py-2.5 rounded-2xl text-xs md:text-sm flex items-center justify-center gap-1.5 shrink-0 cursor-pointer shadow-xs"
            >
              <Gamepad2 className="w-4 h-4 text-amber-900" />
              <span>Main Sekarang</span>
              <ArrowRight className="w-4 h-4 text-amber-900" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};
