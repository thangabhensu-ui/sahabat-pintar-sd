import React, { useState } from 'react';
import { KOTLIN_PROJECT_FILES, KotlinSourceFile } from '../../data/nativeKotlinCode';
import { playSound } from '../../services/soundEffects';
import {
  Code,
  FileCode,
  Copy,
  Check,
  FolderTree,
  Terminal,
  Smartphone,
  Download,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  ArrowRight,
  Sparkles,
  Layers,
  Database
} from 'lucide-react';

export const NativeCodeViewer: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<KotlinSourceFile>(
    KOTLIN_PROJECT_FILES[2] // MainActivity.kt by default
  );
  const [copied, setCopied] = useState(false);
  const [showBuildGuide, setShowBuildGuide] = useState(false);

  const handleCopyCode = () => {
    playSound.click();
    navigator.clipboard.writeText(selectedFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const getCategoryBadge = (cat: KotlinSourceFile['category']) => {
    switch (cat) {
      case 'build':
        return <span className="bg-amber-100 text-amber-800 text-[10px] font-black px-2 py-0.5 rounded">Gradle KTS</span>;
      case 'manifest':
        return <span className="bg-purple-100 text-purple-800 text-[10px] font-black px-2 py-0.5 rounded">Manifest XML</span>;
      case 'activity':
        return <span className="bg-sky-100 text-sky-800 text-[10px] font-black px-2 py-0.5 rounded">Activity</span>;
      case 'database':
        return <span className="bg-emerald-100 text-emerald-800 text-[10px] font-black px-2 py-0.5 rounded">Room Database</span>;
      case 'datastore':
        return <span className="bg-blue-100 text-blue-800 text-[10px] font-black px-2 py-0.5 rounded">DataStore</span>;
      case 'theme':
        return <span className="bg-pink-100 text-pink-800 text-[10px] font-black px-2 py-0.5 rounded">Material 3</span>;
      case 'ui':
        return <span className="bg-indigo-100 text-indigo-800 text-[10px] font-black px-2 py-0.5 rounded">Compose UI</span>;
      case 'ci':
        return <span className="bg-emerald-100 text-emerald-800 text-[10px] font-black px-2 py-0.5 rounded">GitHub Actions CI</span>;
    }
  };

  const auditItems = [
    { label: 'settings.gradle.kts', status: 'Lengkap (Root Project Name & Repositories)' },
    { label: 'build.gradle.kts (Proyek)', status: 'Lengkap (Plugin AGP 8.7.3 & Kotlin 2.0.21)' },
    { label: 'gradle.properties', status: 'Lengkap (AndroidX & JVM Args Configured)' },
    { label: 'app/build.gradle.kts', status: 'Lengkap (minSdk 24, Compose, Room, DataStore)' },
    { label: 'AndroidManifest.xml', status: 'Lengkap (Portrait, Theme, Icon Launcher)' },
    { label: 'MainActivity.kt', status: 'Lengkap (Compose NavHost & Scaffold)' },
    { label: 'HomeScreen.kt', status: 'Lengkap (Kls 1-6 Selector, 7 Mapel, Stars)' },
    { label: 'Theme.kt & Color.kt', status: 'Lengkap (Material 3 Biru-Kuning-Hijau)' },
    { label: 'AppDatabase.kt', status: 'Lengkap (Room DB, DAOs, 100% Offline)' },
    { label: 'UserPreferencesRepository.kt', status: 'Lengkap (DataStore Preferences)' },
    { label: 'Resources & Ikon (res/)', status: 'Lengkap (strings.xml, colors.xml, adaptive icons)' },
    { label: 'Cloud CI/CD Workflow', status: 'Lengkap (.github/workflows/build-apk.yml)' }
  ];

  return (
    <div className="p-4 md:p-6 max-w-5xl mx-auto space-y-6">
      {/* Intro Banner with Download Button */}
      <div className="bg-gradient-to-r from-slate-900 via-sky-950 to-indigo-950 rounded-3xl p-5 md:p-6 text-white shadow-xl border-2 border-sky-500/30">
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-5">
          <div className="space-y-1.5 max-w-xl">
            <div className="flex items-center gap-2">
              <span className="bg-emerald-500 text-slate-950 text-[10px] font-black px-2.5 py-0.5 rounded-full uppercase tracking-wider">
                Audit Selesai • 100% Lengkap
              </span>
              <span className="bg-sky-500 text-white text-[10px] font-black px-2 py-0.5 rounded-full">
                Kotlin 2.0.21 • Min SDK 24
              </span>
            </div>
            <h2 className="font-heading font-black text-xl md:text-2xl text-white">
              Paket Proyek Android Native SAHABAT PINTAR SD
            </h2>
            <p className="text-xs md:text-sm text-slate-300 font-medium leading-relaxed">
              Seluruh 12 komponen file proyek Android native telah diaudit dan dibundel rapi dalam 1 file ZIP lengkap, siap untuk langsung dibuild menjadi file APK!
            </p>
          </div>

          {/* Download & Build Action Buttons */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5 shrink-0 w-full lg:w-auto">
            <a
              href="/sahabat-pintar-sd-android.zip"
              download="SahabatPintarSD-AndroidProject.zip"
              onClick={() => playSound.star()}
              className="btn-tactile-yellow font-black px-5 py-3 rounded-2xl text-xs md:text-sm flex items-center justify-center gap-2 shadow-lg cursor-pointer text-center text-amber-950"
            >
              <Download className="w-4 h-4 text-amber-950" />
              <span>Unduh File ZIP Proyek</span>
            </a>

            <button
              onClick={() => {
                playSound.click();
                setShowBuildGuide((b) => !b);
              }}
              className="bg-sky-600 hover:bg-sky-500 text-white font-black px-4 py-3 rounded-2xl text-xs md:text-sm flex items-center justify-center gap-1.5 shadow-md cursor-pointer transition-colors"
            >
              <Terminal className="w-4 h-4" />
              <span>Panduan Build APK</span>
            </button>
          </div>
        </div>
      </div>

      {/* Audit Checklist Card */}
      <div className="bg-white rounded-3xl p-5 border-2 border-slate-200 shadow-xs">
        <h3 className="font-heading font-black text-base text-slate-800 mb-1 flex items-center gap-2">
          <CheckCircle2 className="w-5 h-5 text-emerald-600" />
          <span>Hasil Audit 12 Komponen Proyek Android:</span>
        </h3>
        <p className="text-xs text-slate-500 font-semibold mb-4">
          Seluruh dependensi, package `id.sahabatpintar.sd`, dan komponen Jetpack Compose telah diverifikasi kompatibel.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
          {auditItems.map((item, idx) => (
            <div
              key={idx}
              className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 flex items-start gap-2.5"
            >
              <div className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center text-xs font-black shrink-0 mt-0.5">
                ✓
              </div>
              <div className="overflow-hidden">
                <div className="font-mono text-xs font-bold text-slate-800 truncate">
                  {item.label}
                </div>
                <div className="text-[10px] text-slate-500 font-medium truncate">
                  {item.status}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Build APK Guide Modal / Drawer */}
      {showBuildGuide && (
        <div className="bg-gradient-to-br from-sky-50 to-blue-50 rounded-3xl p-5 border-2 border-sky-300 shadow-md space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="font-heading font-black text-base text-sky-950 flex items-center gap-2">
              <Smartphone className="w-5 h-5 text-sky-600" />
              <span>3 Cara Menghasilkan File APK Debug:</span>
            </h4>
            <button
              onClick={() => setShowBuildGuide(false)}
              className="text-xs font-bold text-slate-500 hover:text-slate-800 bg-white px-2.5 py-1 rounded-lg border border-slate-200 cursor-pointer"
            >
              Tutup Panduan
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs text-slate-700">
            <div className="bg-white p-3.5 rounded-2xl border border-sky-200 space-y-1.5">
              <div className="font-black text-sky-900 flex items-center gap-1">
                <span>1. Android Studio</span>
                <span className="bg-sky-100 text-sky-800 text-[9px] px-1.5 py-0.2 rounded font-black">Laptop / PC</span>
              </div>
              <p className="text-[11px] text-slate-600">
                Ekstrak ZIP → Buka Android Studio → Pilih <b>Open</b> → Klik menu <b>Build &gt; Build APK(s)</b>. File <code>app-debug.apk</code> langsung jadi dalam 1 menit!
              </p>
            </div>

            <div className="bg-white p-3.5 rounded-2xl border border-emerald-200 space-y-1.5">
              <div className="font-black text-emerald-900 flex items-center gap-1">
                <span>2. Cloud Build Otomatis</span>
                <span className="bg-emerald-100 text-emerald-800 text-[9px] px-1.5 py-0.2 rounded font-black">Gratis di HP</span>
              </div>
              <p className="text-[11px] text-slate-600">
                Unggah folder proyek ke GitHub. File <code>.github/workflows/build-apk.yml</code> yang kami sertakan akan otomatis meng-compile APK di cloud GitHub dan menghasilkan download artifact APK!
              </p>
            </div>

            <div className="bg-white p-3.5 rounded-2xl border border-amber-200 space-y-1.5">
              <div className="font-black text-amber-900 flex items-center gap-1">
                <span>3. Langsung di HP Android (Termux)</span>
                <span className="bg-amber-100 text-amber-800 text-[9px] px-1.5 py-0.2 rounded font-black">Khusus HP</span>
              </div>
              <p className="text-[11px] text-slate-600">
                Di aplikasi Termux HP: pasang <code>openjdk-17</code>, lalu jalankan perintah <code>./gradlew assembleDebug</code> untuk membuat file APK langsung di memori HP.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Code Explorer Section */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Left Sidebar: File Tree */}
        <div className="lg:col-span-4 bg-white rounded-3xl p-4 border-2 border-slate-200 shadow-xs space-y-2">
          <div className="flex items-center gap-2 text-xs font-black text-slate-700 uppercase tracking-wide px-2 py-1">
            <FolderTree className="w-4 h-4 text-sky-600" />
            <span>Pemeriksa File Sumber Kotlin</span>
          </div>

          <div className="space-y-1 max-h-[440px] overflow-y-auto pr-1">
            {KOTLIN_PROJECT_FILES.map((file) => {
              const isSelected = selectedFile.path === file.path;

              return (
                <button
                  key={file.path}
                  onClick={() => {
                    playSound.click();
                    setSelectedFile(file);
                  }}
                  className={`w-full text-left p-2.5 rounded-xl transition-all flex items-center justify-between gap-2 cursor-pointer ${
                    isSelected
                      ? 'bg-sky-600 text-white font-black shadow-xs'
                      : 'hover:bg-slate-100 text-slate-700 font-semibold'
                  }`}
                >
                  <div className="flex items-center gap-2 overflow-hidden">
                    <FileCode
                      className={`w-4 h-4 shrink-0 ${
                        isSelected ? 'text-amber-300' : 'text-sky-600'
                      }`}
                    />
                    <span className="text-xs truncate">{file.name}</span>
                  </div>

                  {!isSelected && getCategoryBadge(file.category)}
                </button>
              );
            })}
          </div>

          <div className="pt-2 border-t border-slate-200">
            <a
              href="/sahabat-pintar-sd-android.zip"
              download="SahabatPintarSD-AndroidProject.zip"
              className="w-full btn-tactile-yellow font-black p-2 rounded-xl text-xs flex items-center justify-center gap-1.5 cursor-pointer text-amber-950 block text-center"
            >
              <Download className="w-3.5 h-3.5 inline" />
              <span>Unduh ZIP Proyek Lengkap (108 KB)</span>
            </a>
          </div>
        </div>

        {/* Right Area: Code Display */}
        <div className="lg:col-span-8 bg-slate-900 rounded-3xl border-2 border-slate-800 shadow-lg overflow-hidden flex flex-col">
          {/* Code Header */}
          <div className="bg-slate-800/90 px-4 py-3 border-b border-slate-700 flex items-center justify-between gap-3 shrink-0">
            <div>
              <div className="flex items-center gap-2">
                <span className="font-mono text-xs font-bold text-sky-300">
                  {selectedFile.path}
                </span>
                {getCategoryBadge(selectedFile.category)}
              </div>
              <p className="text-[11px] text-slate-400 font-medium mt-0.5 line-clamp-1">
                {selectedFile.description}
              </p>
            </div>

            <button
              onClick={handleCopyCode}
              className="bg-sky-600 hover:bg-sky-500 text-white font-black px-3.5 py-1.5 rounded-xl text-xs flex items-center gap-1.5 transition-colors cursor-pointer shrink-0 shadow-xs"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-300" />
                  <span>Tersalin!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Salin Kode</span>
                </>
              )}
            </button>
          </div>

          {/* Code Content */}
          <div className="p-4 overflow-x-auto text-xs font-mono text-slate-200 leading-relaxed bg-slate-950 max-h-[500px] overflow-y-auto">
            <pre className="whitespace-pre">
              <code>{selectedFile.content}</code>
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
};
