export type Grade = 1 | 2 | 3 | 4 | 5 | 6;

export type SubjectId =
  | 'bahasa_indonesia'
  | 'matematika'
  | 'ipas'
  | 'pancasila'
  | 'bahasa_inggris'
  | 'seni_budaya'
  | 'agama';

export interface Subject {
  id: SubjectId;
  name: string;
  shortName: string;
  iconName: string;
  color: string;
  bgLight: string;
  borderLight: string;
  description: string;
  topicCount: number;
  badgeTag: string;
}

export interface ExampleProblem {
  question: string;
  steps: string[];
  answer: string;
  tip?: string;
}

export interface LessonIllustration {
  emoji: string;
  title: string;
  caption: string;
}

export type QuestionType =
  | 'multiple_choice'
  | 'true_false'
  | 'matching'
  | 'fill_blank';

export interface MatchingPair {
  id: string;
  leftText: string;
  leftEmoji?: string;
  rightText: string;
  rightEmoji?: string;
}

export interface ExerciseQuestion {
  id: string;
  type: QuestionType;
  prompt: string;
  illustrationEmoji?: string;
  options?: string[]; // for multiple_choice & true_false
  correctOptionIndex?: number;
  isTrue?: boolean; // for true_false
  acceptableAnswers?: string[]; // for fill_blank
  placeholderText?: string;
  wordBank?: string[]; // helper chips for child on touch screens
  pairs?: MatchingPair[]; // for matching
  explanation: string;
  hint: string;
  praiseMessage?: string;
  points: number;
}

export interface Lesson {
  id: string;
  subjectId: SubjectId;
  grade: Grade;
  chapterNumber: number;
  title: string;
  subtitle: string;
  category: string;
  durationMinutes: number;
  funFact: string;
  summary: string;
  contentParagraphs: string[];
  keyPoints: string[];
  illustrations?: LessonIllustration[];
  examples?: ExampleProblem[];
  exercises?: ExerciseQuestion[];
  audioScript: string;
}

export interface QuizQuestion extends ExerciseQuestion {
  // Backwards compatibility alias
  question?: string;
  correctAnswerIndex?: number;
}

export interface Quiz {
  id: string;
  lessonId: string;
  subjectId: SubjectId;
  grade: Grade;
  title: string;
  description: string;
  rewardStars: number;
  questions: ExerciseQuestion[];
}

export type AvatarId = 'boni' | 'sasa' | 'edo' | 'siti' | 'dayu' | 'budi';

export interface QuizResultRecord {
  quizId: string;
  quizTitle: string;
  subjectId: SubjectId;
  grade: Grade;
  score: number;
  totalQuestions: number;
  percentage: number;
  starsEarned: number;
  date: string;
}

export interface UserProfile {
  name: string;
  schoolName: string;
  grade: Grade;
  avatarId: AvatarId;
  stars: number;
  completedLessons: string[];
  unlockedBadges: string[];
  quizHistory: QuizResultRecord[];
  soundEnabled: boolean;
  lastLessonId?: string;
  lastSubjectId?: SubjectId;
}

export interface Badge {
  id: string;
  title: string;
  description: string;
  icon: string;
  color: string;
  requiredStars?: number;
  requiredQuizzes?: number;
}
